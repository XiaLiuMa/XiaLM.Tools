# Work Time Manager
  
  ## 工作时间管理工具
    
```
 o  或许你常常会因为自己虚度光阴而懊悔，但是又有多少次，你仅仅只是懊悔。

 o  你想过，这是为什么吗？命名浪费了那么多时间，但是自己却毫不在意？

 o  因为你没有指标去衡量自己做了什么，没做什么

 o  你纯粹的，只是，觉得，自己浪费了时间

 o  你需要一个工具，

 o  来记录，你究竟完成了多么少的任务

 o  少到自己觉得羞耻

 o  少到觉得自己赚了 

 o  Work Time Manager 

 o  它，最有效的功能就是，

 o  能统计你实际每天工作时间或许只有，3小时，甚至更少。

```


## 管理自己，从知道自己有多懒散开始

```
注册一个账号，开始记录吧。

```

![logindemo](https://github.com/d100000/worktimemanage/blob/master/WorkTime/demo/%E4%BC%98%E5%8C%96%E7%89%88WorkTimeManage1.0.gif "New Demo")


最后免费送福利，自己做的小资讯网站：[访问网站](http://fuliyuan.tk)
