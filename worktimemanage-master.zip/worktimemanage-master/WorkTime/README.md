﻿# worktimemanage
To manage you work time detail 

```
WorkTimeManager is an tool to help you to manager your work for keeping noties .
```

## Login Demo
![logindemo](https://raw.githubusercontent.com/d100000/worktimemanage/master/WorkTime/demo/logindemo.gif "logindemo")
