﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Schedule.Engine.Core
{
    /// <summary>
    /// 工作日志
    /// </summary>
    public class JobLogger
    {
        //public static IRunLogDAL DALRunLog = new RunLogAccessDAL();

        ///// <summary>
        ///// 添加运行日志
        ///// </summary>
        ///// <param name="runLog">运行日志</param>
        //public static void AddRunLog(RunLogDto runLog)
        //{
        //    RunLog l = new RunLog();
        //    l.JobName = runLog.JobName;
        //    l.StartTime = runLog.StartTime;
        //    l.EndTime = runLog.EndTime;
        //    l.ReMark = runLog.ReMark;

        //    DALRunLog.Add(l);
        //}
    }
}
