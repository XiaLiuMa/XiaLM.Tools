﻿using DataEngine.Db.IManaments;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataEngine.Db.Manaments
{
    public class Class1:IClass1
    {
    }
}
