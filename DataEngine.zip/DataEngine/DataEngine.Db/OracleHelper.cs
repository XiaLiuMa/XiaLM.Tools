﻿using Oracle.ManagedDataAccess.Client;
using System;

namespace DataEngine.Db
{
    public class OracleHelper
    {
        public static void Test(string sqlStr)
        {
            string serverIp = "6.1.37.186";
            //数据库连接字串
            string conString = "User Id=qgtg;Password=qgtg;Data Source=(DESCRIPTION = (ADDRESS_LIST= (ADDRESS = (PROTOCOL = TCP)(HOST = " + serverIp + ")(PORT = 32767))) (CONNECT_DATA = (SERVICE_NAME = " + serverIp + ")))";
            using (OracleConnection con = new OracleConnection(conString))
            {
                using (OracleCommand cmd = con.CreateCommand())
                {
                    try
                    {
                        con.Open();
                        cmd.BindByName = true;
                        cmd.CommandText = sqlStr;
                        //cmd.CommandText = "select a.*,b.pjnr from bj_yw_t_crjrydk a, bj_yw_t_crjpj b where a.wybs = b.wybs(+) and a.crrqsj> '20190123150325' and a.crrqsj < '20190123160325'";    //SQL查询语句
                        OracleDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            Console.WriteLine("用户名: " + reader.GetString(0));
                        }
                        Console.WriteLine("Press 'Enter' to continue");
                        reader.Dispose();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    Console.ReadLine();
                }
            }
        }
    }
}
