﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataEngine.Db.IManaments
{
    public interface IClass1
    {
    }
}
