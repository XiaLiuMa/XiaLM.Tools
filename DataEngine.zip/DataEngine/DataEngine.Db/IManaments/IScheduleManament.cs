﻿using System;
using DataEngine.Db.Entities;

namespace DataEngine.Db.IManaments
{
    public interface IScheduleManament : IBaseManament<ScheduleEntity, Guid>
    {
    }
}
