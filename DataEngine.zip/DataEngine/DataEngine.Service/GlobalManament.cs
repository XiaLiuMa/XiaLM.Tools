﻿using DataEngine.Common;
using DataEngine.Service.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataEngine.Service
{
    public class GlobalManament
    {
        public ServicePublicConfig publicConfig { get; private set; }
        public ServicePrivateConfig privateConfig { get; private set; }
        private static GlobalManament instance;
        private readonly static object objLock = new object();
        public static GlobalManament GetInstance()
        {
            if (instance == null)
            {
                lock (objLock)
                {
                    if (instance == null)
                    {
                        instance = new GlobalManament();
                    }
                }
            }
            return instance;
        }
        public GlobalManament()
        {
            string strConfig = AppDomain.CurrentDomain.BaseDirectory + @"Configs\ServiceConfig.xml";
            publicConfig = XmlSerializer.Load<ServicePublicConfig>(strConfig);
        }

    }
}
