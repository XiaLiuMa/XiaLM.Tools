﻿using DataEngine.Db.IManaments;
using Microsoft.Extensions.DependencyInjection;
using Nancy;
using Schedule.Engine.Core;

namespace DataEngine.Service.Modules
{
    public class BaseModule : NancyModule
    {
        public BaseModule()
        {
            Get("/", args => "默认地址");
            Get("/GetAllRuningJob", p => GetAllRuningJob());
        }

        /// <summary>
        /// 获取正在运行的Jobs
        /// </summary>
        /// <returns></returns>
        private object GetAllRuningJob()
        {
            var class1 = DI.ServiceProvider.GetRequiredService<IClass1>();
            var sql1Manament = DI.ServiceProvider.GetRequiredService<IScheduleManament>();
            var sqlManament = DI.ServiceProvider.GetRequiredService<ISqlManament>();
            return SchedulerCenter.GetInstance().ScheduleList;
        }

    }
}
