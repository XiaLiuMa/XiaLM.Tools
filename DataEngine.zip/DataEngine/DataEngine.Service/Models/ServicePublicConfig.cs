﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataEngine.Service.Models
{
    public class ServicePublicConfig
    {
        public int ServicePort { get; set; }
    }
}
