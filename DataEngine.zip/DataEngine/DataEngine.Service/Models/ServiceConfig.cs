﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataEngine.Service.Models
{
    public class ServiceConfig
    {
        public int ServicePort { get; set; }
    }
}
