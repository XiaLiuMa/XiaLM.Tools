﻿using DataEngine.Common;
using DataEngine.Db;
using DataEngine.Db.IManaments;
using Microsoft.Extensions.DependencyInjection;
using Quartz;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace DataEngine.Service.Jobs
{
    public class CHZKRYJob : IJob
    {
        public Task Execute(IJobExecutionContext context)
        {
            Console.Out.WriteLineAsync("This is CHZKRYJob!");
            try
            {
                var sqlManament = DI.ServiceProvider.GetRequiredService<ISqlManament>();
                string strSql = sqlManament.FirstOrDefault(p => p.SqlName.Equals("CHZKRY")).SqlText;
                string sql = string.Format(strSql, DateTime.Now.AddMinutes(-60).ToString("yyyyMMddHHmmss"), DateTime.Now.ToString("yyyyMMddHHmmss"));
                var result = BaseDBContext.GetInstance().Database.SqlQuery<object>(sql);   //执行sql语句
            }
            catch (Exception ex)
            {
                Logger.Error(ex.ToString());
            }
            return Task.CompletedTask;
        }
    }
}
