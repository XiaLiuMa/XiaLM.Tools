﻿using DataEngine.Common;
using Microsoft.AspNetCore.Hosting;
using Schedule.Engine.Core;
using System;
using System.IO;

namespace DataEngine.Service
{
    class Program
    {
        static void Main(string[] args)
        {
            Logger.Init(AppDomain.CurrentDomain.BaseDirectory + @"Configs\Log4Net.config"); //初始化日志工具
            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
            System.Threading.Mutex mutex = new System.Threading.Mutex(false, "DataEngine.Service");
            bool Running = !mutex.WaitOne(0, false);
            if (!Running)
            {
                int port = GlobalManament.GetInstance().publicConfig.ServicePort;
                var host = new WebHostBuilder()
                    .UseKestrel()
                    .UseUrls($"http://localhost:{port}")
                    .UseContentRoot(Directory.GetCurrentDirectory())
                    .UseIISIntegration()
                    .UseStartup<Startup>()
                    .Build();
                host.Run();

                //运行配置文件中的工作计划
                JobManager.GetInstance().RunConfigJobs(AppDomain.CurrentDomain.BaseDirectory + @"Configs\QuartzByCron.xml");   
                while (true) Console.ReadKey();
            }
        }

        private static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            Logger.Error(e.ExceptionObject.ToString());
            Environment.Exit(0);
        }
    }
}
