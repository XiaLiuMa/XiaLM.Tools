﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataEngine.Service
{
    public static class Extensions
    {
        public static IServiceCollection AddTfDI(this IServiceCollection services)
        {
            DI.Services = services;
            return services;
        }

        public static IApplicationBuilder UseTfDI(this IApplicationBuilder builder)
        {
            DI.ServiceProvider = builder.ApplicationServices;
            return builder;
        }
    }

    /// <summary>
    /// 依赖注入扩展
    /// </summary>
    public static class DI
    {
        public static IServiceCollection Services { get; set; }
        public static IServiceProvider ServiceProvider { get; set; }
    }
}
