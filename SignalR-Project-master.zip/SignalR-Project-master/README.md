# SignalR-Project
关于SignalR 的项目工程
*1.SignalR-Beginners 1.0 pj-简单的实时在线聊天室
