﻿using Jobs_Common;
using Quartz;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.Service.Quarz;
using System;
using System.Collections.Generic;

namespace Jobs_SJTB
{
    /// <summary>
    /// 时间同步调度任务
    /// </summary>
    [PersistJobDataAfterExecution]
    [DisallowConcurrentExecution]
    public class SJTBJobs : AbstractQuarztJob
    {       
        /// <summary>
        /// 梅沙系统时间查询SQL语句
        /// </summary>
        private string strSql = string.Empty;
       
        public override void Run(IJobExecutionContext context)
        {
            try
            {
                strSql = GlobalJobs.GetSql("SJTB");
                SchedulerSysTime();
            }
            catch
            {
                throw;
            }
        }
       
        private void SchedulerSysTime()
        {
            foreach (ISqlOperate sql in LstSqlOperate)
            {
                List<Dictionary<string, object>> lst = SqlUtil.Select(strSql,sql);
                IsolatorUtil.SendOneTime(lst,"SJTB", 88,GlobalJobs.MaxSendCount, true);
                DateTime dt = Convert.ToDateTime(lst[0]["SYSDATE"]);
                SetLocalTime(dt);
            }
        } 
       
        #region 设置本计算机时间
        /// <summary>
        /// 设置本计算机时间
        /// </summary>
        private void SetLocalTime(DateTime TimeNow)
        {
            try
            {
                Schedule.Common.Data.SystemTime st = new Schedule.Common.Data.SystemTime
                {
                    vYear = (ushort)(Convert.ToDateTime(TimeNow)).Year,
                    vMonth = (ushort)(Convert.ToDateTime(TimeNow)).Month,
                    vDay = (ushort)(Convert.ToDateTime(TimeNow)).Day,
                    vHour = (ushort)(Convert.ToDateTime(TimeNow)).Hour,
                    vMinute = (ushort)(Convert.ToDateTime(TimeNow)).Minute,
                    vSecond = (ushort)((Convert.ToDateTime(TimeNow)).Second)
                };

                Win32Util.SetLocalTime(ref st);
            }
            catch
            {
                throw;
            }
        }
        #endregion
    }
}
