﻿using System;
using Isolator.SetCharacter.Mod;
using Isolator.SetCharacter.Helper;

namespace Isolator.SetCharacter.SetCharacter
{
    public class Max1800SetCharacter : MNSetCharacter
    {

        public Max1800SetCharacter(MNZFDJDYGX dygx)
            : base(dygx)
        {

        }
        public override bool ClearLKXX(string zjhm)
        {
            try
            {
                byte[] cmd = MV1800Helper.GetClearLineOnScreenMsg(MNZFDJDYGX.MNSB.JKTDH, MNZFDJDYGX.ZBXX.LKZJHM_DJZB_X, MNZFDJDYGX.ZBXX.LKZJHM_DJZB_Y);
                SerialClass.Write(cmd);

                byte[] cmd1 = MV1800Helper.GetClearLineOnScreenMsg(MNZFDJDYGX.MNSB.JKTDH, MNZFDJDYGX.ZBXX.LKPJXX_DJZB_X, MNZFDJDYGX.ZBXX.LKPJXX_DJZB_Y);
                SerialClass.Write(cmd1);

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public override bool ClearAll()
        {
            byte[] cmd = MV1800Helper.GetClearLineOnScreenMsg(MNZFDJDYGX.MNSB.JKTDH, MNZFDJDYGX.ZBXX.LKZJHM_DJZB_X, MNZFDJDYGX.ZBXX.LKZJHM_DJZB_Y);
            SerialClass.Write(cmd);

            byte[] cmd1 = MV1800Helper.GetClearLineOnScreenMsg(MNZFDJDYGX.MNSB.JKTDH, MNZFDJDYGX.ZBXX.LKPJXX_DJZB_X, MNZFDJDYGX.ZBXX.LKPJXX_DJZB_Y);
            SerialClass.Write(cmd1);

            byte[] cmd2 = MV1800Helper.GetClearLineOnScreenMsg(MNZFDJDYGX.MNSB.JKTDH, MNZFDJDYGX.ZBXX.CZYBM_DJZB_X, MNZFDJDYGX.ZBXX.CZYBM_DJZB_Y);
            SerialClass.Write(cmd2);

            return true;
        }

        public override bool SetCharacter(DjMessage djmsg)
        {
            byte[] cmd = MV1800Helper.GetDisplayMetafileOnVideoMsg(MNZFDJDYGX.MNSB.JKTDH, djmsg.Lkzjhm + " " + djmsg.Lkxm, MNZFDJDYGX.ZBXX.LKZJHM_DJZB_X, MNZFDJDYGX.ZBXX.LKZJHM_DJZB_Y);
            SerialClass.Write(cmd);

            byte[] cmd1 = MV1800Helper.GetDisplayMetafileOnVideoMsg(MNZFDJDYGX.MNSB.JKTDH, djmsg.Lkpjxx, MNZFDJDYGX.ZBXX.LKPJXX_DJZB_X, MNZFDJDYGX.ZBXX.LKPJXX_DJZB_Y);
            SerialClass.Write(cmd1);

            byte[] cmd2 = MV1800Helper.GetDisplayMetafileOnVideoMsg(MNZFDJDYGX.MNSB.JKTDH, djmsg.Czydm + " " + djmsg.Czyxm, MNZFDJDYGX.ZBXX.CZYBM_DJZB_X, MNZFDJDYGX.ZBXX.CZYBM_DJZB_Y);
            SerialClass.Write(cmd2);

            return true;
        }
    }
}
