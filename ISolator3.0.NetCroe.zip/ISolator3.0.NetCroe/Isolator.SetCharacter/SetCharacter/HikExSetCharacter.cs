﻿using Isolator.SetCharacter.Hik;
using Isolator.SetCharacter.Mod;
using log4net;
using Schedule.Common.Util;

namespace Isolator.SetCharacter.SetCharacter
{
    public class HikExSetCharacter : WLSetCharacter
    {
        private ILog log = LogManager.GetLogger(typeof(HikSetCharacter));

        public HikExSetCharacter(WLZFDJDYGX dygx)
            : base(dygx)
        {
            if (!HikNetSdk.IsInitSdk)
            {
                HikNetSdk.NET_DVR_Init();
                HikNetSdk.IsInitSdk = true;
            }
            if (!this.bLogin)
            {
                this.Login();
            }
        }

        public bool Login()
        {
            bool result;
            lock (HikNetSdk.dctLogins)
            {
                string key = this.wlzfdjdygx.WLSB.IPADDRESS + "," + this.wlzfdjdygx.WLSB.PORT;
                if (!HikNetSdk.dctLogins.TryGetValue(key, out this.m_login))
                {
                    HikNetSdk.NET_DVR_DEVICEINFO_V30 m_deviceInfo = default(HikNetSdk.NET_DVR_DEVICEINFO_V30);
                    if (this.wlzfdjdygx != null && !this.bLogin)
                    {
                        this.m_login = HikNetSdk.NET_DVR_Login_V30(this.wlzfdjdygx.WLSB.IPADDRESS, (ushort)this.wlzfdjdygx.WLSB.PORT, this.wlzfdjdygx.WLSB.USER_NAME, this.wlzfdjdygx.WLSB.USER_PWD, ref m_deviceInfo);
                        if (this.m_login == -1)
                        {
                            uint error = HikNetSdk.NET_DVR_GetLastError();
                            log.ErrorFormat("设备登录失败，IP为：{0}，错误号为：{1}", this.wlzfdjdygx.WLSB.IPADDRESS, error);
                            result = false;
                        }
                        else
                        {
                            this.bLogin = true;
                            HikNetSdk.dctLogins.Add(key, this.m_login);
                            result = true;
                        }
                    }
                    else
                    {
                        result = false;
                    }
                }
                else
                {
                    if (this.m_login == -1)
                    {
                        System.Threading.Thread.Sleep(500);
                        this.m_login = HikNetSdk.dctLogins[key];
                    }
                    this.bLogin = true;
                    result = true;
                }
            }
            return result;
        }
        public override bool ClearLKXX(string zjhm)
        {
            if (!base.ClearLKXX(zjhm))
            {
                return true;
            }
            if (!this.bLogin)
            {
                return false;
            }
            HikNetSdk.NET_DVR_SHOWSTRING_V30 m_ShowString = default(HikNetSdk.NET_DVR_SHOWSTRING_V30);
            uint uiBufferSize = (uint)System.Runtime.InteropServices.Marshal.SizeOf(m_ShowString);
            m_ShowString.uiSize = uiBufferSize;
            byte[] m_byShowString = StructUtil.StructToBytes(m_ShowString);
            uint uiReturn = 0u;
            bool bGetConfig = HikNetSdk.NET_DVR_GetDVRConfig(this.m_login, 1030u, this.wlzfdjdygx.WLSB.CHANNEL, m_byShowString, uiBufferSize, ref uiReturn);
            if (bGetConfig)
            {
                m_ShowString = (HikNetSdk.NET_DVR_SHOWSTRING_V30)StructUtil.BytesToStruct(m_byShowString, m_ShowString.GetType());
            }
            if (m_ShowString.struStringInfo == null)
            {
                return false;
            }
            m_ShowString.struStringInfo[2].usShowString = 0;
            m_ShowString.struStringInfo[2].usShowStringTopLeftX = 0;
            m_ShowString.struStringInfo[2].usShowStringTopRightY = 0;
            m_ShowString.struStringInfo[2].usStringSize = 0;
            m_ShowString.struStringInfo[2].strString = "";
            m_ShowString.struStringInfo[3].usShowString = 0;
            m_ShowString.struStringInfo[3].usShowStringTopLeftX = 0;
            m_ShowString.struStringInfo[3].usShowStringTopRightY = 0;
            m_ShowString.struStringInfo[3].usStringSize = 0;
            m_ShowString.struStringInfo[3].strString = "";
            if (!HikNetSdk.NET_DVR_SetDVRConfig(this.m_login, 1031u, this.wlzfdjdygx.WLSB.CHANNEL, StructUtil.StructToBytes(m_ShowString), uiBufferSize))
            {
                uint error = HikNetSdk.NET_DVR_GetLastError();
                log.ErrorFormat("字符清空失败，错误号为：{0}", error);
                return false;
            }
            return true;
        }
        public override bool ClearAll()
        {
            if (!this.bLogin)
            {
                return false;
            }
            HikNetSdk.NET_DVR_SHOWSTRING_V30 m_ShowString = default(HikNetSdk.NET_DVR_SHOWSTRING_V30);
            uint uiBufferSize = (uint)System.Runtime.InteropServices.Marshal.SizeOf(m_ShowString);
            m_ShowString.uiSize = uiBufferSize;
            byte[] m_byShowString = StructUtil.StructToBytes(m_ShowString);
            uint uiReturn = 0u;
            bool bGetConfig = HikNetSdk.NET_DVR_GetDVRConfig(this.m_login, 1030u, this.wlzfdjdygx.WLSB.CHANNEL, m_byShowString, uiBufferSize, ref uiReturn);
            if (bGetConfig)
            {
                m_ShowString = (HikNetSdk.NET_DVR_SHOWSTRING_V30)StructUtil.BytesToStruct(m_byShowString, m_ShowString.GetType());
            }
            if (m_ShowString.struStringInfo == null)
            {
                return false;
            }
            m_ShowString.struStringInfo[1].usShowString = 0;
            m_ShowString.struStringInfo[1].usShowStringTopLeftX = 0;
            m_ShowString.struStringInfo[1].usShowStringTopRightY = 0;
            m_ShowString.struStringInfo[1].usStringSize = 0;
            m_ShowString.struStringInfo[1].strString = "";
            m_ShowString.struStringInfo[2].usShowString = 0;
            m_ShowString.struStringInfo[2].usShowStringTopLeftX = 0;
            m_ShowString.struStringInfo[2].usShowStringTopRightY = 0;
            m_ShowString.struStringInfo[2].usStringSize = 0;
            m_ShowString.struStringInfo[2].strString = "";
            m_ShowString.struStringInfo[3].usShowString = 0;
            m_ShowString.struStringInfo[3].usShowStringTopLeftX = 0;
            m_ShowString.struStringInfo[3].usShowStringTopRightY = 0;
            m_ShowString.struStringInfo[3].usStringSize = 0;
            m_ShowString.struStringInfo[3].strString = "";
            if (!HikNetSdk.NET_DVR_SetDVRConfig(this.m_login, 1031u, this.wlzfdjdygx.WLSB.CHANNEL, StructUtil.StructToBytes(m_ShowString), uiBufferSize))
            {
                uint error = HikNetSdk.NET_DVR_GetLastError();
                log.ErrorFormat("字符清空失败，错误号为：{0}", error);
                return false;
            }
            return true;
        }
        public override bool SetCharacter(DjMessage djmsg)
        {
            base.SetCharacter(djmsg);
            if (this.wlzfdjdygx == null)
            {
                return false;
            }
            if (!this.bLogin)
            {
                return false;
            }
            HikNetSdk.NET_DVR_SHOWSTRING_V30 m_ShowString = default(HikNetSdk.NET_DVR_SHOWSTRING_V30);
            uint uiBufferSize = (uint)System.Runtime.InteropServices.Marshal.SizeOf(m_ShowString);
            m_ShowString.uiSize = uiBufferSize;
            byte[] m_byShowString = StructUtil.StructToBytes(m_ShowString);
            uint uiReturn = 0u;
            bool bGetConfig = HikNetSdk.NET_DVR_GetDVRConfig(this.m_login, 1030u, this.wlzfdjdygx.WLSB.CHANNEL, m_byShowString, uiBufferSize, ref uiReturn);
            if (bGetConfig)
            {
                m_ShowString = (HikNetSdk.NET_DVR_SHOWSTRING_V30)StructUtil.BytesToStruct(m_byShowString, m_ShowString.GetType());
            }
            if (m_ShowString.struStringInfo == null)
            {
                return false;
            }
            if (djmsg.Czybm != null || djmsg.Czybm != "0")
            {
                m_ShowString.struStringInfo[1].usShowString = 1;
                m_ShowString.struStringInfo[1].usShowStringTopLeftX = (ushort)this.wlzfdjdygx.ZBXX.CZYBM_DJZB_X.Value;
                m_ShowString.struStringInfo[1].usShowStringTopRightY = (ushort)this.wlzfdjdygx.ZBXX.CZYBM_DJZB_Y.Value;
                string strCmd = djmsg.Czybm + " " + djmsg.Czyxm;
                m_ShowString.struStringInfo[1].usStringSize = (ushort)System.Text.Encoding.Default.GetBytes(strCmd).Length;
                m_ShowString.struStringInfo[1].strString = strCmd;
            }
            if (!string.IsNullOrEmpty(djmsg.Lkzjhm) && djmsg.Lkzjhm != "0")
            {
                m_ShowString.struStringInfo[2].usShowString = 1;
                m_ShowString.struStringInfo[2].usShowStringTopLeftX = (ushort)this.wlzfdjdygx.ZBXX.LKZJHM_DJZB_X.Value;
                m_ShowString.struStringInfo[2].usShowStringTopRightY = (ushort)this.wlzfdjdygx.ZBXX.LKZJHM_DJZB_Y.Value;
                string strCmd2 = string.Concat(new string[]
				{
					djmsg.Lkzjhm,
					" ",
					djmsg.Lkxm,
				});
                m_ShowString.struStringInfo[2].usStringSize = (ushort)System.Text.Encoding.Default.GetBytes(strCmd2).Length;
                m_ShowString.struStringInfo[2].strString = strCmd2;
            }
            if (!string.IsNullOrEmpty(djmsg.CSRQ) && djmsg.CSRQ != "0")
            {
                m_ShowString.struStringInfo[3].usShowString = 1;
                m_ShowString.struStringInfo[3].usShowStringTopLeftX = (ushort)this.wlzfdjdygx.ZBXX.LKPJXX_DJZB_X.Value;
                m_ShowString.struStringInfo[3].usShowStringTopRightY = (ushort)this.wlzfdjdygx.ZBXX.LKPJXX_DJZB_Y.Value;
                string strCmd3 = string.Concat(new string[]
				{
					djmsg.CSRQ,
					" ",
					djmsg.Lkgj,
				});
                m_ShowString.struStringInfo[3].usStringSize = (ushort)System.Text.Encoding.Default.GetBytes(strCmd3).Length;
                m_ShowString.struStringInfo[3].strString = strCmd3;
            }
            if (HikNetSdk.NET_DVR_SetDVRConfig(this.m_login, 1031u, this.wlzfdjdygx.WLSB.CHANNEL, StructUtil.StructToBytes(m_ShowString), uiBufferSize))
            {
                if (SetCharacterFactory.IsTgtp)
                {
                    string sJpegPicFileName;
                    //图片保存路径和文件名 the path and file name to save
                    sJpegPicFileName = SetCharacterFactory.ztlj + djmsg.WYBS + ".jpg";

                    HikNetSdk.NET_DVR_JPEGPARA lpJpegPara = new HikNetSdk.NET_DVR_JPEGPARA();
                    lpJpegPara.wPicQuality = 0; //图像质量 Image quality
                    lpJpegPara.wPicSize = 0xff; //抓图分辨率 Picture size: 2- 4CIF，0xff- Auto(使用当前码流分辨率)，抓图分辨率需要设备支持，更多取值请参考SDK文档

                    if (!HikNetSdk.NET_DVR_CaptureJPEGPicture(this.m_login, this.wlzfdjdygx.WLSB.CHANNEL, ref lpJpegPara, sJpegPicFileName))
                    {
                        uint error = HikNetSdk.NET_DVR_GetLastError();
                        log.ErrorFormat("抓图失败，错误号为：{0}", error);
                        return false;
                    } 
                }
            }
            else
            {
                uint error = HikNetSdk.NET_DVR_GetLastError();
                log.ErrorFormat("字符叠加失败，错误号为：{0}", error);
                return false;
            }
            return true;
        }
        public override bool Dispose()
        {
            return this.ClearAll();
        }
    }
}
