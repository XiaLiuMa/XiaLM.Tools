﻿using System;

namespace Isolator.SetCharacter.Mod
{
    /// <summary>
    /// 坐标信息实体类
    /// </summary>
    public class ZBXX
    {
        /// <summary>
        /// 操作员代码X坐标
        /// </summary>
        public int? CZYDM_DJZB_X
        {
            get;
            set;
        }

        /// <summary>
        /// 操作员代码Y坐标
        /// </summary>
        public int? CZYDM_DJZB_Y
        {
            get;
            set;
        }

        /// <summary>
        /// 操作员姓名X坐标
        /// </summary>
        public int? CZYXM_DJZB_X
        {
            get;
            set;
        }

        /// <summary>
        /// 操作员姓名Y坐标
        /// </summary>
        public int? CZYXM_DJZB_Y
        {
            get;
            set;
        }

        /// <summary>
        /// 操作员部门X坐标
        /// </summary>
        public int? CZYBM_DJZB_X
        {
            get;
            set;
        }

        /// <summary>
        /// 操作员部门Y坐标
        /// </summary>
        public int? CZYBM_DJZB_Y
        {
            get;
            set;
        }

        /// <summary>
        /// 旅客证件号码X坐标
        /// </summary>
        public int? LKZJHM_DJZB_X
        {
            get;
            set;
        }

        /// <summary>
        /// 旅客证件号码Y坐标
        /// </summary>
        public int? LKZJHM_DJZB_Y
        {
            get;
            set;
        }

        /// <summary>
        /// 旅客姓名X坐标
        /// </summary>
        public int? LKXM_DJZB_X
        {
            get;
            set;
        }

        /// <summary>
        /// 旅客姓名Y坐标
        /// </summary>
        public int? LKXM_DJZB_Y
        {
            get;
            set;
        }

        /// <summary>
        /// 旅客评价内容X坐标
        /// </summary>
        public int? LKPJXX_DJZB_X
        {
            get;
            set;
        }

        /// <summary>
        /// 旅客评价内容Y坐标
        /// </summary>
        public int? LKPJXX_DJZB_Y
        {
            get;
            set;
        }

        /// <summary>
        /// 旅客国籍X坐标
        /// </summary>
        public int? LKGJ_DJZB_X
        {
            get;
            set;
        }

        /// <summary>
        /// 旅客国籍内容Y坐标
        /// </summary>
        public int? LKGJ_DJZB_Y
        {
            get;
            set;
        }

        /// <summary>
        /// 航班号X坐标
        /// </summary>
        public int? JTGJ_DJZB_X
        {
            get;
            set;
        }

        /// <summary>
        /// 航班号内容Y坐标
        /// </summary>
        public int? JTGJ_DJZB_Y
        {
            get;
            set;
        }
    }
}
