﻿using Jobs_Common;
using Quartz;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.Service.Quarz;
using System;
using System.Collections.Generic;

/**
 * 使用Quart.net需要注意的地方
 * 
 * 1: 关于IJob继承类属性和参数的问题
 * 我们给scheduler传入了一个JobDetail实例，而且这个JobDetail实例只是简单提供了类名来引用被执行的Job。
 * 每次scheduler执行这个任务时，它就创建这个类的新实例，然后调用该实例的Execute(..)方法。
 * 对这种行为的一个推论就是Job类必须有一个无参数的构造函数。
 * 另外一个推论就是它使得Job类中定义的成员数据失去意义，因为这些成员数据值在每次执行的时候被“清空”了。
 * 因此我们可以使用JobDataMap来转递和跟踪Job的状态
 * 
 * 2：JobDataMap介绍
 * JobDataMap被用来保存一系列的（序列化的）对象，这些对象在Job执行时可以得到。
 * JobDataMap是IDictionary接口的一个实现，而且还增加了一些存储和读取主类型数据的便捷方法。
 * 
 * 3: 任务分为有状态和与无状态两种。
 * 任务在每次都调度时，都会重新被实例化。因此无法保存任何状态信息。所以我们可将
 * 
 * 4:[PersistJobDataAfterExecution]
 * 此标记说明在执行完Job的execution方法后保存JobDataMap当中固定数据,
 * 在默认情况下 也就是没有设置 [PersistJobDataAfterExecution]的时候 每个job都拥有独立JobDataMap
 * 
 * 5:[DisallowConcurrentExecution]
 * 此标记用在实现Job的类上面,意思是不允许并发执行,按照我之前的理解是 
 * 不允许调度框架在同一时刻调用Job类，后来经过测试发现并不是这样，
 * 而是Job(任务)的执行时间[比如需要10秒]大于任务的时间间隔[Interval（5秒)],
 * 那么默认情况下,调度框架为了能让 任务按照我们预定的时间间隔执行,会马上启用新的线程执行任务。
 * 否则的话会等待任务执行完毕以后 再重新执行！（这样会导致任务的执行不是按照我们预先定义的时间间隔执行）
 * 
 * 假如某任务被设定的时间间隔为3秒,但job执行时间是5秒,
 * 设置@DisallowConcurrentExecution以后程序会等任务执行完毕以后再去执行,否则会在3秒时再启用新的线程执行
 * */

namespace Jobs_KNYFTJ
{
    /// <summary>
    /// 口岸验放统计调度任务
    /// LED勤务数据获取任务
    /// DisallowConcurrentExecution表示不接收并发运行。
    /// 保证此任务不管什么时候，此任务只被一个调度器线程运行。
    /// 当此次调度未完成时，下一次到来的调度任务则在线程池中等待。
    /// </summary>
    [PersistJobDataAfterExecution]
    [DisallowConcurrentExecution]//，由程序来控制任何时间任务只被一次调用，防止线程池中待运行任务过多
    public class KNYFTJJobs : AbstractQuarztJob//IJob
    {
        #region IJob 成员

        /// <summary>
        /// 调度任务入口
        /// </summary>
        /// <param name="context"></param>       
        public override void Run(IJobExecutionContext context)
        {
            try
            {
                foreach (ISqlOperate sql in LstSqlOperate)
                {
                    SecheduleKadryfTj(sql);
                }
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region //口岸出入境人员数据统计

        /// <summary>
        /// 按口岸统计每日出入境人数,只统计当天当前的数据
        /// </summary>
        private void SecheduleKadryfTj(ISqlOperate sql)
        {
            string cmdText = string.Format(GlobalJobs.GetSql("KADRYFTJ"), DateTime.Now.ToString("yyyyMMdd"));           
          
            List<Dictionary<string, object>> lst = SqlUtil.Select(cmdText,sql);
            IsolatorUtil.SendOneTime(lst, "KNYFTJ", 06, GlobalJobs.MaxSendCount);                
        }

        #endregion
    }
}
