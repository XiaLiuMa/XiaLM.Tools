﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Runtime.ExceptionServices;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Primitives;
using Schedule.Common.SqlHelp;
using Schedule.Common.SqlHelp.Impl;
using Schedule.Engine.Model;
using Schedule.model.common;

namespace Schedule.Engine.Core
{
    /// <summary>
    /// 数据库
    /// </summary>
    public class DbConfigRepertory : IDisposable
    {
        static List<DataBase> dbconfigs = new List<DataBase>();
        static string dbConfigPath = @"Config/DataBaseConfig.xml";
        static List<DataBaseEX> dbconfigEXs = new List<DataBaseEX>();
        //HostFileChangeMonitor monitor;
        IFileProvider fileProvider;

        public static List<Dictionary<string, object>> SelectData(String sql)
        {
            return SqlUtil.Select(sql, getDafaultSqlOperate());
        }

        public void init()
        {
            fileProvider = new PhysicalFileProvider(AppDomain.CurrentDomain.BaseDirectory);
            ChangeToken.OnChange(() => fileProvider.Watch(dbConfigPath), () => OnChangedCallback(fileProvider));

            //monitor = new HostFileChangeMonitor(new List<string>() {
            //    AppDomain.CurrentDomain.BaseDirectory+dbConfigPath
            //});
            //monitor.NotifyOnChanged(OnChangedCallback);

            getdbconfigs();
        }

        private void OnChangedCallback(object state)
        {
            getdbconfigs();
        }

        [HandleProcessCorruptedStateExceptions]
        private void getdbconfigs()
        {
            dbconfigs = SerializationHelper.Load<List<DataBase>>(AppDomain.CurrentDomain.BaseDirectory + dbConfigPath);
            dbconfigEXs.Clear();
            foreach (var item in dbconfigs)
            {
                var obj = new DataBaseEX(item);
                obj.connstr = new Lazy<ISqlOperate>(() =>
                {
                    string serverIp = item.ServerIp;
                    string serverPort = item.ServerPort;

#if !DEBUG
                    string strP = @"#SZSSKJ#{0}^{1}#SZSSKJ@";
                    string strPP = string.Format(strP, serverIp, serverPort);
                    string strRe = string.Empty;
                    bool re = false;
                    try
                    {
                        re = DLL.GetSvrConfigInfo(strPP, ref strRe);
                    }
                    catch (Exception ex)
                    {
                        throw;
                    }
                    if (re)
                    {
                        string[] aa = strRe.Split('^');

                        if (aa != null && aa.Length == 3)
                        {
                            string strDataSource = aa[0];
                            string strUid = aa[1];
                            string strPwd = aa[2];
                            string conStr = "Provider=MSDAORA;User ID=" + strUid + ";Password=" + strPwd + ";Data Source=(DESCRIPTION = (ADDRESS_LIST= (ADDRESS = (PROTOCOL = TCP)(HOST = " + serverIp + ")(PORT = 1521))) (CONNECT_DATA = (SERVICE_NAME = " + serverIp + ")))";

                            ISqlOperate sqlOperate = new OracleSqlOperate();
                            sqlOperate.DbConStr = conStr;


                            return sqlOperate;
                        }
                    } 
                                        return null;
#else
                    string conStr = "Provider=MSDAORA;User ID=qgtg;Password=qgtg;Data Source=(DESCRIPTION = (ADDRESS_LIST= (ADDRESS = (PROTOCOL = TCP)(HOST = " + serverIp + ")(PORT = 65001))) (CONNECT_DATA = (SERVICE_NAME = " + serverIp + ")))";

                    ISqlOperate sqlOperate = new OracleSqlOperate();
                    sqlOperate.DbConStr = conStr;

                    return sqlOperate;
#endif
                });

                dbconfigEXs.Add(obj);
            }
        }

        public static ISqlOperate getDafaultSqlOperate()
        {
            if (dbconfigEXs.Any())
            {
                ISqlOperate defaultSql = dbconfigEXs.First().sqlOperate;

                var obj = dbconfigEXs.LastOrDefault(c => c.Default).sqlOperate;
                if (obj != null)
                {
                    defaultSql = obj;
                }
                return defaultSql;
            }
            return null;
        }

        public static List<ISqlOperate> getISqlOperater(string ids)
        {
            try
            {
                string[] idsArray = ids.Split(',');

                return dbconfigEXs.Where(p => idsArray.Contains(p.ID.ToString())).Select(p => p.sqlOperate).ToList();
            }
            catch (Exception EX)
            {

                throw EX;
            }
        }




        public void Dispose()
        {
            //monitor.Dispose();
            dbconfigs.Clear();
            dbconfigEXs.Clear();

        }
    }
    public class DataBaseEX : DataBase
    {
        public DataBaseEX(DataBase dbInfo)
        {
            this.ID = dbInfo.ID;
            this.ServerIp = dbInfo.ServerIp;
            this.ServerPort = dbInfo.ServerPort;
            this.Default = dbInfo.Default;



        }
        internal Lazy<ISqlOperate> connstr;


        public ISqlOperate sqlOperate { get { return connstr.Value; } }
    }
}
