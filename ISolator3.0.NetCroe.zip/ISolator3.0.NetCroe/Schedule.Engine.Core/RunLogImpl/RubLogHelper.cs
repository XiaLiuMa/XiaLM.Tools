﻿using DAL.AccessDAL;
using DAL.IDAL;
using DAL.Mod;
using Schedule.Engine.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schedule.Engine.Core.RunLogImpl
{
    public class JobLogHelper
    {
        public static IRunLogDAL DALRunLog = new RunLogSqliteDAL();

        /// <summary>
        /// 添加运行日志
        /// </summary>
        /// <param name="runLog">运行日志</param>
        public static void AddRunLog(RunLogDto runLog)
        {
            RunLog l = new RunLog();
            l.JobName = runLog.JobName;
            l.StartTime = runLog.StartTime;
            l.EndTime = runLog.EndTime;
            l.ReMark = runLog.ReMark;

            DALRunLog.Add(l);
        }
    }
}
