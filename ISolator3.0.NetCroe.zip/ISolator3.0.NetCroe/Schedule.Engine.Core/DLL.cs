﻿using System.Runtime.InteropServices;

namespace Schedule.Engine.Core
{

    public static class DLL
    {
        private const string strDllPath = @"DLL\BJVerify.dll";

        [DllImport(strDllPath)]
        public extern static bool GetSvrConfigInfo(string PChar, ref string Info);
    }
}
