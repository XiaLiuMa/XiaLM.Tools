﻿using Schedule.Common.Util;
using Schedule.Engine.Core.Service;
using Schedule.Engine.Core.Service.Quarz;
using Schedule.Engine.Model;
using Schedule.model.common;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using Schedule.Common.log;
using System.IO;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Primitives;

namespace Schedule.Engine.Core
{
    /// <summary>
    /// 任务仓库
    /// </summary>
    public class JobRepertory : IDisposable
    {
        /// <summary>
        /// 本地dll
        /// </summary>
        private static ConcurrentDictionary<string, object> _LocalJob = new ConcurrentDictionary<string, object>();

        private static List<ScheduleServiceConfig> _runScheduleConfig = new List<ScheduleServiceConfig>();

        private static readonly string ScheduleServiceConfigPath = @"Config\QuartzByCron.xml";

        //HostFileChangeMonitor monitor;
        IFileProvider fileProvider; //UNDONE:（不确定是否可行）

        /// <summary>
        /// 正在运行的调度任务集合
        /// </summary>
        public static Lazy<List<string>> RuningSchedule = new Lazy<List<string>>();

        public void init()
        {
            _LocalJob.Clear();
            _runScheduleConfig.Clear();
            var ScheduleServicesDefin = ReflectionUtil.FindSubClasses(typeof(IScheduleService));

            var jobDefines = ScheduleServicesDefin;

            foreach (var item in jobDefines)
            {
                if (!item.IsSealed)
                {
                    var obj = Activator.CreateInstance(item);

                    string fullName = item.FullName;
                    _LocalJob.AddOrUpdate(fullName, obj, (key, instance) =>
                    {
                        return instance;
                    });
                }
            }
            //monitor = new HostFileChangeMonitor(new List<string>() {
            //    AppDomain.CurrentDomain.BaseDirectory+ScheduleServiceConfigPath
            //});
            //monitor.NotifyOnChanged(OnChangedCallback);

            fileProvider = new PhysicalFileProvider(AppDomain.CurrentDomain.BaseDirectory);
            ChangeToken.OnChange(() => fileProvider.Watch(ScheduleServiceConfigPath), () => OnChangedCallback(fileProvider));

            startQz();
        }
        string jobName = "";
        private void startQz()
        {
            try
            {
                List<ScheduleServiceConfig> newlist = getConfigJob();

                var clist = Listcompare.Listcompare.Merge(_runScheduleConfig, newlist, p => p.ID, new configCompare());

                foreach (var changeditem in clist)
                {
                    if (_LocalJob.ContainsKey(changeditem.item.typeName))
                    {
                        var c = _LocalJob[changeditem.item.typeName] as IScheduleService;
                        if (changeditem.rowState == System.Data.DataRowState.Added || changeditem.rowState == System.Data.DataRowState.Modified)
                        {
                            if (c.IsQuarz)
                            {
                                var Schedule = c as AbstractScheduleService;
                                if (!string.IsNullOrEmpty(changeditem.item.Expresstion))
                                {
                                    Schedule.CronExpressionString = changeditem.item.Expresstion;
                                }

                                if (changeditem.item.state)
                                {
                                    Schedule.LstSqlOperate = DbConfigRepertory.getISqlOperater(changeditem.item.Conn);

                                    Schedule.Start();
                                }
                                else
                                {
                                    Schedule.Stop();
                                }
                            }
                            else
                            {
                                if (changeditem.item.state)
                                {
                                    c.LstSqlOperate = DbConfigRepertory.getISqlOperater(changeditem.item.Conn);
                                    c.Start();
                                }
                                else
                                {
                                    c.Stop();
                                }
                            }
                        }
                        else if (changeditem.rowState == System.Data.DataRowState.Deleted)
                        {
                            c.Stop();
                        }
                    }
                }
                _runScheduleConfig = new List<ScheduleServiceConfig>(newlist);
            }
            catch (Exception ex)
            {
                LogHelp.Error(this.GetType(), ex);
            }
        }

        private static List<ScheduleServiceConfig> getConfigJob()
        {
            return SerializationHelper.Load<List<ScheduleServiceConfig>>(AppDomain.CurrentDomain.BaseDirectory + ScheduleServiceConfigPath);
        }

        private void OnChangedCallback(object state)
        {
            startQz();

            //monitor = new HostFileChangeMonitor(new List<string>() {
            //    AppDomain.CurrentDomain.BaseDirectory+ScheduleServiceConfigPath
            //});
            //monitor.NotifyOnChanged(OnChangedCallback);

            fileProvider = new PhysicalFileProvider(AppDomain.CurrentDomain.BaseDirectory + @"Config/");
            ChangeToken.OnChange(() => fileProvider.Watch(ScheduleServiceConfigPath), () => OnChangedCallback(fileProvider));

            
        }

        class configCompare : EqualityComparer<ScheduleServiceConfig>
        {
            public override bool Equals(ScheduleServiceConfig x, ScheduleServiceConfig y)
            {
                return x.ID == y.ID && x.Expresstion == y.Expresstion && x.state == y.state && x.typeName == y.typeName && x.Conn == y.Conn;
            }

            public override int GetHashCode(ScheduleServiceConfig obj)
            {
                return obj.GetHashCode();
            }
        }

        public static void Stop()
        {
            List<ScheduleServiceConfig> newlist = getConfigJob();

            foreach (var changeditem in newlist)
            {
                if (_LocalJob.ContainsKey(changeditem.typeName))
                {
                    var c = _LocalJob[changeditem.typeName] as IScheduleService;
                    if (c.IsQuarz)
                    {
                        var Schedule = c as AbstractScheduleService;

                        Schedule.Stop();
                    }
                    else
                    {
                        c.Stop();
                    }
                }
            }
        }

        public void Dispose()
        {
            //monitor.Dispose();
            _LocalJob.Clear();
            _runScheduleConfig.Clear();
        }
    }
}
