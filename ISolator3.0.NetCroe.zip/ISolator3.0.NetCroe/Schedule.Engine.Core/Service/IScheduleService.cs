﻿using Schedule.Common.SqlHelp;
using System.Collections.Generic;

namespace Schedule.Engine.Core.Service
{
    // public interfaces...
    /// <summary>
    /// 调度服务接口。此接口为逆变接口
    /// 定义：
    /// 协变：如果一个泛型接口IFoo<T>，IFoo<TSub>可以转换为IFoo<TParent>的话，我们称这个过程为协变，IFoo支持对参数T的协变。
    /// 逆变：如果一个泛型接口IFoo<T>，IFoo<TParent>可以转换为IFoo<TSub>的话，我们称这个过程为逆变，IFoo支持对参数T的逆变。
    /// 注意：
    /// 接口在定义协变和逆变时。
    /// 1：支持协变的参数只能用于方法的返回值
    /// 2：支持逆变的参数只能用于方法参数？
    /// </TSub>
    /// </TParent></T></TParent></TSub></T></summary>
    public interface IScheduleService
    {
        // properties...
        /// <summary>
        /// 数据库操作接口
        /// </summary>
        List<ISqlOperate> LstSqlOperate { get; set; }
        /// <summary>
        /// 获取当前服务名称。不同的服务名称不能相同
        /// </summary>
        string ServiceName { get; }

        // methods...
        /// <summary>
        /// 类说明，做为调度器名称
        /// </summary>
        /// <returns></returns>
        string ClassNote();
        /// <summary>
        /// 启动调度服务
        /// </summary>
        void Start();
        /// <summary>
        /// 停止服务
        /// </summary>
        void Stop();

        /// <summary>
        /// 是否为Quarz调度服务
        /// </summary>
        bool IsQuarz { get; }
    }
}
