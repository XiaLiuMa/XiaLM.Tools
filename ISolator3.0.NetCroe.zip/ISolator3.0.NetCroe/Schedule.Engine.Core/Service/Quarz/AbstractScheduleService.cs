﻿using Quartz;
using Quartz.Impl;
using Quartz.Impl.Triggers;
using Schedule.Common.Service;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Schedule.Engine.Core.Service.Quarz
{
    // public classes...
    /// <summary>
    /// 抽象的Quarzt调度任务。其余Quarzt调试任务继承此类
    /// </summary>
    public abstract class AbstractScheduleService : IScheduleService, IQuarztService
    {
        // private fields...
        /// <summary>
        /// CRON表达式
        /// </summary>
        private string cronExpressionString;

        /// <summary>
        /// 调度任务信息封装
        /// </summary>
        private IJobDetail JobDetail;

        /// <summary>
        /// 调度器
        /// </summary>
        public static IScheduler scheduler;

        /// <summary>
        /// 调试任务触发器
        /// </summary>
        private CronTriggerImpl trigger = null;

        // public properties...
        /// <summary>
        /// CRON表达式
        /// </summary>
        public string CronExpressionString
        {
            set
            {
                cronExpressionString = value;
            }
            get
            {
                return cronExpressionString;
            }
        }

        /// <summary>
        /// 获取或设置数据库操作
        /// </summary>
        public List<ISqlOperate> LstSqlOperate
        {
            get;
            set;
        }

        /// <summary>
        /// 调度器
        /// </summary>
        public IScheduler Scheduler
        {
            set
            {
                scheduler = value;
            }
            get
            {
                return scheduler;
            }
        }

        /// <summary>
        /// 当前调度服务名称
        /// </summary>
        public abstract string ServiceName { get; }

        /// <summary>
        /// 调度任务触发器
        /// </summary>
        public CronTriggerImpl Trigger
        {
            set
            {
                trigger = value;
            }
            get
            {
                return trigger;
            }
        }

        // public methods...
        /// <summary>
        /// 类说明，做为调度器名称
        /// </summary>
        /// <returns></returns>
        public abstract string ClassNote();

        /// <summary>
        /// 获取当前任务类型
        /// </summary>
        /// <returns></returns>
        public abstract Type GetJobType();

        private static SpinLock slock = new SpinLock(false);

        /// <summary>
        /// 启动调度服务
        /// </summary>
        public void Start()
        {
            bool lockTaken = false;
            try
            {
                slock.TryEnter(2000, ref lockTaken);
                if (lockTaken)
                {
                    if (scheduler == null)
                    {
                        ISchedulerFactory sf = new StdSchedulerFactory();
                        scheduler = sf.GetScheduler().Result;
                        scheduler.Start();
                    }
                    if (JobDetail == null)
                    {
                        var jobName = ServiceName + StringUtil.GetGuid();
                        JobDetail = new JobDetailImpl(jobName, GetJobType());
                        JobDetail.JobDataMap.Add("ISqlOperate", LstSqlOperate);
                        JobDetail.JobDataMap.Add("IsRuning", "false");
                        JobDetail.JobDataMap.Add("ServiceName", ServiceName);
                        JobDetail.JobDataMap.Add("ClassNote", ClassNote());

                        if (trigger == null)
                        {
                            var triggerName = ServiceName + "Trigger" + StringUtil.GetGuid();
                            var cronTrigger = new CronTriggerImpl(triggerName);
                            cronTrigger.CronExpressionString = CronExpressionString;
                            trigger = cronTrigger;
                        }
                        if (!scheduler.CheckExists(JobDetail.Key).Result && !scheduler.CheckExists(trigger.Key).Result)
                        {
                            scheduler.ScheduleJob(JobDetail, trigger);
                        }
                    }
                    else if (JobDetail != null && trigger != null)
                    {
                        if (trigger.CronExpressionString != cronExpressionString)
                        {
                            trigger.CronExpressionString = cronExpressionString;
                            if (scheduler.CheckExists(JobDetail.Key).Result)
                            {
                                scheduler.DeleteJob(JobDetail.Key);
                                scheduler.ScheduleJob(JobDetail, trigger);
                            }
                        }
                        else
                        {
                            if (!scheduler.CheckExists(JobDetail.Key).Result && !scheduler.CheckExists(trigger.Key).Result)
                            {
                                scheduler.ScheduleJob(JobDetail, trigger);
                            }
                            else if (scheduler.CheckExists(JobDetail.Key).Result && scheduler.CheckExists(trigger.Key).Result)
                            {
                                scheduler.ResumeJob(JobDetail.Key);
                            }
                        }
                    }
                    //scheduler.TriggerJob(JobDetail.Key);
                    JobRepertory.RuningSchedule.Value.Add(ServiceName);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                if (lockTaken)
                {
                    slock.Exit(false);
                }
            }
        }

        /// <summary>
        /// 停止调度服务
        /// </summary>
        public void Stop()
        {
            if (JobDetail != null && scheduler.CheckExists(JobDetail.Key).Result && trigger != null && scheduler.CheckExists(trigger.Key).Result)
            {
                scheduler.PauseJob(JobDetail.Key);
                JobRepertory.RuningSchedule.Value.Remove(ServiceName);
            }
        }

        /// <summary>
        /// 移除调度任务
        /// </summary>
        public void Delete()
        {
            if (JobDetail != null && scheduler.CheckExists(JobDetail.Key).Result && trigger != null && scheduler.CheckExists(trigger.Key).Result)
            {
                scheduler.DeleteJob(JobDetail.Key);
                JobRepertory.RuningSchedule.Value.Remove(ServiceName);
            }
        }

        /// <summary>
        /// 是否为Quarz调度任务
        /// </summary>
        public bool IsQuarz
        {
            get { return true; }
        }

        /// <summary>
        /// 调度任务状态
        /// </summary>
        public bool IsRuning
        {
            get { return JobDetail != null && scheduler.GetJobDetail(JobDetail.Key) != null; }
        }
    }
}
