﻿using Quartz;
using Quartz.Impl.Triggers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schedule.Engine.Core.Service.Quarz
{
    // public interfaces...
    /// <summary>
    /// QUERZT
    /// </summary>
    public interface IQuarztService
    {
        // properties...
        /// <summary>
        /// CRON表达式
        /// </summary>
        string CronExpressionString { get; set; }
        /// <summary>
        /// 设置或获取作业调度器
        /// </summary>
        IScheduler Scheduler { get; set; }

        /// <summary>
        /// 调度任务触发器
        /// </summary>
        CronTriggerImpl Trigger { get; set; }
    }
}
