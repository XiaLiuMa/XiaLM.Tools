﻿using Schedule.Common.SqlHelp;
using Schedule.Engine.Core.Service.Engines.CycleEngine;
using System;
using System.Collections.Generic;

namespace Schedule.Engine.Core.Service.Engines
{
    public abstract class AbstractEngineService : IScheduleService
    {
        public List<ISqlOperate> LstSqlOperate
        {
            get;
            set;
        }

        public abstract string ServiceName
        {
            get;
        }

        /// <summary>
        /// 调度任务
        /// </summary>
        public abstract BaseCycleEngine Job { get; }

        /// <summary>
        /// 执行时间间隔
        /// </summary>
        public virtual int SpanInSecs 
        {
            get 
            { 
                return 1; 
            }
        }

        public abstract string ClassNote();

        public void Start()
        {
            try
            {
                if (Job != null)
                {
                    if (Job.EngineMap == null)
                    {
                        Job.EngineMap = new Dictionary<string, object>();

                        Job.EngineMap.Add("ServiceName", ServiceName);
                        Job.EngineMap.Add("ClassNote", ClassNote());
                        Job.LstSqlOperate = LstSqlOperate;
                        //轮循间隔时间为1秒。
                        Job.DetectSpanInSecs = 1;
                    }
                    if (!Job.IsRuning)
                    {
                        Job.Start();
                        JobRepertory.RuningSchedule.Value.Add(ServiceName);
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void Stop()
        {
            if (Job != null && Job.IsRuning)
            {
                Job.Stop();
                JobRepertory.RuningSchedule.Value.Remove(ServiceName);
            }
        }

        public bool IsQuarz
        {
            get { return false; }
        }
    }
}
