﻿using Schedule.Common.log;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.RunLogImpl;
using Schedule.Engine.Model;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

// namespaces...
namespace Schedule.Engine.Core.Service.Engines.CycleEngine
{
    // public classes...
    /// <summary>
    /// ICycleEngine的抽象实现，循环引擎直接继承它并实现DoDetect方法即可。
    /// </summary>
    public abstract class BaseCycleEngine : ICycleEngine
    {
        // const fields...
        /// <summary>
        /// 线程每次暂停时间为一秒
        /// </summary>
        private const int SleepTime = 1000;

        // private fields...
        private int detectSpanInSecs = 0;
        private volatile bool isRuning = false;
        private ManualResetEvent manualResetEvent4Stop = new ManualResetEvent(false);
        private int totalSleepCount = 0;


        public Dictionary<string, object> EngineMap
        {
            get;set;
        }

        public List<ISqlOperate> LstSqlOperate
        {
            get;
            set;
        }

        // public constructors...
        public BaseCycleEngine()
        {
            this.OnEngineStopped += delegate
            {
             };
        }

        // public events...
        public event Action<Exception> OnEngineStopped;

        // public properties...
        /// <summary>
        /// 引擎进行轮询的间隔，DetectSpanInSecs=0，表示无间隙运作引擎；DetectSpanInSecs小于0则表示不使用引擎
        /// </summary>
        public virtual int DetectSpanInSecs
        {
            get
            {
                return detectSpanInSecs;
            }
            set
            {
                this.detectSpanInSecs = value;
            }
        }
        public bool IsRuning
        {
            get
            {
                return isRuning;
            }
        }

        // protected methods...
        /// <summary>
        /// DoDetect 为每次循环时，引擎需要执行的核心动作。
        /// (1)该方法不允许抛出异常。
        /// (2)该方法中不允许调用BaseCycleEngine.Stop()方法，否则会导致死锁。
        /// </summary>
        /// <returns>返回值如果为false，表示退出引擎循环线程</returns>
        protected abstract bool DoDetect();
        System.Diagnostics.Stopwatch st = new System.Diagnostics.Stopwatch();
        RunLogDto dt = new RunLogDto();
        string _ClassNote;
        /// <summary>
        /// 开始执行工作引擎
        /// </summary>
        protected virtual void Run()
        {
            while (this.IsRuning)
            {
                for (var i = 0; i < this.totalSleepCount; i++)
                {
                    if (!this.IsRuning)
                    {
                        break;
                    }
                    Thread.Sleep(BaseCycleEngine.SleepTime);
                }
                try
                {
                    _ClassNote=EngineMap["ClassNote"].ToString();
#if DEBUG
                    LogHelp.Info(DateTime.Now.ToString(CalculateUtil.FormatDt) + ":开始执行，" + _ClassNote);     
#endif

                    dt.JobName = _ClassNote;
                    dt.StartTime = DateTime.Now;
                    st.Start();
                    if (!this.DoDetect())
                    {
                        this.isRuning = false;
                        break;
                    }
                    st.Stop();
                    dt.EndTime = DateTime.Now;
                    dt.ReMark = dt.JobName + "，本次执行用时:" + st.ElapsedMilliseconds + "毫秒";
                    JobLogHelper.AddRunLog(dt);
#if DEBUG
                    LogHelp.Info(DateTime.Now.ToString(CalculateUtil.FormatDt) + ":执行完成，" + _ClassNote + "用时:" + st.ElapsedMilliseconds + "毫秒");
#endif
                }
                catch (Exception ex)
                {
                    LogHelp.Error(this.GetType(),ex);
                }
            }
            this.manualResetEvent4Stop.Set();
        }

        // public methods...
        /// <summary>
        /// 启动引擎
        /// </summary>
        public virtual void Start()
        {
            this.totalSleepCount = this.detectSpanInSecs * 1000 / BaseCycleEngine.SleepTime;

            if (this.detectSpanInSecs < 0)
            {
                return;
            }

            if (this.isRuning)
            {
                return;
            }

            this.manualResetEvent4Stop.Reset();
            this.isRuning = true;

            var t = Task.Factory.StartNew(this.Run);
        }
        public virtual void Stop()
        {
            if (this.isRuning == false)
            {
                return;
            }
            this.isRuning = false;
            this.manualResetEvent4Stop.WaitOne();
            this.manualResetEvent4Stop.Reset();
        }
    }
}
