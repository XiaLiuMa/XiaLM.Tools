﻿using System;

// namespaces...
namespace Schedule.Engine.Core.Service.Engines.CycleEngine
{
    // public interfaces...
    /// <summary>
    /// 后台线程进行间隔循环的引擎
    /// </summary>
    public interface ICycleEngine
    {
        // properties...
        /// <summary>
        /// 引擎进行轮询的间隔，DetectSpanInSecs=0，表示无间隙运作引擎；DetectSpanInSecs小于0则表示不使用引擎
        /// </summary>
        int DetectSpanInSecs { get; set; }
        /// <summary>
        /// 引擎是否运行中
        /// </summary>
        bool IsRuning { get; }

        // methods...
        /// <summary>
        /// 启动后台引擎线程
        /// </summary>
        void Start();
        /// <summary>
        /// 停止后台引擎线程，只有当线程安全退出后，该方法才返回
        /// </summary>
        void Stop();

        // events...
        /// <summary>
        /// 当引擎由运行变为停止状态时，将触发此事件。如果是异常停止，则事件参数为异常对象，否则，事件参数为null。
        /// </summary>
        event Action<Exception> OnEngineStopped;
    }
}
