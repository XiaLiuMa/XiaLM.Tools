﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Schedule.Engine.Core.Listcompare
{
    public class Listcompare
    {
        public static IEnumerable<RowStateTrace<T>> Merge<T, Tkey>(List<T> oldlist, List<T> newlist, Func<T, Tkey> findkey, EqualityComparer<T> EqualityComparer)
        {
            foreach (var olditem in oldlist)
            {
                var obj = newlist.FirstOrDefault(c => findkey(c).Equals(findkey(olditem)));
                if(obj!=null)
                {
                    if (EqualityComparer.Equals(olditem, obj))
                        yield return new RowStateTrace<T> { item = olditem, rowState = System.Data.DataRowState.Unchanged };
                    else
                        yield return new RowStateTrace<T> { item =obj , rowState = System.Data.DataRowState.Modified };
                }
                else
                {
                    yield return new RowStateTrace<T>() { item = olditem, rowState = System.Data.DataRowState.Deleted };
                }
            }


            foreach (var newitem in newlist)
            {
                var obj = oldlist.FirstOrDefault(c => findkey(c).Equals(findkey(newitem)));
                if(obj==null)
                {
                    yield return new RowStateTrace<T> { item = newitem, rowState = System.Data.DataRowState.Added };
                }
                
            }
        }

    }

    public class RowStateTrace<T>
    {
        public T item { get; set; }

        public System.Data.DataRowState rowState { get; set; }
    }


    public static class listCompareEX
    {

        public static IEnumerable<RowStateTrace<T>> select<T>(this IEnumerable<RowStateTrace<T>> lst, System.Data.DataRowState rowState)
        {
            return lst.Where(c => c.rowState == rowState).ToList();
        }
    }
}
