﻿using Jobs_Common;
using Quartz;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.Service.Quarz;
using System;
using System.Collections.Generic;

namespace Jobs_KNYFTJNY
{
    /// <summary>
    /// 口岸验放统计年月调度任务
    /// </summary>
    [PersistJobDataAfterExecution]
    [DisallowConcurrentExecution]
    public class KNYFTJNYJobs : AbstractQuarztJob
    {
        #region  //自定义变量

        /// <summary>
        /// 口岸当月验放统计SQL语句
        /// </summary>
        private string strSqlTJM = string.Empty;

        /// <summary>
        /// 口岸当年验放统计SQL语句
        /// </summary>
        private string strSqlTJY = string.Empty;

        #endregion

        #region IJob 成员

        /// <summary>
        /// 调度任务入口
        /// </summary>
        /// <param name="context"></param>       
        public override void Run(IJobExecutionContext context)
        {
            try
            {
                strSqlTJM = GlobalJobs.GetSql("KADYYFTJ");
                strSqlTJY = GlobalJobs.GetSql("KADNYFTJ");
                foreach (ISqlOperate sql in LstSqlOperate)
                {
                    SecheduleKadryfTj(sql);
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region //出入境人员数据统计

        /// <summary>
        /// 统计当月、当年出入境人员数据
        /// </summary>
        private void SecheduleKadryfTj(ISqlOperate sql)
        {
            string mStart = DateTime.Now.ToString("yyyyMM01");

            string mEnd = DateTime.Now.AddDays(1).ToString("yyyyMMdd");

            mStart = "201101";
            mEnd = "201102";

            string sqlTJM = string.Format(strSqlTJM,mStart,mEnd);
            //统计当月出入境人员数据
            List<Dictionary<string, object>> lstM = SqlUtil.Select(sqlTJM, sql);
            IsolatorUtil.SendOneTime(lstM, "KNYFTJNY", 06, GlobalJobs.MaxSendCount);

            string yStart = DateTime.Now.ToString("yyyy0101");

            string yEnd = DateTime.Now.AddDays(1).ToString("yyyy1231");

            yStart = "20110101";
            yEnd = "20110631";

            string SqlTJY = string.Format(strSqlTJY, yStart, yEnd);
            //统计当年出入境人员数据
            List<Dictionary<string, object>> lstY = SqlUtil.Select(SqlTJY, sql);
            IsolatorUtil.SendOneTime(lstY, "KNYFTJNY", 06, GlobalJobs.MaxSendCount);
        }

        #endregion
    }
}
