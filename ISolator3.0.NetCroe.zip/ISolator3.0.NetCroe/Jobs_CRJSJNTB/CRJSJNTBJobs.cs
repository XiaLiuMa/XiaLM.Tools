﻿using System;
using System.Collections.Generic;

/// <summary>
/// 出入境交通年数据，出入境人员年数据，出入境交通年同比，出入境人员年同比
/// 用于武汉边检网站数据接口
/// </summary>
namespace Jobs_CRJSJNTB
{
    public class CRJSJNTBJobs : Schedule.Engine.Core.Service.Quarz.AbstractQuarztJob
    {
        public override void Run(global::Quartz.IJobExecutionContext context)
        {
            foreach (Schedule.Common.SqlHelp.ISqlOperate item in LstSqlOperate)
            {
                DoQuery(item);
            }
        }

        private void DoQuery(Schedule.Common.SqlHelp.ISqlOperate sql)
        {
            string startTime = null;
            string endTime = null;
            string strSql = null;

            Dictionary<string, object> dic = new Dictionary<string, object>();
            List<Dictionary<string, object>> lst = new List<Dictionary<string, object>>();
            List<Dictionary<string, object>> lst1 = new List<Dictionary<string, object>>();
            List<Dictionary<string, object>> lst2 = new List<Dictionary<string, object>>();
            List<Dictionary<string, object>> lst3 = new List<Dictionary<string, object>>();
            List<Dictionary<string, object>> lst4 = new List<Dictionary<string, object>>();

            try
            {
                string sql_ry = Jobs_Common.GlobalJobs.GetSql("CRJRYNTB");
                string sql_jt = Jobs_Common.GlobalJobs.GetSql("CRJJTGJNTB");

                //出入境人员前一年某时间段数据
                startTime = DateTime.Now.AddYears(-1).ToString("yyyy0101000000");
                endTime = DateTime.Now.AddYears(-1).AddDays(-1).ToString("yyyyMMdd235959");
                strSql = string.Format(sql_ry, startTime, endTime);
                lst1 = Schedule.Common.SqlHelp.SqlUtil.Select(strSql, sql);

                //出入境人员现年数据
                startTime = DateTime.Now.ToString("yyyy0101000000");
                endTime = DateTime.Now.AddDays(-1).ToString("yyyyMMdd235959");
                strSql = string.Format(sql_ry, startTime, endTime);
                lst2 = Schedule.Common.SqlHelp.SqlUtil.Select(strSql, sql);

                //出入境交通工具前一年某时间段数据
                startTime = DateTime.Now.AddYears(-1).ToString("yyyy0101000000");
                endTime = DateTime.Now.AddYears(-1).AddDays(-1).ToString("yyyyMMdd235959");
                strSql = string.Format(sql_ry, startTime, endTime);
                lst3 = Schedule.Common.SqlHelp.SqlUtil.Select(strSql, sql);

                //出入境交通工具现年数据
                startTime = DateTime.Now.ToString("yyyy0101000000");
                endTime = DateTime.Now.AddDays(-1).ToString("yyyyMMdd235959");
                strSql = string.Format(sql_ry, startTime, endTime);
                lst4 = Schedule.Common.SqlHelp.SqlUtil.Select(strSql, sql);

                //计算出入境人员、出入境交通工具年同比
                double rdu = Math.Round(Convert.ToDouble(Convert.ToInt32(lst2[0]["TJSJ"]) - Convert.ToInt32(lst1[0]["TJSJ"])) / Convert.ToInt32(lst1[0]["TJSJ"]), 2) * 100;
                double gdu = Math.Round(Convert.ToDouble(Convert.ToInt32(lst4[0]["TJSJ"]) - Convert.ToInt32(lst3[0]["TJSJ"])) / Convert.ToInt32(lst3[0]["TJSJ"]), 2) * 100;

                dic.Add("WYBS", "3F46FF87-EB1F-4AC3-BE6A-8E0FEA4078FC");
                dic.Add("LKNTB", rdu);
                dic.Add("JTNTB", gdu);
                dic.Add("NTJRS", lst2[0]["TJSJ"]);
                dic.Add("NTJJT", lst4[0]["TJSJ"]);
                lst.Add(dic);
                Schedule.Common.Util.IsolatorUtil.SendOneTime(lst, "CRJSJNTB", 254, Jobs_Common.GlobalJobs.MaxSendCount, true);
            }
            catch (Exception ex)
            {

                throw;
            }

            dic.Clear();
            lst.Clear();
            lst1.Clear();
            lst2.Clear();
            lst3.Clear();
            lst4.Clear();
        }
    }
}
