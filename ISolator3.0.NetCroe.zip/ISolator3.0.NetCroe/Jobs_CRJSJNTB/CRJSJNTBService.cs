﻿using Schedule.Engine.Core.Service.Quarz;
using System;

namespace Jobs_CRJSJNTB
{
    public class CRJSJNTBService : AbstractScheduleService
    {
        public override string ServiceName
        {
            get { return "CRJSJNTB"; }
        }

        public override string ClassNote()
        {
            return "出入境数据年同比调度服务";
        }

        public override Type GetJobType()
        {
            return typeof(CRJSJNTBJobs);
        }
    }
}
