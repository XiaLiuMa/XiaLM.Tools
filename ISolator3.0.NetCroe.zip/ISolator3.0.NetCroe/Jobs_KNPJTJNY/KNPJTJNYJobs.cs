﻿using Jobs_Common;
using Quartz;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.Service.Quarz;
using System;
using System.Collections.Generic;

namespace Jobs_KNPJTJNY
{
    /// <summary>
    /// 口岸评价统计年月调度任务
    /// </summary>
    [PersistJobDataAfterExecution]
    [DisallowConcurrentExecution]
    public class KNPJTJNYJobs : AbstractQuarztJob
    {
        #region  //自定义变量

        /// <summary>
        /// 口岸当月评价统计SQL语句
        /// </summary>
        private string strSqlTJM = string.Empty;

        /// <summary>
        /// 口岸当年评价统计SQL语句
        /// </summary>
        private string strSqlTJY = string.Empty;

        #endregion

        #region IJob 成员

        /// <summary>
        /// 调度任务入口
        /// </summary>
        /// <param name="context"></param>       
        public override void Run(IJobExecutionContext context)
        {
            try
            {
                strSqlTJM = GlobalJobs.GetSql("KADYPJTJ");
                strSqlTJY = GlobalJobs.GetSql("KADNPJTJ");
                foreach (ISqlOperate sql in LstSqlOperate)
                {
                    SecheduleKadryfTj(sql);
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region //出入境人员数据统计

        /// <summary>
        /// 统计当月、当年出入境人员数据
        /// </summary>
        private void SecheduleKadryfTj(ISqlOperate sql)
        {
            //统计当月评价数据
            string mStart = DateTime.Now.ToString("yyyyMM01000000");
            string mEnd = DateTime.Now.ToString("yyyyMMdd235959");
            string sqlTJM = string.Format(strSqlTJM, mStart, mEnd);
            List<Dictionary<string, object>> lstM = SqlUtil.Select(sqlTJM, sql);
            IsolatorUtil.SendOneTime(lstM, "KNPJTJNY", 09, GlobalJobs.MaxSendCount);

            //统计当年评价数据
            string yStart = DateTime.Now.ToString("yyyy0101000000");

            string yEnd = DateTime.Now.ToString("yyyy1231235959");

            string sqlTJY = string.Format(strSqlTJY, yStart, yEnd);
            List<Dictionary<string, object>> lstY = SqlUtil.Select(sqlTJY, sql);
            IsolatorUtil.SendOneTime(lstY, "KNPJTJNY", 09, GlobalJobs.MaxSendCount);
        }

        #endregion
    }
}
