﻿using Jobs_Common;
using Quartz;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.Service.Quarz;
using System;
using System.Collections.Generic;

namespace Jobs_CRJJTGJ
{
    /// <summary>
    /// 出入境交通工具调度任务
    /// 定时将交通工具出入境记录转送至隔离器
    /// </summary>
    [PersistJobDataAfterExecution]
    [DisallowConcurrentExecution]
    public class CRJJTGJJobs : AbstractQuarztJob
    {
        #region IJob 成员

        public override void Run(IJobExecutionContext context)
        {
            try
            {
                foreach (ISqlOperate sql in LstSqlOperate)
                {
                    string strSql = GlobalJobs.GetSql("crjjtgj");

                    string str = string.Format(strSql, DateTime.Now.AddMinutes(-60).ToString("yyyyMMddHHmmss"), DateTime.Now.ToString("yyyyMMddHHmmss"));

                    List<Dictionary<string, object>> lst = SqlUtil.Select(str, sql);

                    IsolatorUtil.SendOneTime(lst, "CRJJTGJ", 72,GlobalJobs.MaxSendCount, true);
                }
            }
            catch
            {
                throw;
            }
        }

        #endregion
    }
}
