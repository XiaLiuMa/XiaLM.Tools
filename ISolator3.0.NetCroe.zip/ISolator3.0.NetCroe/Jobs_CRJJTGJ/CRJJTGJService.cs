﻿using Schedule.Engine.Core.Service.Quarz;
using System;

namespace Jobs_CRJJTGJ
{
    /// <summary>
    /// 出入境交通工具调度任务
    /// </summary>
    public class CRJJTGJService : AbstractScheduleService
    {
        /// <summary>
        /// 当前调度服务名称
        /// </summary>
        public override string ServiceName
        {
            get { return "CRJJTGJ"; }
        }

        /// <summary>
        /// 类说明，做为调度器名称
        /// </summary>
        /// <returns></returns>
        public override string ClassNote()
        {
            return "出入境交通工具调度任务";
        }

        /// <summary>
        /// 获取当前任务类型
        /// </summary>
        /// <returns></returns>
        public override Type GetJobType()
        {
            return typeof(CRJJTGJJobs);
        }
    }
}
