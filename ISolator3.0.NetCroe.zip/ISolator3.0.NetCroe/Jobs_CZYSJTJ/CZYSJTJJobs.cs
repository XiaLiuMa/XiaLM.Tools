﻿using Jobs_Common;
using Quartz;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core;
using Schedule.Engine.Core.Service.Quarz;
using Schedule.Engine.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;

namespace Jobs_CZYSJTJ
{
    /// <summary>
    /// 操作员时间统计调度任务
    /// </summary>
    [PersistJobDataAfterExecution]
    [DisallowConcurrentExecution]
    public class CZYSJTJJobs : AbstractQuarztJob
    {
        #region  //自定义变量

        /// <summary>
        /// 查询验放数据、评价数据SQL
        /// </summary>
        private string sqlTD_YF_PJ = string.Empty;

        /// <summary>
        /// 操作员注册注销
        /// </summary>
        private string CZYZCZXSQL = string.Empty;

        private string strCZYSJTJBMDM = string.Empty;

        #endregion

        #region IJob 成员

        /// <summary>
        /// 调度任务入口
        /// </summary>
        /// <param name="context"></param>       
        public override void Run(IJobExecutionContext context)
        {
            try
            {
                sqlTD_YF_PJ = GlobalJobs.GetSql("sqlTD_YF_PJ");
                CZYZCZXSQL = GlobalJobs.GetSql("CZYZCZXSQL");
                strCZYSJTJBMDM = DataEngine_BaseDataConfig.baseDataConfig.Czysjtjdm;
                foreach (ISqlOperate sql in LstSqlOperate)
                {
                    SecheduleCZYSJTJ(sql);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        #endregion

        #region 操作员时间统计

        private void SecheduleCZYSJTJ(ISqlOperate sql)
        {
            try
            {
                string strStartDate = DateTime.Now.ToString("yyyyMMdd000000");
                string strEndDate = DateTime.Now.ToString("yyyyMMdd235959");
                string strSqlTD_YF_PJ = string.Format(sqlTD_YF_PJ, strStartDate, strEndDate, strStartDate, strEndDate, strStartDate, strEndDate, strCZYSJTJBMDM);
                List<Dictionary<string, object>> lst = SqlUtil.Select(strSqlTD_YF_PJ, sql);
                List<Dictionary<string, object>> lstSend = new List<Dictionary<string, object>>();
                if (lst != null)
                {
                    for (int i = 0; i < lst.Count; i++)
                    {
                        Dictionary<string, object> dic = lst[i];

                        string strSqlCZYZCZX = string.Format(CZYZCZXSQL, dic["CZYDM"].ToString(), strStartDate, strEndDate);

                        List<Dictionary<string, object>> lstCZYZCZX = SqlUtil.Select(strSqlCZYZCZX, sql);

                        double zsc = GetZS(lstCZYZCZX);

                        dic.Add("STSC", zsc.ToString());

                        lstSend.Add(dic);
                    }
                }
                if (lstSend != null && lstSend.Count > 1)
                {
                    IsolatorUtil.SendOneTime(lst, "CZYSJTJ", 11,GlobalJobs.MaxSendCount, true);
                }
            }
            catch
            {
                throw;
            }
        }

        private double GetZS(List<Dictionary<string, object>> lst)
        {
            double re = 0;
            for (int i = 0; i < lst.Count; i++)
            {
                Dictionary<string, object> dic = lst[i];
                string czyzcsj = dic["ZCSJ"].ToString();
                string czyzxsj = dic["ZXSJ"] != null ? dic["ZXSJ"].ToString() : string.Empty;
                double ss = 0.0;
                string strDTFormat = "yyyyMMddHHmmss";
                DateTime dtStart = DateTime.ParseExact(czyzcsj, strDTFormat, CultureInfo.InvariantCulture);
                DateTime dtEnd = new DateTime();
                if (string.IsNullOrEmpty(czyzxsj))
                {
                    dtEnd = DateTime.Now;
                }
                else
                {
                    dtEnd = DateTime.ParseExact(czyzxsj, strDTFormat, CultureInfo.InvariantCulture);
                }

                TimeSpan ts = dtEnd - dtStart;

                ss = ts.TotalSeconds;
                re = re + ss;
            }
            return re;
        }
        #endregion
    }
}
