﻿using Isolator.common.Isoltor.MQQueue;
using Isolator.common.Isoltor.SeriaPort;
using log4net;
using log4net.Config;
using Schedule.Common.log;
using System;
using System.IO;
using System.ServiceProcess;
using System.Threading;

namespace Isolator.Ms.WindowService
{

    static class Program
    {

        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        static void Main()
        {
#if DEBUG
            bool flag = false;
            Mutex mutex = new Mutex(true, "Isolator.Ms", out flag);
            if (flag)
            {
                Global.Init();
                Console.ReadLine();
                
            }
            else
            {
                LogHelp.Info(Global._Resource1.StrName + "已经启动...........");
                System.Threading.Thread.Sleep(5000);//线程挂起5秒钟  
                Environment.Exit(1);//退出程序  
            }
#else
  ServiceBase[] ServicesToRun;
            ServicesToRun = new ServiceBase[] 
            { 
                new Service1() 
            };
            ServiceBase.Run(ServicesToRun);
#endif
        }

        static void TraceInfo_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {

        }


    }
}
