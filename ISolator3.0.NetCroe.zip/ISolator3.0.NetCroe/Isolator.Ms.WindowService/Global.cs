﻿using Isolator.common.Isoltor.MQQueue;
using Isolator.common.Isoltor.SeriaPort;
using log4net.Config;
using Schedule.Common.log;
using System;
using System.IO;
using System.Threading;
using Isolator.common.Isoltor.Context;
using Isolator.common.IsoltorSeriaPort.DecisionIMPL;
using Jtkz.Common.Decision;
using log4net;
using Schedule.model.common;

namespace Isolator.Ms.WindowService
{
    public class Global
    {
        public static IsoltorComManager comManage;
        public static model.Resource1 _Resource1;

        /// <summary>
        /// 初始化系统
        /// </summary>
        public static void Init()
        {
            try
            {
                _Resource1 = SerializationHelper.Load<model.Resource1>(AppDomain.CurrentDomain.BaseDirectory + @"Config/Resource1.xml");
                var repository = LogManager.CreateRepository("NETCoreRepository");
                string path = AppDomain.CurrentDomain.BaseDirectory + "Log4Net.config";
                XmlConfigurator.Configure(repository, new FileInfo(path));     //UNDONE:（不确定是否可行）
                LogHelp.Info("启动" + _Resource1.StrName + "...........");
                ThreadPool.SetMaxThreads(50, 80);
                comManage = new IsoltorComManager();
                comManage.StartSerialPortData_ActionBlock();
                comManage.startListen();
                MQmanage.StartMqData_ActionBlock();
                MQmanage.Init();

                //  MQmanage.ConsumeRegist();
                Console.WriteLine("正在等待公安端上线");
                ApplicationContext.Instance.SerialportDispatch.repository.Select(p => new { gaState = p.pickupDecisionItem<gaState>() }).Subscibe(p =>
                {
                    if (p.gaState.State)
                    {
                        Console.WriteLine("公安端已经上线，正在启动mq消息订阅");
                        MQmanage.ConsumeRegist();
                    }
                    else
                    {
                        Console.WriteLine("公安端已经下线，停止订阅mq消息");
                        MQmanage.UnConsumeRegist();
                    }


                });




            }
            catch (Exception ex)
            {
                LogHelp.Error(typeof(Global), ex);
            }
            LogHelp.Info(_Resource1.StrName + "初始化成功................");
        }

        public static void UnInit()
        {
            LogHelp.Info("停止" + _Resource1.StrName + "...........");

            try
            {
                MQmanage.stop();
                if (comManage != null)
                    comManage.Dispose();
            }
            catch (Exception ex)
            {
                LogHelp.Error(typeof(Global), ex);
            }

            LogHelp.Info(_Resource1.StrName + "停止成功................");
        }
    }
}
