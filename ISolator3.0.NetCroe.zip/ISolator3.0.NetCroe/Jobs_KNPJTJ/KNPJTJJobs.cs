﻿using Jobs_Common;
using Quartz;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.Service.Quarz;
using System;
using System.Collections.Generic;

namespace Jobs_KNPJTJ
{
    /// <summary>
    /// 口岸评价统计统计调度任务
    /// </summary>
    [PersistJobDataAfterExecution]
    [DisallowConcurrentExecution]
    public class KNPJTJJobs : AbstractQuarztJob
    {
        #region IJob 成员

        /// <summary>
        /// 调度任务入口
        /// </summary>
        /// <param name="context"></param>       
        public override void Run(IJobExecutionContext context)
        {
            try
            {
                foreach (ISqlOperate sql in LstSqlOperate)
                {
                    SechedulePJTJ(sql);
                }
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region 评价统计
       
        private void SechedulePJTJ(ISqlOperate sql)
        {
            string cmdText = string.Format(GlobalJobs.GetSql("KADRPJTJ"), DateTime.Now.ToString("yyyyMMdd"));
            List<Dictionary<string, object>> lst = SqlUtil.Select(cmdText,sql);
            IsolatorUtil.SendOneTime(lst, "KNPJTJ", 09, GlobalJobs.MaxSendCount,false);
        }
        #endregion
     }
}
