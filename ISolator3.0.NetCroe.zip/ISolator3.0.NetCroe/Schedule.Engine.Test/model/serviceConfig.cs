﻿
namespace Schedule.Engine.Test.model
{
    public class serviceConfig
    {
        public int HttpServerPort { get; set; }
        public serviceConfig()
        {
            HttpServerPort = 9000;
        }
    }
}
