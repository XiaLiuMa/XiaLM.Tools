﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Schedule.Engine.Test.model
{
    public class Resource1
    {
        public string StrName { get; set; }
    }
}
