﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Schedule.Engine.Test
{
    /// <summary>
    /// 服务状态对象
    /// </summary>
    public abstract class SeviceState : System.ComponentModel.INotifyPropertyChanged
    {
        SynchronizationContext ctx = SynchronizationContext.Current;

        // Fields...
        private string _State;

        public string State
        {
            get { return _State; }
            set
            {
                if (_State == value)
                    return;
                _State = value;
                if (PropertyChanged != null)
                    NotifyPropertyChanged("State");
            }
        }


        public void NotifyPropertyChanged(string info)
        {
            //ctx==null表示非线程环境，直接使用标准方式处理
            if (ctx == null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(info));
            }
            else
            {
                //此处采用上下文同步方式发送消息，你当然也可以使用异步方式发送,异步方法为ctx.Post
                ctx.Send(p => PropertyChanged(this, new PropertyChangedEventArgs(info)), null);

            }
        }



        //启动服务
        public abstract void Start();

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;
    }

    public class WebApiSeviceState : SeviceState
    {
        public WebApiSeviceState()
        {
            State = "正在启动中";
        }


        /// <summary>
        ///   启动http服务监听
        /// </summary>
        public override void Start()
        {
            HttpServer httpserver = new HttpServer();
            httpserver.start(this);
        }
    }
}
