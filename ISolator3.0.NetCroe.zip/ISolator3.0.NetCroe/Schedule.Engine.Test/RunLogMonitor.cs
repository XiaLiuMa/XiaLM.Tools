﻿using DAL.AccessDAL;
using DAL.IDAL;
using Schedule.Engine.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schedule.Engine.Test
{
    public class RunLogMonitor
    {
        static System.Timers.Timer timer = null;

        private readonly static object lckObj = new object();

        static IRunLogDAL dal = new RunLogSqliteDAL();
        public static void Start()
        {
            if(timer==null)
            {
                timer = new System.Timers.Timer();
                timer.Elapsed += timer_Elapsed;
                timer.Interval = 10 * 60 * 1000;
            }
            timer.Start();
        }

        static void timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            lock (lckObj)
            {
                try
                {
                    string con = @"format(StartTime,'yyyy-mm-dd HH:mm:ss')<='{0}'";
                    string conn = string.Format(con,DateTime.Now.AddDays(Convert.ToInt32("-" + DataEngine_BaseDataConfig.baseDataConfig.RunLogDays)));

                    dal.Delete(new List<string>() {conn });
                }
                catch (Exception ex)
                {
                    Schedule.Common.log.LogHelp.Error(ex);
                }
            }
        }

        public static void Stop()
        { 
            if(timer==null)
            {
                timer.Stop();
            }
        }
    }
}
