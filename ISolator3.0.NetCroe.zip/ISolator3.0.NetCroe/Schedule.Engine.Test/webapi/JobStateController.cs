﻿using Nancy;
using Newtonsoft.Json;
using Schedule.Common.Service;
using Schedule.Engine.Core;
using Schedule.Engine.Core.Service;
using Schedule.Engine.Core.Service.Quarz;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace Schedule.Engine.Test.webapi
{
    //public class IsolatorController : ApiController
    //{
    //    [HttpGet]
    //    public async Task<HttpResponseMessage> GetAllRuningJob()
    //    {
    //        //if(JobRepertory.RuningSchedule.Value.)
    //        HttpResponseMessage re = await Write<List<string>>(JobRepertory.RuningSchedule.Value);
    //        return re;
    //    }

    //    /// <summary>
    //    /// 向前台输出
    //    /// </summary>
    //    /// <param name="content">输出内容。默认编码UTF-8，媒体类型text/html</param>
    //    /// <returns>输出上下文</returns>
    //    public static async Task<HttpResponseMessage> Write<T>(T t)
    //    {
    //        string content =await JsonConvert.SerializeObjectAsync(t);
    //        HttpResponseMessage result = new HttpResponseMessage
    //        {
    //            Content =
    //                new StringContent(content, Encoding.GetEncoding("UTF-8"), "text/html")
    //        };

    //        return result;
    //    }
    //}

    public class IsolatorController : NancyModule
    {
        public IsolatorController()
        {
            Get("/GetAllRuningJob", p => GetAllRuningJob());
        }

        public HttpResponseMessage GetAllRuningJob()
        {
            HttpResponseMessage re = Write<List<string>>(JobRepertory.RuningSchedule.Value);
            return re;
        }

        /// <summary>
        /// 向前台输出
        /// </summary>
        /// <param name="content">输出内容。默认编码UTF-8，媒体类型text/html</param>
        /// <returns>输出上下文</returns>
        public static HttpResponseMessage Write<T>(T t)
        {
            string content = JsonConvert.SerializeObject(t);
            HttpResponseMessage result = new HttpResponseMessage
            {
                Content = new StringContent(content, Encoding.GetEncoding("UTF-8"), "text/html")
            };
            return result;
        }
    }
}
