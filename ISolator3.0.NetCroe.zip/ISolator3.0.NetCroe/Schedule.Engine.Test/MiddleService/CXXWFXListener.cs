﻿using Jobs_Common;
using Newtonsoft.Json;
using Schedule.Common.Service;
using Schedule.Common.Util;
using Schedule.Engine.Core;
using Schedule.model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks.Dataflow;

namespace Schedule.Engine.Test.MiddleService
{
    public class CXXWFXListener : IReceiveListener
    {
        string CXXWFX = string.Empty;

        public void ReceiveNotified(IsolatorData data)
        {
            switch (data.Cmd)
            {
                case 73:
                    CXXWFX = GlobalJobs.GetSql("CXXWFX");
                    Dictionary<string, object> receive = JsonConvert.DeserializeObject<Dictionary<string, object>>(Encoding.UTF8.GetString(data.Value));
                    string startDic = Convert.ToDateTime(receive["StarTime"]).ToString("yyyy0101000000");
                    string endDic = Convert.ToDateTime(receive["EndTime"]).ToString("yyyy1231235959");
                    string str = string.Format(CXXWFX, startDic, endDic, startDic, endDic);

                    List<Dictionary<string, object>> lst = DbConfigRepertory.SelectData(str);
                    IsolatorUtil.SendOneTime(lst, "CXXWFX", 73, GlobalJobs.MaxSendCount, false);
                    break;
            }
        }


        private ActionBlock<IsolatorData> _Data_ActionBlock;

        public static CancellationTokenSource _CancellationTokenSourceData = new CancellationTokenSource();

        public ActionBlock<IsolatorData> Data_ActionBlock
        {
            get
            {
                _Data_ActionBlock = new ActionBlock<IsolatorData>((data) =>
                {
                    switch (data.Cmd)
                    {
                        case 73:
                            CXXWFX = GlobalJobs.GetSql("CXXWFX");
                            Dictionary<string, object> receive = JsonConvert.DeserializeObject<Dictionary<string, object>>(Encoding.UTF8.GetString(data.Value));
                            string startDic = Convert.ToDateTime(receive["StarTime"]).ToString("yyyy0101000000");
                            string endDic = Convert.ToDateTime(receive["EndTime"]).ToString("yyyy1231235959");
                            string str = string.Format(CXXWFX, startDic, endDic, startDic, endDic);

                            List<Dictionary<string, object>> lst = DbConfigRepertory.SelectData(str);
                            IsolatorUtil.SendOneTime(lst, "CXXWFX", 73, GlobalJobs.MaxSendCount, false);
                            break;
                    }
                }, new ExecutionDataflowBlockOptions() { MaxDegreeOfParallelism = 3, BoundedCapacity = 100, CancellationToken = _CancellationTokenSourceData.Token });
                return _Data_ActionBlock;
            }
            set
            {
                _Data_ActionBlock = value;
            }
        }
    }
}
