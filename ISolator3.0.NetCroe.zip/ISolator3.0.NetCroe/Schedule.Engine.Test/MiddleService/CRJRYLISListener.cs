﻿using Jobs_Common;
using Newtonsoft.Json;
using Schedule.Common.Service;
using Schedule.Common.Util;
using Schedule.Engine.Core;
using Schedule.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;

/* ==============================
*
* 作者: 胡军会
* 创建时间：2018-06-22 16:04:17
* 文件名称：CRJRYLISListener
* 版本：V1.0.1
* 修改时间:
* 修改人：
* 修改备注：
* ===============================
*/
namespace Schedule.Engine.Test.MiddleService
{
    public class CRJRYLISListener : IReceiveListener
    {
        public void ReceiveNotified(Schedule.model.IsolatorData data)
        {
            throw new NotImplementedException();
        }

        private ActionBlock<IsolatorData> _Data_ActionBlock;

        public static CancellationTokenSource _CancellationTokenSourceData = new CancellationTokenSource();
        string CRJRYLIS = string.Empty;
        public ActionBlock<Schedule.model.IsolatorData> Data_ActionBlock
        {
            get
            {
                _Data_ActionBlock = new ActionBlock<IsolatorData>((data) =>
                {
                    switch (data.Cmd)
                    {
                        case 75:
                            CRJRYLIS = GlobalJobs.GetSql("CRJRYLIS");
                            Dictionary<string, object> receive = JsonConvert.DeserializeObject<Dictionary<string, object>>(Encoding.UTF8.GetString(data.Value));
                            string startDic = Convert.ToDateTime(receive["StarTime"]).ToString("yyyyMMddHHmmss");
                            string endDic = Convert.ToDateTime(receive["EndTime"]).ToString("yyyyMMddHHmmss");
                            string str = string.Format(CRJRYLIS, startDic, endDic);
                            List<Dictionary<string, object>> lst = DbConfigRepertory.SelectData(str);

                            IsolatorUtil.SendOneTime(lst, "CRJRYLIS", 75, GlobalJobs.MaxSendCount, true);
                            break;
                    }
                }, new ExecutionDataflowBlockOptions() { MaxDegreeOfParallelism = 3, BoundedCapacity = 100, CancellationToken = _CancellationTokenSourceData.Token });
                return _Data_ActionBlock;
            }
            set
            {
                _Data_ActionBlock = value;
            }
        }
    }
}
