﻿using Jobs_Common;
using Newtonsoft.Json;
using Schedule.Common.Service;
using Schedule.Common.Util;
using Schedule.Engine.Core;
using Schedule.Engine.Model;
using Schedule.model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;

namespace Schedule.Engine.Test.MiddleService
{
    public class CZYSJTJListener : IReceiveListener
    {
        /// <summary>
        /// 查询验放数据、评价数据SQL
        /// </summary>
        private string sqlTD_YF_PJ = string.Empty;

        /// <summary>
        /// 操作员注册注销
        /// </summary>
        private string CZYZCZXSQL = string.Empty;

        private string strCZYSJTJBMDM = string.Empty;

        public void ReceiveNotified(IsolatorData data)
        {
            switch (data.Cmd)
            {
                case 11:
                    sqlTD_YF_PJ = GlobalJobs.GetSql("LSYF_PJ");
                    CZYZCZXSQL = GlobalJobs.GetSql("LSCZYZCZXSQL");
                    strCZYSJTJBMDM = DataEngine_BaseDataConfig.baseDataConfig.Czysjtjdm;
                    Dictionary<string, object> receive = JsonConvert.DeserializeObject<Dictionary<string, object>>(Encoding.UTF8.GetString(data.Value));
                    string startDic = receive["StarTime"].ToString();
                    string endDic = receive["EndTime"].ToString();

                    DateTime startDateTime = Convert.ToDateTime(startDic);
                    DateTime endDateTime = Convert.ToDateTime(endDic);

                    string strStartDate = startDateTime.ToString("yyyyMMdd000000");
                    string strEndDate = endDateTime.ToString("yyyyMMdd235959");

                    string strSqlTD_YF_PJ = string.Format(sqlTD_YF_PJ, strStartDate, strEndDate, strStartDate, strEndDate, strStartDate, strEndDate, strCZYSJTJBMDM);
                    List<Dictionary<string, object>> lst = DbConfigRepertory.SelectData(strSqlTD_YF_PJ);
                    List<Dictionary<string, object>> lstSend = new List<Dictionary<string, object>>();
                    if (lst != null)
                    {
                        for (int i = 0; i < lst.Count; i++)
                        {
                            Dictionary<string, object> dic = lst[i];

                            string strSqlCZYZCZX = string.Format(CZYZCZXSQL, dic["CZYDM"].ToString(), strStartDate, strEndDate);

                            List<Dictionary<string, object>> lstCZYZCZX = DbConfigRepertory.SelectData(strSqlCZYZCZX);

                            double zsc = GetZS(lstCZYZCZX);

                            dic.Add("STSC", zsc.ToString());

                            lstSend.Add(dic);
                        }
                    }
                    if (lstSend != null && lstSend.Count > 1)
                    {
                        IsolatorUtil.SendOneTime(lst, "CZYSJTJ", 11,GlobalJobs.MaxSendCount, false);
                    }
                    break;
            }
        }

        private double GetZS(List<Dictionary<string, object>> lst)
        {
            double re = 0;
            for (int i = 0; i < lst.Count; i++)
            {
                Dictionary<string, object> dic = lst[i];
                string czyzcsj = dic["ZCSJ"].ToString();
                string czyzxsj = dic["ZXSJ"] != null ? dic["ZXSJ"].ToString() : string.Empty;
                double ss = 0.0;
                string strDTFormat = "yyyyMMddHHmmss";
                DateTime dtStart = DateTime.ParseExact(czyzcsj, strDTFormat, CultureInfo.InvariantCulture);
                DateTime dtEnd = new DateTime();
                if (string.IsNullOrEmpty(czyzxsj))
                {
                    dtEnd = DateTime.Now;
                }
                else
                {
                    dtEnd = DateTime.ParseExact(czyzxsj, strDTFormat, CultureInfo.InvariantCulture);
                }

                TimeSpan ts = dtEnd - dtStart;

                ss = ts.TotalSeconds;
                re = re + ss;
            }
            return re;
        }


        private ActionBlock<IsolatorData> _Data_ActionBlock;

        public static CancellationTokenSource _CancellationTokenSourceData = new CancellationTokenSource();

        public ActionBlock<IsolatorData> Data_ActionBlock
        {
            get
            {
                _Data_ActionBlock = new ActionBlock<IsolatorData>((data) =>
                {
                    switch (data.Cmd)
                    {
                        case 11:
                            sqlTD_YF_PJ = GlobalJobs.GetSql("LSYF_PJ");
                            CZYZCZXSQL = GlobalJobs.GetSql("LSCZYZCZXSQL");
                            strCZYSJTJBMDM = ConfigurationManager.AppSettings["czysjtjdm"];
                            Dictionary<string, object> receive = JsonConvert.DeserializeObject<Dictionary<string, object>>(Encoding.UTF8.GetString(data.Value));
                            string startDic= receive["StarTime"].ToString();
                            string endDic = receive["EndTime"].ToString();

                            DateTime startDateTime = Convert.ToDateTime(startDic);
                            DateTime endDateTime = Convert.ToDateTime(endDic);

                            string strStartDate = startDateTime.ToString("yyyyMMdd000000");
                            string strEndDate = endDateTime.ToString("yyyyMMdd235959");

                            string strSqlTD_YF_PJ = string.Format(sqlTD_YF_PJ, strStartDate, strEndDate, strStartDate, strEndDate, strStartDate, strEndDate, strCZYSJTJBMDM);
                            List<Dictionary<string, object>> lst = DbConfigRepertory.SelectData(strSqlTD_YF_PJ);
                            List<Dictionary<string, object>> lstSend = new List<Dictionary<string, object>>();
                            if (lst!=null)
                            {
                                for (int i = 0; i < lst.Count; i++)
                                {
                                    Dictionary<string, object> dic = lst[i];
                                    string strCzyStartDt =dic["TJRQ"].ToString()+"000000";
                                    string strCzyEndDt = dic["TJRQ"].ToString() + "235959";
                                    string strSqlCZYZCZX = string.Format(CZYZCZXSQL, dic["CZYDM"].ToString(), strCzyStartDt, strCzyEndDt);

                                    List<Dictionary<string, object>> lstCZYZCZX = DbConfigRepertory.SelectData(strSqlCZYZCZX);

                                    double zsc = GetZS(lstCZYZCZX);

                                    dic.Add("STSC", zsc.ToString());

                                    lstSend.Add(dic);
                                } 
                            }
                            if (lstSend != null && lstSend.Count > 1)
                            {
                                IsolatorUtil.SendOneTime(lst, "CZYSJTJ", 11, GlobalJobs.MaxSendCount, false);
                            }
                            break;
                    }
                }, new ExecutionDataflowBlockOptions() { MaxDegreeOfParallelism = 3, BoundedCapacity = 100, CancellationToken = _CancellationTokenSourceData.Token });
                return _Data_ActionBlock;
            }
            set
            {
                _Data_ActionBlock = value;
            }
        }
    }
}
