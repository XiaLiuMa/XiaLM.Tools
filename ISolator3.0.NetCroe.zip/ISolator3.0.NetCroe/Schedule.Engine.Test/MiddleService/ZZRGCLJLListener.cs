﻿using Jobs_Common;
using Newtonsoft.Json;
using Schedule.Common.Service;
using Schedule.Common.Util;
using Schedule.Engine.Core;
using Schedule.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;

/* ==============================
*
* 作者: 胡军会
* 创建时间：2018-06-22 16:52:05
* 文件名称：ZZRGCLJLListener
* 版本：V1.0.1
* 修改时间:
* 修改人：
* 修改备注：
* ===============================
*/
namespace Schedule.Engine.Test.MiddleService
{
    public class ZZRGCLJLListener : IReceiveListener
    {

        public void ReceiveNotified(Schedule.model.IsolatorData data)
        {
            throw new NotImplementedException();
        }

        private ActionBlock<IsolatorData> _Data_ActionBlock;

        public static CancellationTokenSource _CancellationTokenSourceData = new CancellationTokenSource();

        public ActionBlock<Schedule.model.IsolatorData> Data_ActionBlock
        {
            get
            {
                _Data_ActionBlock = new ActionBlock<IsolatorData>((data) =>
                {
                    switch (data.Cmd)
                    {
                        case 252:
                            Dictionary<string, object> receive = JsonConvert.DeserializeObject<Dictionary<string, object>>(Encoding.UTF8.GetString(data.Value));
                            DateTime startDic = Convert.ToDateTime(receive["startDateTime"]);
                            DateTime endDic = Convert.ToDateTime(receive["endDateTime"]);

                            string strSql = GlobalJobs.GetSql("ZZRGCLJL");

                            string str = string.Format(strSql, startDic.ToString("yyyyMMdd"), endDic.ToString("yyyyMMdd"),"000000", "235959");

                            List<Dictionary<string, object>> lst = DbConfigRepertory.SelectData(str);
                            List<Dictionary<string, object>> lstSend = new List<Dictionary<string, object>>();
                            foreach (Dictionary<string, object> dic in lst)
                            {
                                string strwybs = GlobalJobs.GetSql("ZZRGCLJLWYBS");
                                string clsj = dic["CLRQ"].ToString() + dic["CLSJ"].ToString();
                                DateTime dtClsj = DateTime.ParseExact(clsj, "yyyyMMddHHmmss", System.Globalization.CultureInfo.CurrentCulture);
                                string startDt = dtClsj.AddHours(-5).ToString("yyyyMMddHHmmss");
                                string endDt = dtClsj.AddHours(5).ToString("yyyyMMddHHmmss");
                                string strSqlWybs = string.Format(strwybs, startDt, endDt, dic["ZJHM"], dic["KADM"], dic["TDH"]);

                                List<Dictionary<string, object>> lstWybs = DbConfigRepertory.SelectData(strSqlWybs);
                                string wybs = lstWybs != null && lstWybs.Count > 0 && lstWybs[0]["WYBS"] != null ? lstWybs[0]["WYBS"].ToString() : "";
                                if (!string.IsNullOrEmpty(wybs))
                                {
                                    dic.Add("WYBS", wybs);
                                    lstSend.Add(dic);
                                }
                            }

                            IsolatorUtil.SendOneTime(lstSend, "ZZRGCLJL", data.Cmd, GlobalJobs.MaxSendCount);
                            break;
                    }
                }, new ExecutionDataflowBlockOptions() { MaxDegreeOfParallelism = 3, BoundedCapacity = 100, CancellationToken = _CancellationTokenSourceData.Token });
                return _Data_ActionBlock;
            }
            set
            {
                _Data_ActionBlock = value;
            }
        }
    }
}
