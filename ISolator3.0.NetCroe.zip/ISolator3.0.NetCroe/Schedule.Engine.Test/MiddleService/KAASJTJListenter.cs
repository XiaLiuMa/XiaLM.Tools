﻿using Jobs_Common;
using Newtonsoft.Json;
using Schedule.Common.Service;
using Schedule.Common.Util;
using Schedule.Engine.Core;
using Schedule.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;

namespace Schedule.Engine.Test.MiddleService
{
    /// <summary>
    /// 口岸案事件统计监听
    /// </summary>
    class KAASJTJListenter : IReceiveListener
    {
        /// <summary>
        /// 开始时间
        /// </summary>
        string startDateTime;
        /// <summary>
        /// 结束时间
        /// </summary>
        string endDateTime;
        string sqlChwfwgry;
        string sqlChzkry;


        /// <summary>
        /// 查询类型
        /// 0：年
        /// 1：月
        /// 2：日
        /// </summary>
        string queryType = "0";
        /// <summary>
        /// 当前月份
        /// </summary>
        int nowMonth = DateTime.Now.Month;

        /// <summary>
        /// 口岸当nian 案事件SQL语句
        /// </summary>
        private string strSqlTJY = string.Empty;

        /// <summary>
        /// 口岸当月案事件SQL语句
        /// </summary>
        private string strSqlTJM = string.Empty;

        private string strSqlTJD = string.Empty;

        string strCHZKRYY = string.Empty;

        string strCHZKRYM = string.Empty;

        string strCHZKRYD = string.Empty;

        public Dictionary<string, object> receive;
        public void ReceiveNotified(IsolatorData data)
        {
            receive = JsonConvert.DeserializeObject<Dictionary<string, object>>(Encoding.UTF8.GetString(data.Value));
            startDateTime = receive["StarTime"].ToString();
            endDateTime = receive["EndTime"].ToString();
            queryType = receive["Type"].ToString();

            DateTime startDate = Convert.ToDateTime(startDateTime);
            DateTime endDate = Convert.ToDateTime(endDateTime);
            switch (data.Cmd)
            {
                case 08:
                    strSqlTJY = GlobalJobs.GetSql("LSKAASJTJN");

                    strSqlTJM = GlobalJobs.GetSql("LSKAASJTJY");

                    strSqlTJD = GlobalJobs.GetSql("LSKAASJTJR");

                    strCHZKRYY = GlobalJobs.GetSql("LSKAASJTJZKN");

                    strCHZKRYM = GlobalJobs.GetSql("LSKAASJTJZKY");

                    strCHZKRYD = GlobalJobs.GetSql("LSKAASJTJZKR");

                    switch (queryType)
                    {
                        case "0":
                        default:
                            string startYear = startDate.ToString("yyyy0101000000");
                            string endYear = endDate.ToString("yyyy1231235959");
                            if (endDate.Year >= DateTime.Now.Year)
                            {
                                endYear = DateTime.Now.AddDays(-1).ToString("yyyyMMdd235959");
                            }
                            sqlChwfwgry = string.Format(strSqlTJY, startYear, endYear);
                            sqlChzkry = string.Format(strCHZKRYY, startYear, endYear);
                            break;
                        case "1":
                            string startMonth = startDate.ToString("yyyyMM01000000");
                            string endMonth = endDate.AddDays(1 - endDate.Day).AddMonths(1).AddDays(-1).ToString("yyyyMMdd235959");
                            if (Convert.ToInt32(endDate.Year.ToString() + endDate.Month.ToString()) >= (Convert.ToInt32(DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString())))
                            {
                                endMonth = DateTime.Now.AddDays(-1).ToString("yyyyMMdd235959");
                            }
                            sqlChwfwgry = string.Format(strSqlTJM, startMonth, endMonth);
                            sqlChzkry = string.Format(strCHZKRYM, startMonth, endMonth);
                            break;
                        case "2":
                            string startDay = startDate.ToString("yyyyMMdd000000");
                            string endDay = endDate.ToString("yyyyMMdd235959");
                            sqlChwfwgry = string.Format(strSqlTJD, startDay, endDay);
                            sqlChzkry = string.Format(strCHZKRYD, startDay, endDay);
                            break;
                    }

                    IsolatorUtil.SendOneTime(DbConfigRepertory.SelectData(sqlChwfwgry), "KAASJTJ", data.Cmd, GlobalJobs.MaxSendCount);
                    IsolatorUtil.SendOneTime(DbConfigRepertory.SelectData(sqlChzkry), "KAASJTJ", data.Cmd, GlobalJobs.MaxSendCount);
                    break;
            }
        }

       
        private ActionBlock<IsolatorData> _Data_ActionBlock;

        public static CancellationTokenSource _CancellationTokenSourceData = new CancellationTokenSource();

        public ActionBlock<IsolatorData> Data_ActionBlock
        {
            get
            {
                _Data_ActionBlock = new ActionBlock<IsolatorData>((data) =>
                {
                    receive = JsonConvert.DeserializeObject<Dictionary<string, object>>(Encoding.UTF8.GetString(data.Value));
                    startDateTime = receive["StarTime"].ToString();
                    endDateTime = receive["EndTime"].ToString();
                    queryType = receive["Type"].ToString();

                    DateTime startDate = Convert.ToDateTime(startDateTime);
                    DateTime endDate = Convert.ToDateTime(endDateTime);
                    switch (data.Cmd)
                    {
                        case 08:
                            strSqlTJY = GlobalJobs.GetSql("LSKAASJTJN");

                            strSqlTJM = GlobalJobs.GetSql("LSKAASJTJY");

                            strSqlTJD = GlobalJobs.GetSql("LSKAASJTJR");

                            strCHZKRYY = GlobalJobs.GetSql("LSKAASJTJZKN");

                            strCHZKRYM = GlobalJobs.GetSql("LSKAASJTJZKY");

                            strCHZKRYD = GlobalJobs.GetSql("LSKAASJTJZKR");

                            switch (queryType)
                            {
                                case "0":
                                default:
                                    string startYear = startDate.ToString("yyyy0101000000");
                                    string endYear = endDate.ToString("yyyy1231235959");
                                    if (endDate.Year >= DateTime.Now.Year)
                                    {
                                        endYear = DateTime.Now.AddDays(-1).ToString("yyyyMMdd235959");
                                    }
                                    sqlChwfwgry = string.Format(strSqlTJY, startYear, endYear);
                                    sqlChzkry = string.Format(strCHZKRYY, startYear, endYear);
                                    break;
                                case "1":
                                    string startMonth = startDate.ToString("yyyyMM01000000");
                                    string endMonth = endDate.AddDays(1 - endDate.Day).AddMonths(1).AddDays(-1).ToString("yyyyMMdd235959");
                                    if (Convert.ToInt32(endDate.Year.ToString() + endDate.Month.ToString()) >= (Convert.ToInt32(DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString())))
                                    {
                                        endMonth = DateTime.Now.AddDays(-1).ToString("yyyyMMdd235959");
                                    }
                                    sqlChwfwgry = string.Format(strSqlTJM, startMonth, endMonth);
                                    sqlChzkry = string.Format(strCHZKRYM, startMonth, endMonth);
                                    break;
                                case "2":
                                    string startDay = startDate.ToString("yyyyMMdd000000");
                                    string endDay = endDate.ToString("yyyyMMdd235959");
                                    sqlChwfwgry = string.Format(strSqlTJD, startDay, endDay);
                                    sqlChzkry = string.Format(strCHZKRYD, startDay, endDay);
                                    break;
                            }

                            IsolatorUtil.SendOneTime(DbConfigRepertory.SelectData(sqlChwfwgry), "KAASJTJ", data.Cmd, GlobalJobs.MaxSendCount);
                            IsolatorUtil.SendOneTime(DbConfigRepertory.SelectData(sqlChzkry), "KAASJTJ", data.Cmd, GlobalJobs.MaxSendCount);
                            break;
                    }
                }, new ExecutionDataflowBlockOptions() { MaxDegreeOfParallelism = 3, BoundedCapacity = 100, CancellationToken = _CancellationTokenSourceData.Token });
                return _Data_ActionBlock;
            }
            set
            {
                _Data_ActionBlock = value;
            }
        }
    }
}
