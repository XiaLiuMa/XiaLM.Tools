﻿using Jobs_Common;
using Newtonsoft.Json;
using Schedule.Common.Service;
using Schedule.Common.Util;
using Schedule.Engine.Core;
using Schedule.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;

/* ==============================
*
* 作者: 胡军会
* 创建时间：2018-06-22 15:38:52
* 文件名称：_72XSGJMQLKListener
* 版本：V1.0.1
* 修改时间:
* 修改人：
* 修改备注：
* ===============================
*/
namespace Schedule.Engine.Test.MiddleService
{
    public class _72XSGJMQLKListener:IReceiveListener
    {

        public void ReceiveNotified(Schedule.model.IsolatorData data)
        {
            throw new NotImplementedException();
        }

        private ActionBlock<IsolatorData> _Data_ActionBlock;

        public static CancellationTokenSource _CancellationTokenSourceData = new CancellationTokenSource();

        public ActionBlock<Schedule.model.IsolatorData> Data_ActionBlock
        {
            get
            {
                _Data_ActionBlock = new ActionBlock<IsolatorData>((data) =>
                {
                    switch (data.Cmd)
                    {
                        case 253:
                            string sql = GlobalJobs.GetSql("72XSGJMQLK");

                            Dictionary<string, object> receive = JsonConvert.DeserializeObject<Dictionary<string, object>>(Encoding.UTF8.GetString(data.Value));
                            string startDic = Convert.ToDateTime(receive["StarTime"]).ToString("yyyyMMddHHmmss");
                            string endDic = Convert.ToDateTime(receive["EndTime"]).ToString("yyyyMMddHHmmss");

                            string str = string.Format(sql, GlobalJobs._72XSGJMQZDYDM, startDic, endDic);

                            List<Dictionary<string, object>> lst = DbConfigRepertory.SelectData(str);

                            IsolatorUtil.SendOneTime(lst, "_72XSGJMQLKJobs", 69, GlobalJobs.MaxSendCount, false);


                            string sql1 = GlobalJobs.GetSql("72XSGJMQLK");

                            Dictionary<string, object> receive1 = JsonConvert.DeserializeObject<Dictionary<string, object>>(Encoding.UTF8.GetString(data.Value));
                            string startDic1 = Convert.ToDateTime(receive1["StarTime"]).ToString("yyyyMMddHHmmss");
                            string endDic1 = Convert.ToDateTime(receive1["EndTime"]).ToString("yyyyMMddHHmmss");

                            string str1 = string.Format(sql1, GlobalJobs._72XSGJMQZDYDM, startDic1, endDic1);

                            List<Dictionary<string, object>> lst1 = DbConfigRepertory.SelectData(str1);

                            IsolatorUtil.SendOneTime(lst1, "_72XSGJMQLKJobs", 69, GlobalJobs.MaxSendCount, false);
                            break;
                    }
                }, new ExecutionDataflowBlockOptions() { MaxDegreeOfParallelism = 3, BoundedCapacity = 100, CancellationToken = _CancellationTokenSourceData.Token });
                return _Data_ActionBlock;
            }
            set
            {
                _Data_ActionBlock = value;
            }
        }
    }
}
