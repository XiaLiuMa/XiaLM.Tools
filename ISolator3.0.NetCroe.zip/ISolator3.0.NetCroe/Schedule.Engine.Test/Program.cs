﻿using Schedule.Common.log;
using System;
using System.ServiceProcess;
using System.Threading;
namespace Schedule.Engine.Test
{
    class Program
    {
        static void Main(string[] args)
        {
#if DEBUG
            bool flag = false;
            Mutex mutex = new Mutex(true, "DataEngine", out flag);
            if (flag)
            {
                Global.Init();
                Console.ReadLine();
            }
            else
            {
                LogHelp.Info(Global._Resource1.StrName + "已经启动...........");
                System.Threading.Thread.Sleep(5000);//线程挂起5秒钟  
                Environment.Exit(1);//退出程序  
            }

            //if(GetProgramRuning())
            //{
            //    Global.Init(new object());
            //    Console.ReadLine();
            //}
#else


  ServiceBase[] ServicesToRun;
            ServicesToRun = new ServiceBase[] 
            { 
                new Service1() 
            };
            ServiceBase.Run(ServicesToRun);
#endif
        }


        private static bool GetProgramRuning()
        {
            bool flag = false;
            Mutex mutex = new Mutex(true, "Test", out flag);

            return flag;
        }

    }
}
