﻿using log4net;
using log4net.Config;
using Schedule.Common.Core.Send.MqSend;
using Schedule.Common.log;
using Schedule.Common.Util;
using Schedule.Engine.Core;
using Schedule.model.common;
using System;
using System.IO;
using System.Threading;

namespace Schedule.Engine.Test
{
    public static class Global
    {
        public static model.Resource1 _Resource1;
        /// <summary>
        /// 初始化系统
        /// </summary>
        public static void Init()
        {
            try
            {
                //if (GetProgramRuning())
                //{
                _Resource1 = SerializationHelper.Load<model.Resource1>(AppDomain.CurrentDomain.BaseDirectory + @"Config/Resource1.xml");

                var repository = LogManager.CreateRepository("NETCoreRepository");
                string path = AppDomain.CurrentDomain.BaseDirectory + "Log4Net.config";
                //XmlConfigurator.Configure(new FileInfo(path));
                XmlConfigurator.Configure(repository, new FileInfo(path)); //UNDONE:（不确定是否可行）

                LogHelp.Info("启动" + _Resource1.StrName + "...........");
                ThreadPool.SetMaxThreads(50, 80);

                //UNDONE:（未处理，Accesss换成Sqlite还未测试，注释起来了）
                //IsolatorUtil.StartDataBlock();
                
                RabbitMqManage.Init();
                RabbitMqManage.ConsumeRegist();

                DbConfigRepertory dbconfig = new DbConfigRepertory();
                dbconfig.init();

                JobRepertory jobs = new JobRepertory();
                jobs.init();

                RunLogMonitor.Start();
                SeviceState httpserver = new WebApiSeviceState();
                httpserver.Start();
                LogHelp.Info(_Resource1.StrName + "初始化成功................");
                //}
                //else
                //{
                //    LogHelp.Info(Resource1.StrName + "已经启动...........");
                //    System.Threading.Thread.Sleep(5000);//线程挂起5秒钟  
                //    Environment.Exit(1);//退出程序  
                //}
            }
            catch (Exception ex)
            {
                LogHelp.Error(typeof(Global), ex);
            }
        }

        private static bool GetProgramRuning()
        {
            bool flag = false;
            Mutex mutex = new Mutex(true, "Test", out flag);

            return flag;
        }

        /// <summary>
        /// 释放系统
        /// </summary>
        public static void UnInit()
        {
            LogHelp.Info("停止" + _Resource1.StrName + "...........");
            try
            {
                RunLogMonitor.Stop();
                RabbitMqManage.Stop();
                JobRepertory.Stop();
            }
            catch (Exception ex)
            {
                LogHelp.Error(typeof(Global), ex);
            }
            LogHelp.Info(_Resource1.StrName + "停止成功................");
        }
    }
}
