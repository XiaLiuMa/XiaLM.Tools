﻿using Jobs_Common;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.Service.Quarz;
using System;
using System.Collections.Generic;

/* ==============================
*
* 作者: 胡军会
* 创建时间：2018-06-22 16:22:45
* 文件名称：CRJRYLISJobs
* 版本：V1.0.1
* 修改时间:
* 修改人：
* 修改备注：
* ===============================
*/
namespace Jobs_CRJRYLIS
{
    public class CRJRYLISJobs : AbstractQuarztJob
    {
        public override void Run(Quartz.IJobExecutionContext context)
        {
            foreach (ISqlOperate sql in LstSqlOperate)
            {
                InqueryZDYMFZJ(sql);
            }
        }

        #region 查询数据
        private void InqueryZDYMFZJ(ISqlOperate sql)
        {
            try
            {
                string Sql = GlobalJobs.GetSql("CRJRYLIS");
                Sql = string.Format(Sql, DateTime.Now.AddMinutes(-1).ToString("yyyyMMddHHmmss"), DateTime.Now.ToString("yyyyMMddHHmmss"));
                List<Dictionary<string, object>> lst = SqlUtil.Select(Sql, sql);
                IsolatorUtil.SendOneTime(lst, "CRJRYLIS", 75, GlobalJobs.MaxSendCount, true);
            }
            catch (Exception ex)
            {
                
            }
        }
        #endregion
    }
}
