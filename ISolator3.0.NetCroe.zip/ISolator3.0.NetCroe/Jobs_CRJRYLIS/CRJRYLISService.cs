﻿using Schedule.Engine.Core.Service.Quarz;

/* ==============================
*
* 作者: 胡军会
* 创建时间：2018-06-22 16:20:53
* 文件名称：CRJRYLISService
* 版本：V1.0.1
* 修改时间:
* 修改人：
* 修改备注：
* ===============================
*/
namespace Jobs_CRJRYLIS
{
    public class CRJRYLISService : AbstractScheduleService
    {
        public override string ServiceName
        {
            get { return "CRJRYLIS"; }
        }

        public override string ClassNote()
        {
            return "出入境人员历史调度服务";
        }

        public override System.Type GetJobType()
        {
            return typeof(CRJRYLISJobs);
        }
    }
}
