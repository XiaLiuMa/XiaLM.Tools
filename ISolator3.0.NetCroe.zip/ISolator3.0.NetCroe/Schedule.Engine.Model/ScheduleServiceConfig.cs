﻿using System;


namespace Schedule.Engine.Model
{
    public class ScheduleServiceConfig
    {
        public Guid ID { get; set; }

        public bool state { get; set; }

        public string Expresstion { get; set; }

        public string typeName { get; set; }

        public string Conn { get; set; }

       
    }
}
