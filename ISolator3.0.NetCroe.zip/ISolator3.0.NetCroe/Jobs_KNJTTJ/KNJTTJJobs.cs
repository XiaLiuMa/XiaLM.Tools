﻿using Jobs_Common;
using Quartz;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.Service.Quarz;
using System;
using System.Collections.Generic;

namespace Jobs_KNJTTJ
{
    /// <summary>
    /// 口岸交通统计调度任务
    /// </summary>
    [PersistJobDataAfterExecution]
    [DisallowConcurrentExecution]
    public class KNJTTJJobs : AbstractQuarztJob
    {
        #region  //自定义变量

        #endregion

        public override void Run(IJobExecutionContext context)
        {
            try
            {
                foreach (ISqlOperate sql in LstSqlOperate)
                {
                    SecheduleKajtgjTj(sql);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 按口岸统计交通工具每日出入境人数,只统计当天当前的数据
        /// </summary>
        private void SecheduleKajtgjTj(ISqlOperate sql)
        {
            string KADRJTTJ = GlobalJobs.GetSql("KADRJTTJ");
            string cmdText = string.Format(KADRJTTJ, DateTime.Now.ToString("yyyyMMdd"));

            List<Dictionary<string, object>> lst = SqlUtil.Select(cmdText, sql);
            IsolatorUtil.SendOneTime(lst, "KNJTTJ", 07, GlobalJobs.MaxSendCount, false);
        }
    }
}
