﻿using Jobs_Common;
using Quartz;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.Service.Quarz;
using System;
using System.Collections.Generic;

namespace Jobs_KNJTTJNY
{
    /// <summary>
    /// 口岸交通统计年月调度任务
    /// </summary>
    [PersistJobDataAfterExecution]
    [DisallowConcurrentExecution]
    public class KNJTTJNYJobs : AbstractQuarztJob
    {
        #region  //自定义变量

        /// <summary>
        /// 口岸当月交通统计SQL语句
        /// </summary>
        private string strSqlTJM = string.Empty;

        /// <summary>
        /// 口岸当年交通统计SQL语句
        /// </summary>
        private string strSqlTJY = string.Empty;

        #endregion

        public override void Run(IJobExecutionContext context)
        {
            try
            {
                strSqlTJM = GlobalJobs.GetSql("KADYJTTJ");
                strSqlTJY = GlobalJobs.GetSql("KADNJTTJ");
                foreach (ISqlOperate sql in LstSqlOperate)
                {
                    SecheduleKajtgjTj(sql);
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 按口岸统计当月、当年交通数据
        /// </summary>
        private void SecheduleKajtgjTj(ISqlOperate sql)
        {
            //统计当月出入交通数据
            string mStart = DateTime.Now.ToString("yyyyMM01");

            string mEnd = DateTime.Now.AddDays(1).ToString("yyyyMMdd");

            string sqlTJM = string.Format(strSqlTJM, mStart, mEnd);
            List<Dictionary<string, object>> lstM = SqlUtil.Select(sqlTJM, sql);
            IsolatorUtil.SendOneTime(lstM, "KNJTTJNY", 07, GlobalJobs.MaxSendCount);


            string yStart = DateTime.Now.ToString("yyyy0101");

            string yEnd = DateTime.Now.AddDays(1).ToString("yyyy1231");

            string SqlTJY = string.Format(strSqlTJY, yStart, yEnd);
            //统计当年出入交通数据
            List<Dictionary<string, object>> lstY = SqlUtil.Select(SqlTJY, sql);
            IsolatorUtil.SendOneTime(lstY, "KNJTTJNY", 07, GlobalJobs.MaxSendCount);
        }
    }
}
