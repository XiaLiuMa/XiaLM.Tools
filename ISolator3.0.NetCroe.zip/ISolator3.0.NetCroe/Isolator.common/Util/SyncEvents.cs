﻿using System.Threading;

// namespaces...
namespace Isolator.common.Util
{
    // public classes...
    public class SyncEvents
    {
        // private fields...
        private WaitHandle[] _eventArray;
        private EventWaitHandle _exitThreadEvent;
        private EventWaitHandle _newItemEvent;

        // public constructors...
        public SyncEvents()
        {
            _newItemEvent = new AutoResetEvent(false);
            _exitThreadEvent = new ManualResetEvent(false);
            _eventArray = new WaitHandle[2];
            _eventArray[0] = _newItemEvent;
            _eventArray[1] = _exitThreadEvent;
        }

        // public properties...
        public WaitHandle[] EventArray
        {
            get
            {
                return _eventArray;
            }
        }
        public EventWaitHandle ExitThreadEvent
        {
            get
            {
                return _exitThreadEvent;
            }
        }
        public EventWaitHandle NewItemEvent
        {
            get
            {
                return _newItemEvent;
            }
        }
    }
}
