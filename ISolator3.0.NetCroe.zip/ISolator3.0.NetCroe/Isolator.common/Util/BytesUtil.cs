﻿
// namespaces...

using System;
using System.Security.Cryptography;

namespace Isolator.common.Util
{
    // public classes...
    public static class BytesUtil
    {
        // public methods...
        /// <summary>
        /// 获取crc16校验码
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static byte[] GetCrc16(this byte[] source)
        {
            return CrcUtil.Crc16(source);
        }
        /// <summary>
        /// 获取crc32校验码
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static byte[] GetCrc32(this byte[] source)
        {
            return CrcUtil.Crc32(source);
        }

        public static byte[] getMD5bytes(this byte[] source)
        {
            var md5 = new MD5CryptoServiceProvider();
            return md5.ComputeHash(source);
        }

        public static string getMd5String(this byte[] source)
        {
            return BitConverter.ToString(getMD5bytes(source)).Replace("-", "").ToLower();
        }

    }
}
