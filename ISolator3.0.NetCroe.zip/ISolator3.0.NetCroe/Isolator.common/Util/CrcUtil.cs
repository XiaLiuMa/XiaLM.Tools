﻿
namespace Isolator.common.Util
{/// <summary>
    /// 提供CRC校验
    /// </summary>
    class CrcUtil
    {
        /// <summary>
        /// CRC-16    = X16 + X15 + X2 + X0
        /// </summary>
        public const ushort cnCRC_16 = 0x8005;

        /// <summary>
        /// CRC-CCITT = X16 + X12 + X5 + X0，据说这个 16 位 CRC 多项式比上一个要好
        /// </summary>
        public const ushort cnCRC_CCITT = 0x1021;

        /// <summary>
        /// CRC-32    = X32 + X26 + X23 + X22 + X16 + X11 + X10 + X8 + X7 + X5 + X4 + X2 + X1 + X0
        /// </summary>
        public const uint cnCRC_32 = 0x04C10DB7;

        /// <summary>
        /// CRC_16的查找表
        /// </summary>
        public static readonly ushort[] TBL_CRC_16;

        /// <summary>
        /// CRC_CCITT的查找表
        /// </summary>
        public static readonly ushort[] TBL_CRC_CCITT;

        /// <summary>
        /// CRC_32的查找表
        /// </summary>
        public static readonly uint[] TBL_CRC_32;

        static CrcUtil()
        {
            //初始化CRC_16查找表
            TBL_CRC_16 = new ushort[256];
            BuildTable16(cnCRC_16, TBL_CRC_16);

            //初始化CRC_CCITT查找表
            TBL_CRC_CCITT = new ushort[256];
            BuildTable16(cnCRC_CCITT, TBL_CRC_CCITT);

            //初始化CRC_32查找表
            TBL_CRC_32 = new uint[256];
            BuildTable32(cnCRC_32, TBL_CRC_32);
        }


        /// <summary>
        /// 计算CRC16查找表
        /// </summary>
        static void BuildTable16(ushort aPoly, ushort[] Table_CRC)
        {
            ushort i, j;
            ushort nData;
            ushort nAccum;

            for (i = 0; i < 256; i++)
            {
                nData = (ushort)(i << 8);
                nAccum = 0;
                for (j = 0; j < 8; j++)
                {
                    if (((nData ^ nAccum) & 0x8000) != 0)
                        nAccum = (ushort)((nAccum << 1) ^ aPoly);
                    else
                        nAccum <<= 1;
                    nData <<= 1;
                }
                Table_CRC[i] = nAccum;
            }
        }


        /// <summary>
        /// 计算 16 位 CRC 值，CRC-16 或 CRC-CCITT
        /// </summary>
        static ushort Crc16(ushort[] TBL, byte[] data, int offset, int len)
        {
            ushort nAccum = 0;

            for (int i = 0; i < len; i++)
            {
                nAccum = (ushort)((nAccum << 8) ^ (ushort)TBL[(nAccum >> 8) ^ data[i + offset]]);
            }
            return nAccum;
        }


        /// <summary>
        /// 构造 32 位 CRC 表
        /// </summary>
        static void BuildTable32(uint aPoly, uint[] Table_CRC)
        {
            uint i, j;
            uint nData;
            uint nAccum;

            for (i = 0; i < 256; i++)
            {
                nData = (i << 24);
                nAccum = 0;
                for (j = 0; j < 8; j++)
                {
                    if (((nData ^ nAccum) & 0x80000000) != 0)
                        nAccum = (ushort)((nAccum << 1) ^ aPoly);
                    else
                        nAccum <<= 1;
                    nData <<= 1;
                }
                Table_CRC[i] = nAccum;
            }
        }


        /// <summary>
        /// 计算 32 位 CRC-32 值
        /// </summary>
        static uint Crc32(uint[] TBL, byte[] data, int offset, int len)
        {
            uint nAccum = 0;

            for (int i = 0; i < len; i++)
                nAccum = (nAccum << 8) ^ TBL[(nAccum >> 24) ^ data[i + offset]];
            return nAccum;
        }

        /// <summary>
        /// 计算CRC32校验值
        /// </summary>
        public static byte[] Crc32(byte[] data, int offset, int len)
        {
            uint crc = Crc32(TBL_CRC_32, data, offset, len);
            return new byte[]
            {
                (byte)(crc >> 24),
                (byte)(crc >> 16),
                (byte)(crc >> 8),
                (byte)(crc & 0x000000FF),
                               };
        }

        /// <summary>
        /// 计算CRC32校验值
        /// </summary>
        public static byte[] Crc32(byte[] data)
        {
            return Crc32(data, 0, data.Length);
        }


        /// <summary>
        /// 计算CRC_16校验值
        /// </summary>
        public static byte[] Crc16(byte[] data)
        {
            return Crc16(data, 0, data.Length);
        }


        /// <summary>
        /// 计算CRC_16校验值
        /// </summary>
        public static byte[] Crc16(byte[] data, int offset, int len)
        {
            ushort crc = Crc16(TBL_CRC_16, data, offset, len);
            return new byte[]
            {
                (byte)(crc >> 8),
                (byte)(crc & 0x00FF)
            };
        }
    }
}
