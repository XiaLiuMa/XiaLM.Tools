﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;


namespace Jtkz.Common.Decision
{
    /// <summary>
    /// 决策仓库
    /// </summary>
    public class DecisionRepository
    {
        /// <summary>
        /// 决策条件仓库
        /// </summary>


        internal ConcurrentDictionary<Type, DecisionItem> dic = new ConcurrentDictionary<Type, DecisionItem>();
    

        public T pickupDecisionItem<T>()
        where T : DecisionItem, new()
        {
            DecisionItem obj = default(T);
            dic.TryGetValue(typeof(T), out obj);
            if (obj == null)
            {
                obj = new T();
                obj.PropertyChanged += item_PropertyChanged;
                dic.TryAdd(typeof(T), obj);
            }
            return (T)obj;
        }

    internal  Dictionary<Type, List<DecisionAction>> _actionDictionary = new Dictionary<Type, List<DecisionAction>>();

        private static readonly object lockobj = new object();
        private async void item_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            lock (lockobj)
            {
                Type pType = sender.GetType();

                if (_actionDictionary.ContainsKey(pType))
                {
                    //_actionDictionary[pType].ForEach(p =>
                    //{
                    //    p.SendState(this);
                    //});

                    var task = _actionDictionary[pType]
                        .Select(p => Task.Factory.StartNew(() => { p.SendState(this); }, TaskCreationOptions.PreferFairness
                            )
                        );
                    Task.WaitAll(task.ToArray());
                }
            }
        }


        internal void regist<T>(Type memberInfo, DecisionAction<T> decisionAction)
        {
            lock (lockobj)
            {
                if (_actionDictionary.ContainsKey(memberInfo))
                {
                    _actionDictionary[memberInfo].Add(decisionAction);
                }
                else
                {
                    List<DecisionAction> lst = new List<DecisionAction>();
                    lst.Add(decisionAction);
                    _actionDictionary.Add(memberInfo, lst);
                }
            }
        }

        internal void Unregist<T>(Type memberInfo, DecisionAction<T> decisionAction)
        {
            lock (lockobj)
            {
                if (_actionDictionary.ContainsKey(memberInfo))
                {
                    var obj = _actionDictionary[memberInfo].FirstOrDefault(c => c.Equals(decisionAction));

                    if (obj != null)
                    {
                        _actionDictionary[memberInfo].Remove(obj);
                        if (!_actionDictionary[memberInfo].Any())
                        {
                            _actionDictionary.Remove(memberInfo);
                        }
                    }
                }
            }
        }
    }

    /// <summary>
    /// 决策项
    /// </summary>

    public abstract class DecisionItem : INotifyPropertyChanged
    {
        private bool _state;

        /// <summary>
        /// 标签项
        /// </summary>

        public object Tag { get; set; }

        /// <summary>
        /// 决策项状态
        /// </summary>
        public bool State
        {
            get => _state;
            set
            {
                if (value == _state) return;
                _state = value;
                OnPropertyChanged();
            }
        }

        public string ErrMsg { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;


        private static readonly object lockobj = new object();
       
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

            
        }

        public void SetState(bool b, string ErrorMsg = null, object tag = null)
        {
            State = b;
            this.ErrMsg = ErrorMsg ?? String.Empty;
            this.Tag = tag;
        }


    }




    public class DecisionAction<T> : DecisionAction, IDecisionAction<T>, IDisposable
    {
        internal Func<T, bool> where;
        internal Expression<Func<DecisionRepository, T>> Select;

        private Lazy<IEnumerable<Type>> MeberTypes;
        internal DecisionRepository Repository { get; set; }
        public Action<T> SubscibeAction { get; set; }

        public DecisionAction()
        {
            MeberTypes = new Lazy<IEnumerable<Type>>(() =>
            {
                var con = (NewExpression)Select.Body;

                return con.Members.Select(p => ((PropertyInfo)p).PropertyType);
            });
        }

        public void Dispose()
        {
            foreach (var memberInfo in MeberTypes.Value)
            {
                Repository.Unregist(memberInfo, this);
            }
        }

        internal void MadeSubscibe()
        {
            foreach (var memberInfo in MeberTypes.Value)
            {
                Repository.regist(memberInfo, this);
            }
        }

        internal override void SendState(DecisionRepository decisionRepository)
        {
            var obj = Select.Compile().Invoke(decisionRepository);
            if (@where != null)
            {
                var b = @where(obj);
                if (@where(obj))
                    SubscibeAction(obj);
            }
            else
            {
                SubscibeAction(obj);
            }

        }
    }


    public abstract class DecisionAction
    {
        internal abstract void SendState(DecisionRepository decisionRepository);

    }
    public interface IDecisionAction<out T>
    {

    }

    public static class DecisionRepositoryEx
    {
        public static IDecisionAction<T> Select<T>(this DecisionRepository repository, Expression<Func<DecisionRepository, T>> func)
        {
            return new DecisionAction<T>()
            {
                Select = func,
                Repository = repository
            };
        }

        public static IDecisionAction<T> where<T>(this IDecisionAction<T> DecisionAction, Func<T, bool> func)
        {
            DecisionAction<T> send = (DecisionAction<T>)DecisionAction;

            return new DecisionAction<T>()
            {
                Select = send.Select,
                @where = func,
                Repository = send.Repository
            };
        }

        public static IDisposable Subscibe<T>(this IDecisionAction<T> DecisionAction, Action<T> action)
        {
            DecisionAction<T> send = (DecisionAction<T>)DecisionAction;

            DecisionAction<T> res = new DecisionAction<T>()
            {
                Select = send.Select,
                @where = send.@where,
                SubscibeAction = action,
                Repository = send.Repository
            };
            res.MadeSubscibe();
            return res;
        }


    }
}