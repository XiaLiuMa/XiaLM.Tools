﻿
// namespaces...
namespace Isolator.common.runtimeService
{
    // public interfaces...
    /// <summary>
    /// 系统自启动服务接口
    /// </summary>
    public interface IRuntimeService
    {
        // properties...
        /// <summary>
        /// 用于标记当前服务是否已启动
        /// </summary>
        bool IsRuning { get; }
        /// <summary>
        /// 启动顺序
        /// </summary>
        int StartOrder { get; }

        // methods...
        /// <summary>
        /// 停止服务
        /// </summary>
        void Shutdown();
        /// <summary>
        /// 启动服务
        /// </summary>
        void Startup();
    }
}
