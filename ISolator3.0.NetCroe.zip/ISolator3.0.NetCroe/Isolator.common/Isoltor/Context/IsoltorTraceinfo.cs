﻿
// namespaces...

using System.Security.Policy;

namespace Isolator.common.Isoltor.Context
{
    // public classes...
    /// <summary>
    /// 隔离器跟踪对象
    /// </summary>
    public class IsoltorTraceinfo : AbsApplicationTraceInfo
    {
        
    }
}
