﻿
// namespaces...
namespace Isolator.common.Isoltor.Context
{
    // public classes...
    /// <summary>
    /// 消息队列跟踪对象
    /// </summary>
    public class MQTraceInfo : AbsApplicationTraceInfo
    {
    }
}
