﻿
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Composition;
using System.Linq;
using Isolator.common.SerialportControl;
using Schedule.model;
using Schedule.model.common;

// namespaces...
namespace Isolator.common.Isoltor.Context
{
    // public classes...
    /// <summary>
    /// 系统级公用上下文
    /// </summary>
    [Export]
    public class ApplicationContext : INotifyPropertyChanged
    {
        // private fields...
        private static readonly Lazy<ApplicationContext> layzInstance = new Lazy<ApplicationContext>(() =>
        {
            return new ApplicationContext();
        });
        private static readonly Lazy<IsoltorSeriaPort.SerialportDispatch> lazySerialportDispatch = new Lazy<IsoltorSeriaPort.SerialportDispatch>(() =>
        {
            var comconfig = SerializationHelper.Load<List<SerialPortConfig>>(AppDomain.CurrentDomain.BaseDirectory + @"config\SerialPort.xml");
            var comdispatch = new IsoltorSeriaPort.SerialportDispatch();
            comdispatch.InitSerialport(comconfig);
            return comdispatch;

        });
        public ObservableCollection<AbsApplicationTraceInfo> TraceInfo = new ObservableCollection<AbsApplicationTraceInfo>();

        // public constructors...
        public ApplicationContext()
        {
            getmqConfig();
            TraceInfo.CollectionChanged += TraceInfo_CollectionChanged;
        }

        // public events...
        public event PropertyChangedEventHandler PropertyChanged;

        // public properties...
        /// <summary>
        /// 上下文实例，单件
        /// </summary>
        public static ApplicationContext Instance
        {
            get
            {
                return layzInstance.Value;
            }
        }
        public List<IsoltorTraceinfo> IsoltorTraceinfoLst
        {
            get
            {
                return TraceInfo.OfType<IsoltorTraceinfo>().ToList();
            }
        }
        /// <summary>
        /// 获取mqconfig
        /// </summary>
        public RabbitMqConfig MqConfig { get; private set; }
        public List<MQTraceInfo> MQTraceInfoLst
        {
            get
            {
                return TraceInfo.OfType<MQTraceInfo>().ToList();
            }
        }
        public IsoltorSeriaPort.SerialportDispatch SerialportDispatch
        {
            get
            {
                return lazySerialportDispatch.Value;
            }
        }

        // private methods...
        private void getmqConfig()
        {
            MqConfig = SerializationHelper.Load<RabbitMqConfig>(AppDomain.CurrentDomain.BaseDirectory+@"config\rabbitmq.xml");
        }
        private void TraceInfo_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(sender, new PropertyChangedEventArgs(string.Empty));
            }
        }
    }
}
