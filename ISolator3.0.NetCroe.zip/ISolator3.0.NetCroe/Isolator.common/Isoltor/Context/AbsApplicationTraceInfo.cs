﻿
// namespaces...
namespace Isolator.common.Isoltor.Context
{
    // public classes...
    /// <summary>
    /// 系统运行跟踪对象
    /// </summary>
    public abstract class AbsApplicationTraceInfo
    {
        // public properties...
        public string Msg { get; set; }
    }
}
