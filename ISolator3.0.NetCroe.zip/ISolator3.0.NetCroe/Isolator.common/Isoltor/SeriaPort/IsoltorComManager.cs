﻿using System;
using System.Linq;
using System.Threading;
using Isolator.common.Isoltor.Context;
using Isolator.common.Isoltor.MQQueue;
using Isolator.common.IsoltorSeriaPort;
using Schedule.Common.log;
using System.Diagnostics;
using Schedule.Common.Util;
using System.Threading.Tasks.Dataflow;

// namespaces...
namespace Isolator.common.Isoltor.SeriaPort
{
    // public classes...
    public class IsoltorComManager : IDisposable
    {
        // private fields...
        private CancellationTokenSource cts = new CancellationTokenSource();

        // public constructors...
        public IsoltorComManager()
        {
        }

        // public properties...
        public static Context.ApplicationContext context
        {
            get
            {
                return Context.ApplicationContext.Instance;
            }
        }

        // public methods...
        public void Dispose()
        {
            cts.Cancel();
        }

        public CancellationTokenSource _CancellationTokenSourceBasicDeliverEventArgs = new CancellationTokenSource();

        private ActionBlock<SerialPortReceiveArg> SerialPortData_ActionBlock;

        public void StartSerialPortData_ActionBlock()
        {
            var jobs = context.MqConfig.Publishs.SelectMany(p => p.Jobs, (pub, job) => new { pub, job });


            var SerialportDispatch = context.SerialportDispatch;

            SerialPortData_ActionBlock = new ActionBlock<SerialPortReceiveArg>((p) =>
                {
                    ReceiveHanlder.Instance.PostReceive(p);
                }, new ExecutionDataflowBlockOptions() { MaxDegreeOfParallelism = 3, BoundedCapacity = 100, CancellationToken = _CancellationTokenSourceBasicDeliverEventArgs.Token });
        }

        // private static int sendcount;
        public void startListen()
        {
            var SerialportDispatch = context.SerialportDispatch;
            SerialportDispatch.Receive().Subscribe(p =>
                {
                    if (SerialPortData_ActionBlock != null)
                    {
                        SerialPortData_ActionBlock.Post(p);
                    }
                });
        }
    }

    public class SerialPortData
    {
        public SerialPortReceiveArg p { get; set; }
    }
}
