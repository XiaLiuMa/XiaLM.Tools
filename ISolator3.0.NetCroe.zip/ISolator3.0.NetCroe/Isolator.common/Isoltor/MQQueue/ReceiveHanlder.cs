﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Isolator.common.Isoltor.Context;
using Isolator.common.IsoltorSeriaPort;
using Isolator.common.Util;
using Schedule.Common.log;

namespace Isolator.common.Isoltor.MQQueue
{
    public class ReceiveHanlder
    {
        private static readonly Lazy<ReceiveHanlder> _ReceiveHanlder=new Lazy<ReceiveHanlder>(()=>new ReceiveHanlder());

        private static readonly Dictionary<Guid, SortedDictionary<int, DataPackage>> _daDictionary = new Dictionary<Guid, SortedDictionary<int, DataPackage>>();


        private static readonly BlockingCollection<MqDataPackage> _preMqBlockingCollection = new BlockingCollection<MqDataPackage>();

        private static readonly BlockingCollection<SerialPortReceiveArg> _serialPortReceiveArgs =
            new BlockingCollection<SerialPortReceiveArg>();

        public static ReceiveHanlder Instance
        {
            get { return _ReceiveHanlder.Value; }
        }

        public ReceiveHanlder()
        {
            var jobs = ApplicationContext.Instance.MqConfig.Publishs.SelectMany(p => p.Jobs, (pub, job) => new { pub, job });



            //为加快消费，同时对待发送mq数据建立5个消费
            for (int i = 0; i < 5; i++)
            {
                Task.Factory.StartNew(() =>
                {
                    foreach (var package in _preMqBlockingCollection.GetConsumingEnumerable())
                    {
                        try
                        {
                            var job = jobs.FirstOrDefault(c => c.job.Name.Equals(package.JobName));
                            if (job != null)
                            {
                                MQmanage.Publish(job.pub.ExchangeName, job.pub.ExchangeKey, package.MqData,
                                    job.job.Priority, false, 0, job.job.Name);
                            }
                            // Console.WriteLine(package.JobName);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);

                        }
                    }
                }, TaskCreationOptions.LongRunning);
            }

            for (int i = 0; i < 5; i++)
            {

                Task.Factory.StartNew(() =>
                {
                    foreach (var p in _serialPortReceiveArgs.GetConsumingEnumerable())
                    {
                        Console.WriteLine(
                            $"{p.ComRx.config.PortName}: {p.DataPackage.TotalPage}/{p.DataPackage.CurrentPage}");

                        if (!p.DataPackage.CheckCrc())
                        {
                            Console.WriteLine(
                                $"{p.Com}: {p.DataPackage.TotalPage}/{p.DataPackage.CurrentPage} CRC校验失败");

                            var errpackage = DataPackageUtil.CreateCrcErrPackages(p.DataPackage.MsgKey,
                                p.DataPackage.TotalPage,
                                p.DataPackage.CurrentPage);
                            p.ComRx.Send(errpackage.Encode());

                        }
                        else
                        {

                            lock (_daDictionary)
                            {
                                if (_daDictionary.ContainsKey(p.DataPackage.MsgKey))
                                {
                                    if (_daDictionary[p.DataPackage.MsgKey].ContainsKey(p.DataPackage.CurrentPage))
                                    {
                                        _daDictionary[p.DataPackage.MsgKey][p.DataPackage.CurrentPage] =
                                            p.DataPackage;
                                    }
                                    else
                                    {
                                        _daDictionary[p.DataPackage.MsgKey]
                                            .Add(p.DataPackage.CurrentPage, p.DataPackage);
                                    }


                                }
                                else
                                {
                                    SortedDictionary<int, DataPackage> dataSortedDictionary =
                                        new SortedDictionary<int, DataPackage>();
                                    dataSortedDictionary.Add(p.DataPackage.CurrentPage, p.DataPackage);

                                    _daDictionary.Add(p.DataPackage.MsgKey, dataSortedDictionary);
                                }

                                Console.WriteLine(
                                    $"---------{p.DataPackage.TotalPage}/{_daDictionary[p.DataPackage.MsgKey].Count}");
                                if (p.DataPackage.TotalPage == _daDictionary[p.DataPackage.MsgKey].Count)
                                {

                                    var data = _daDictionary[p.DataPackage.MsgKey].SelectMany(c => c.Value.Data)
                                        .ToArray();
                                    MqDataPackage package = null;
                                    if (p.DataPackage.TotalPage == 1)
                                    {
                                        package = new MqDataPackage();
                                        package.DeEncode(data);
                                        string strtem = Encoding.UTF8.GetString(package.MqData);

                                        LogHelp.Info("收到数据："+strtem);
                                        //Console.WriteLine($"{p.Com}收到数据：{package.JobName}/{strtem}");
                                        _daDictionary.Remove(p.DataPackage.MsgKey);


                                    }
                                    else
                                    {
                                        var last = _daDictionary[p.DataPackage.MsgKey].Last();
                                        var oldmd5 = last.Value.Md5Bytes;
                                        var newmd5 = data.ToArray().getMD5bytes();
                                        if (oldmd5.SequenceEqual(newmd5))
                                        {
                                            package = new MqDataPackage();
                                            package.DeEncode(data);


                                            Console.WriteLine("Md5校验成功");

                                        }
                                        else
                                        {

                                            Console.WriteLine("MD5校验失败");
                                        }

                                        _daDictionary.Remove(p.DataPackage.MsgKey);
                                    }

                                    if (package != null)
                                    {
                                        if (p.DataPackage.CommandEnum == IsotorProtocolCommandEnum.SendAck)
                                            p.ComRx.Send(DataPackageUtil.CreateAckBackPackage(p.DataPackage.MsgKey,
                                                IsotorProtocolCommandEnum.AckOK).Encode());


                                        _preMqBlockingCollection.Add(package);

                                    }
                                    else
                                    {
                                        if (p.DataPackage.CommandEnum == IsotorProtocolCommandEnum.SendAck)
                                        {
                                            p.ComRx.Send(DataPackageUtil.CreateAckBackPackage(p.DataPackage.MsgKey,
                                                IsotorProtocolCommandEnum.AckError).Encode());
                                        }
                                    }


                                }
                            }


                        }




                        GC.Collect(2);
                    }

                }, TaskCreationOptions.LongRunning);



            }

        }

        public void PostReceive(SerialPortReceiveArg p)
        {
            _serialPortReceiveArgs.Add(p);
        }

    }
}