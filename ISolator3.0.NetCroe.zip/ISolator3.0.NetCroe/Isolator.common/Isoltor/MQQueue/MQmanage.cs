﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Isolator.common.Isoltor.Context;
using Isolator.common.IsoltorSeriaPort;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using Schedule.Common.log;
using Schedule.Common.Core.Send.MqSend;

using Schedule.model;
using System.Collections.Concurrent;
using System.Reactive.Linq;
using System.Text.RegularExpressions;
using Schedule.Common.Util;
using System.Threading.Tasks.Dataflow;
using Isolator.common.IsoltorSeriaPort.DecisionIMPL;
using Jtkz.Common.Decision;

// namespaces...
namespace Isolator.common.Isoltor.MQQueue
{
    // public classes...
    public class MQmanage
    {
        // private fields...
        /// <summary>
        /// 消费者池 这里暂时只考虑一个RABBITMQ的情况
        /// </summary>
        private static ConnectionPool Consumerpool;
        /// <summary>
        /// 生产者连接池 这里暂时只考虑一个RABBITMQ的情况
        /// </summary>
        private static ConnectionPool Productpool;

        // private properties...
        private static Context.ApplicationContext context
        {
            get
            {
                return Context.ApplicationContext.Instance;
            }
        }

        // public properties...
        public static RabbitMqConfig MqConfig { get; private set; }

        public static CancellationTokenSource _CancellationTokenSourceBasicDeliverEventArgs = new CancellationTokenSource();

        private static ActionBlock<MqData> MqData_ActionBlock;

        public static void StartMqData_ActionBlock()
        {
            MqData_ActionBlock = new ActionBlock<MqData>((item) =>
            {
                item.SendData();
            }, new ExecutionDataflowBlockOptions() { MaxDegreeOfParallelism = 3, BoundedCapacity = 100, CancellationToken = _CancellationTokenSourceBasicDeliverEventArgs.Token });

        }

        // private methods...
        /// <summary>
        /// 从队列中接收到消息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private static void consumer_Received(object sender, BasicDeliverEventArgs e)
        {

            if (MqData_ActionBlock != null)
            {
                MqData data = new MqData();
                data.sender = sender as EventingBasicConsumer;
                data.e = e;
                MqData_ActionBlock.Post(data);
            }

        }


        private static void ExchangeDeclare(ConnectionFactory factory)
        {
            try
            {
                if (MqConfig.Publishs == null || MqConfig.Publishs.Count == 0)
                {
                    return;
                }
                using (var channel = Productpool.GetOrCreateChannel())
                {
                    var model = channel.Model;
                    MqConfig.Publishs.ForEach(r =>
                        {
                            if (!string.IsNullOrWhiteSpace(r.ExchangeName))
                            {
                                model.ExchangeDeclare(r.ExchangeName, r.ExchangeType, true);
                            }
                        });
                }
            }
            catch (Exception ex)
            {
                LogHelp.Error("MQ初始化申明路由时失败 ", ex);
            }
        }
        private static bool findAckDefine(RabbitMQ.Client.Events.BasicDeliverEventArgs basicDeliverEventArgs)
        {
            var res = false;
            //2017-01-20 修改topic方式，key不等，故采用正则匹配
            // var consumer = context.MqConfig.Consumers.FirstOrDefault(c => c.ExchangeKey==basicDeliverEventArgs.RoutingKey && c.ExchangeName == basicDeliverEventArgs.Exchange);
            var consumer = context.MqConfig.Consumers.FirstOrDefault(c => Regex.IsMatch(basicDeliverEventArgs.RoutingKey, c.ExchangeKey.Replace(".", @"\."), RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace) && c.ExchangeName == basicDeliverEventArgs.Exchange);
            if (consumer != null)
            {
                res = consumer.IsAck;
            }
            return res;
        }
        /// <summary>
        /// 申明队列
        /// </summary>
        /// <param name="factory"></param>
        private static void QueueDeclare(ConnectionFactory factory)
        {
            try
            {
                if (MqConfig.Consumers == null || MqConfig.Consumers.Count == 0)
                {
                    return;
                }
                using (var channel = Productpool.GetOrCreateChannel())
                {
                    var model = channel.Model;
                    MqConfig.Consumers.ForEach(r =>
                        {
                            IDictionary<string, object> queueParams = new Dictionary<string, object>();
                            if (r.IsPriority)
                            {
                                queueParams.Add("x-max-priority", r.PrioritySize);
                            }
                            if (r.IsTtl)
                            {
                                queueParams.Add("x-message-ttl", r.TtlTime);
                            }

                            model.QueueDeclare(r.QueueName, true, false, false, queueParams);


                            if (!string.IsNullOrWhiteSpace(r.ExchangeName))
                            {
                                model.QueueBind(r.QueueName, r.ExchangeName, r.ExchangeKey);
                            }
                        });
                }
            }
            catch (Exception ex)
            {
                LogHelp.Error("MQ初始化申明队列时失败 ", ex);
            }
        }

        // public methods...
        /// <summary>
        /// 消费者注册。这里以事件的方式来接收消费者信息
        /// </summary>
        public static void ConsumeRegist()
        {
            try
            {
                if (MqConfig.Consumers == null || MqConfig.Consumers.Count == 0)
                {
                    return;
                }
                MqConfig.Consumers.ForEach(r =>
                    {
                        if (r.IsListen)
                        {
                            dyConsumer(r);
                        }
                    });
            }
            catch (Exception ex)
            {
                LogHelp.Error("MQ 绑定消费者失败", ex);
            }
        }

        private static readonly HashSet<EventingBasicConsumer> ConsumerHashset = new HashSet<EventingBasicConsumer>();
        private static void dyConsumer(ConsumerConfig r)
        {

            using (var channel = Consumerpool.CreateChannel())

            {

                channel.Model.BasicQos(0, 1, false);
                var consumer = new EventingBasicConsumer(channel.Model);
                channel.Model.BasicConsume(r.QueueName, !r.IsAck, consumer);
                consumer.Received += consumer_Received;
                channel.Model.ModelShutdown += (o, e) =>
                {
                    if (context.SerialportDispatch.repository.pickupDecisionItem<gaState>().State)
                    {
                        lock (ConsumerHashset)
                        {
                            ConsumerHashset.Remove(consumer);
                        }

                        LogHelp.Error("梅沙端软件崩溃 E 值"+e.ToString());
                        Console.WriteLine("梅沙端软件崩溃 E 值"+e);

                        Thread.Sleep(30000);
                        dyConsumer(r);
                    }

                };
                lock (ConsumerHashset)
                {
                    
                    ConsumerHashset.Add(consumer);
                }

            }
        }


        /// <summary>
        /// 初始化RABBIT
        /// </summary>
        public static void Init()
        {

            MqConfig = context.MqConfig;
            var uri = new Uri(string.Format("qmqp://{0}:{1}", MqConfig.Ip, MqConfig.Port));

            var factory = new ConnectionFactory();
            factory.Endpoint = new AmqpTcpEndpoint(uri);
            factory.VirtualHost = MqConfig.Vhost;
            factory.UserName = MqConfig.Use;
            factory.Password = MqConfig.Pwd;
            //factory.AutomaticRecoveryEnabled = true;
            //factory.RequestedHeartbeat = 60;

            Productpool = new ConnectionPool(factory, MqConfig.ConnPool);
            Productpool.ChannelPool = MqConfig.ChannelPool;

            Consumerpool = new ConnectionPool(factory, MqConfig.ConnPool);
            Consumerpool.ChannelPool = MqConfig.ChannelPool;


            ExchangeDeclare(factory);
            QueueDeclare(factory);
            isRun = true;




        }
        private readonly static object lckObj = new object();
        /// <summary>
        /// 发送数据
        /// </summary>
        /// <param name="exchange">路由</param>
        /// <param name="routingKey">路由键</param>
        /// <param name="body">内容</param>
        /// <param name="priority">优先级(0-9)</param>
        /// <param name="persistence">是否持久化</param>
        /// <param name="expiration">过期时间</param>
        public static void Publish(string exchange, string routingKey, byte[] body, int priority, bool persistence, int expiration = 0, string jobName = "")
        {
            lock (lckObj)
            {
                using (var channel = Productpool.GetOrCreateChannel())
                {
                    var properties = channel.Model.CreateBasicProperties();


                    if (priority >= 0)
                    {
                        properties.Priority = (byte)priority;
                    }


                    if (persistence)
                    {
                        properties.DeliveryMode = 2;
                    }


                    if (expiration > 1)
                    {
                        properties.Expiration = (expiration * 1000).ToString();
                    }

                    properties.MessageId = jobName;

                    channel.Model.BasicPublish(exchange, routingKey, properties, body);
                }
            }
        }

        private static bool isRun;
        public static void stop()
        {
            isRun = false;
            Consumerpool.Dispose();
            Productpool.Dispose();

        }


      
        public static void UnConsumeRegist()
        {
            lock (ConsumerHashset)
            {
                foreach (var eventingBasicConsumer in ConsumerHashset)
                {
                    eventingBasicConsumer.Model.Dispose();
                }
                ConsumerHashset.Clear();
            }

        }
    }

    public class MqData
    {
        private static readonly HashSet<Guid> hashSet = new HashSet<Guid>();


        public static Guid GetGuid()
        {
            lock (hashSet)
            {
                Guid res = Guid.Empty;

                while (true)
                {
                    res = Guid.NewGuid();
                    if (!hashSet.Any(c => c.Equals(res)))
                    {

                        hashSet.Add(res);
                        return res;
                    }
                }
            }


        }
        public EventingBasicConsumer sender { get; set; }
        public BasicDeliverEventArgs e { get; set; }

        private ApplicationContext context = Context.ApplicationContext.Instance;

        private Guid MsgId;
        public async Task SendData()
        {

            this.MsgId = GetGuid();
            var jobName = e.BasicProperties.MessageId;
            var jobs = context.MqConfig.Publishs.SelectMany(p => p.Jobs, (pub, job) => new { pub, job });

            MqDataPackage mqDataPackage = new MqDataPackage()
            {
                JobName = jobName,
                MqData = e.Body
            };

            var sendData = mqDataPackage.Encode();

            var isAck = findAckDefine();
            if (isAck)
            {
                await SendToIsolatorWithAck(sendData);
                lock (hashSet)
                {
                    try
                    {
                        hashSet.Remove(this.MsgId);
                    }
                    catch (Exception exception)
                    {

                    }

                }
            }
            else
            {
                SendToIsolatorWithNOAck(sendData).ContinueWith(p =>
                {
                    lock (hashSet)
                    {
                        hashSet.Remove(this.MsgId);
                    }
                });
            }
        }

        private static readonly SemaphoreSlim _semaphore = new SemaphoreSlim(1);
        async Task<bool> SendToIsolatorWithAck(byte[] data)
        {

            Console.WriteLine($"收到{e.DeliveryTag}");
            Console.WriteLine("收到数据参数>>DeliveryTag："+ e.DeliveryTag+ ">>Exchange：" + e.Exchange+ ">>RoutingKey：" + e.RoutingKey+ ">>ConsumerTag：" + e.ConsumerTag+ ">>Redelivered：" + e.Redelivered);
            CancellationTokenSource cts = new CancellationTokenSource();
            CancellationToken token = cts.Token;

            var task = Task<bool>.Factory.StartNew(() =>
               {
                   TaskCompletionSource<bool> tcs = new TaskCompletionSource<bool>();
                   context.SerialportDispatch.ReceiveAck()
                       .Where(p => p.DataPackage.MsgKey == this.MsgId).FirstOrDefaultAsync()
                       .Subscribe(p =>
                       {
                           if (p.DataPackage.CommandEnum == IsotorProtocolCommandEnum.AckError)
                           {

                               tcs?.SetResult(false);
                           }
                           else if (p.DataPackage.CommandEnum == IsotorProtocolCommandEnum.AckOK)
                           {

                               tcs?.SetResult(true);
                           }

                           tcs = null;


                       }, token);
                   return tcs.Task.Result;
               });

            var b = await context.SerialportDispatch.Send(data, MsgId, e.BasicProperties.Priority, IsotorProtocolCommandEnum.SendAck);


            task.Wait(TimeSpan.FromMilliseconds(10 * 1000));


            if (task.Status == TaskStatus.Running)
            {
                Console.WriteLine($"归还{e.DeliveryTag}");
                Console.WriteLine("归还数据参数>>DeliveryTag：" + e.DeliveryTag + ">>Exchange：" + e.Exchange + ">>RoutingKey：" + e.RoutingKey + ">>ConsumerTag：" + e.ConsumerTag + ">>Redelivered：" + e.Redelivered);
                sender.Model.BasicNack(e.DeliveryTag, false, true);
            }
            else
            {
                Console.WriteLine($"确认{e.DeliveryTag}");
                Console.WriteLine("确认数据参数>>DeliveryTag：" + e.DeliveryTag + ">>Exchange：" + e.Exchange + ">>RoutingKey：" + e.RoutingKey + ">>ConsumerTag：" + e.ConsumerTag + ">>Redelivered：" + e.Redelivered);
                sender.Model.BasicAck(e.DeliveryTag, false);

            }





            return b;

            //  return true;

        }

        async Task<bool> SendToIsolatorWithNOAck(byte[] data)
        {
            context.SerialportDispatch.Send(data, MsgId, e.BasicProperties.Priority, IsotorProtocolCommandEnum.SendNoAck);
            return true;
        }

        private bool findAckDefine()
        {
            var res = false;


            var consumer1 = context.MqConfig.Consumers.FirstOrDefault(c => c.ExchangeKey.Equals(e.RoutingKey));
            if (consumer1 != null)
            {
                res = consumer1.IsAck;
                Console.WriteLine("实时数据MQ队列：" + e.RoutingKey + "----回复确认：" + res);
            }
            else
            {
                var consumer = context.MqConfig.Consumers.FirstOrDefault(c => Regex.IsMatch(e.RoutingKey, c.ExchangeKey.Replace(".", @"\."), RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace) && c.ExchangeName == e.Exchange);
                if (consumer != null)
                {
                    res = consumer.IsAck;
                    Console.WriteLine("基础数据、统计数据MQ队列：" + e.RoutingKey + "----回复确认：" + res);

                }
            }
                    
         

            //2017-01-20 修改topic方式，key不等，故采用正则匹配
            // var consumer = context.MqConfig.Consumers.FirstOrDefault(c => c.ExchangeKey==basicDeliverEventArgs.RoutingKey && c.ExchangeName == basicDeliverEventArgs.Exchange);
            //var consumer = context.MqConfig.Consumers.FirstOrDefault(c => Regex.IsMatch(e.RoutingKey, c.ExchangeKey.Replace(".", @"\."), RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace) && c.ExchangeName == e.Exchange);
            //if (consumer != null)
            //{
            //    res = consumer.IsAck;
            //}
            return res;
        }

        public static void RemoveMsgid(Guid guid)
        {
            lock (hashSet)
            {
                hashSet.Remove(guid);
            }
        }
    }
}
