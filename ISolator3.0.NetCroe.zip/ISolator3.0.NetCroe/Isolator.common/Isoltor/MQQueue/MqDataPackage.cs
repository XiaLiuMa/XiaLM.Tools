﻿using System;
using System.Collections.Generic;

namespace Isolator.common.Isoltor.MQQueue
{
    /// <summary>
    /// mq数据包
    /// </summary>
    public class MqDataPackage
    {
        public string JobName { get; set; }
        public byte[] MqData { get; set; }

        private int jobnameLength;
        /// <summary>
        /// 编码
        /// </summary>
        /// <returns></returns>
        public byte[] Encode()
        {
            byte[] jobBytes = System.Text.Encoding.Default.GetBytes(JobName);


            byte[] data=new byte[4+jobBytes.Length+MqData.Length];
            jobnameLength = jobBytes.Length;
            Buffer.BlockCopy(BitConverter.GetBytes(jobBytes.Length),0,data,0,4);
            Buffer.BlockCopy(jobBytes,0,data,4,jobBytes.Length);
            Buffer.BlockCopy(MqData, 0, data, 4 + jobnameLength, MqData.Length);

            return data;
        }

        /// <summary>
        /// 解码
        /// </summary>
        /// <param name="data"></param>
        public void DeEncode(byte[] data)
        {
            this.jobnameLength = BitConverter.ToInt32(data, 0);

            this.JobName = System.Text.Encoding.Default.GetString(data, 4, jobnameLength);

            this.MqData=new byte[data.Length-4-jobnameLength];
            Buffer.BlockCopy(data, 4 + jobnameLength, MqData,0, MqData.Length);
        }
    }
}