﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reactive.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using Isolator.common.SerialportControl;
using System.Threading;
using System.Xml.Schema;
using Isolator.common.Isoltor.MQQueue;
using Isolator.common.IsoltorSeriaPort.DecisionIMPL;
using Isolator.common.PriorityQueue;
using Jtkz.Common.Decision;
using Schedule.Common.log;
using Microsoft.Extensions.Caching.Memory;

// namespaces...
namespace Isolator.common.IsoltorSeriaPort
{
    // public classes...
    /// <summary>
    /// 串口发送调度
    /// </summary>
    public class SerialportDispatch
    {


        private IObservable<SerialPortReceiveArg> _Receive = Observable.Empty<SerialPortReceiveArg>();

        private PriorityQueue<DataPackage> _priorityQueue = new PriorityQueue<DataPackage>(21);

        private event Action<SerialPortReceiveArg> _ondata = p => { };

        private event Action<Tuple<DateTime, int>> _onPostData = p => { };

        private IObservable<Tuple<DateTime, int>> _postDataObservable = Observable.Empty<Tuple<DateTime, int>>();

        //private readonly ObjectCache _sendCache = new MemoryCache("sendCache");
        private static MemoryCache cache = new MemoryCache(new MemoryCacheOptions());     //UNDONE:（不确定是否可行）

        public DecisionRepository repository = new DecisionRepository();

        public SerialportDispatch()
        {


            _Receive = Observable.FromEvent<SerialPortReceiveArg>(p => this._ondata += p, p => this._ondata -= p);
            _postDataObservable =
                Observable.FromEvent<Tuple<DateTime, int>>(p => this._onPostData += p,
                    p => this._onPostData -= p);
            _Receive.Where(p => p.DataPackage.CommandEnum == IsotorProtocolCommandEnum.CrcError).Subscribe(p =>
            {
                //CRC校验错误，从缓存中获取，并重新加入发送队列,为尽快确认,重新放入优先级高的队列

                var obj = (DataPackage)cache.Get($"{p.DataPackage.MsgKey}/{p.DataPackage.TotalPage}/{p.DataPackage.CurrentPage}");

                if (obj != null)
                {
                    _priorityQueue.TryAdd(19, obj);
                    cache.Remove($"{p.DataPackage.MsgKey}/{p.DataPackage.TotalPage}/{p.DataPackage.CurrentPage}");
                }


            });


            var livemsg = _Receive.Where(p => p.DataPackage.CommandEnum == IsotorProtocolCommandEnum.livePack);
            var byebyemsg = _Receive.Where(p => p.DataPackage.CommandEnum == IsotorProtocolCommandEnum.Byebye);

            livemsg.Subscribe(p =>
                repository.pickupDecisionItem<gaState>().SetState(true)
            );

            byebyemsg.Subscribe(p => 
                repository.pickupDecisionItem<gaState>().SetState(false)
                );

            //超时1分钟没有收到存活消息，设置公安端存活状态为false
            livemsg.Throttle(TimeSpan.FromMilliseconds(60 * 1000)).Subscribe(p1 =>
            {
                LogHelp.Info("公安端下线，正在清除发送队列");
                _priorityQueue.clear();
                repository.pickupDecisionItem<gaState>().SetState(false);
            });


        }



        /// <summary>
        /// 初始化端口
        /// </summary>
        /// <param name="configList"></param>
        public void InitSerialport(List<SerialPortConfig> configList)
        {
            foreach (var configItem in configList)
            {
                var comPort = new SerialportRX();
                comPort.setConfig(configItem);
                comPort.Startup();
                IsoltorProtocol IsolatorProtocol = new IsoltorProtocol();
                comPort.Receive(IsolatorProtocol).Subscribe(p =>
                {
                    var obj = new SerialPortReceiveArg()
                    {
                        ComRx = p.comPort,

                        Com = p.comPort.config.PortName,
                        DataPackage = p

                    };
                    this._ondata.Invoke(obj);
                });

                //
                Task.Factory.StartNew(() =>
               {
                   foreach (var sendate in _priorityQueue.GetConsumingEnumerable())
                   {


                       Task.Factory.StartNew(async () =>
                       {
                           //var data = sendate.Encode();
                           //Trace.WriteLine(comPort.config.PortName + ":" + sendate.TotalPage + "/" + sendate.CurrentPage + "---[" +
                           //    BitConverter.ToString(data).Replace("-", " ") + "]");


                           var res = await comPort.Send(sendate.Encode());
                           //保留crc校验错，重新请求的需求，故缓存数据1分钟
                           //CacheItemPolicy policy = new CacheItemPolicy();
                           //policy.AbsoluteExpiration = DateTime.Now.AddMinutes(1);
                           //_sendCache.Add($"{sendate.MsgKey}/{sendate.TotalPage}/{sendate.CurrentPage}", sendate, policy);
                           cache.Set($"{sendate.MsgKey}/{sendate.TotalPage}/{sendate.CurrentPage}", sendate, new MemoryCacheEntryOptions
                           {
                               SlidingExpiration = TimeSpan.FromMinutes(1)
                           });  //UNDONE:（不确定是否可行）

                           this._onPostData(new Tuple<DateTime, int>(DateTime.Now, sendate.DataLength));
                           sendate.SendedAction?.Invoke(res);
                       }, TaskCreationOptions.PreferFairness);
                   }

               }, TaskCreationOptions.LongRunning);
            
            }

           
        }

        async Task test()
        {
            await Task.Delay(TimeSpan.FromMilliseconds(2));

        }

        public IObservable<SerialPortReceiveArg> Receive(Func<SerialPortReceiveArg, bool> where)
        {
            return _Receive.Where(where);
        }
        public IObservable<SerialPortReceiveArg> Receive()
        {
            return _Receive.Where(p => p.DataPackage.CommandEnum == IsotorProtocolCommandEnum.SendAck || p.DataPackage.CommandEnum == IsotorProtocolCommandEnum.SendNoAck);
        }
        public IObservable<SerialPortReceiveArg> ReceiveAck()
        {

            return _Receive.Where(p => p.DataPackage.CommandEnum == IsotorProtocolCommandEnum.AckError || p.DataPackage.CommandEnum == IsotorProtocolCommandEnum.AckOK);
        }

        public IObservable<Tuple<DateTime, int>> PostDataObservable()
        {
            return _postDataObservable;
        }



        private int PageSize = 11 * 1024;

        /// <summary>
        /// 发送数据
        /// </summary>
        /// <param name="data"></param>
        /// <param name="Protocol"></param>
        /// <returns></returns>
        public Task<bool> Send(byte[] data, Guid Inguid, int Priority, IsotorProtocolCommandEnum command = IsotorProtocolCommandEnum.SendNoAck)
        {
            TaskCompletionSource<bool> tcs = new TaskCompletionSource<bool>();

            var pacakage = DataPackageUtil.CreateDataPackages(data, PageSize, Inguid, p =>
            {
                tcs?.SetResult(p);
                tcs = null;

            }, command);


            foreach (var dataPackage in pacakage)
            {
                _priorityQueue.TryAdd(Priority, dataPackage);
            }



            return tcs.Task;

        }
    }

    public class SerialPortReceiveArg
    {
        // public properties...
        public string Com { get; set; }

        public SerialportRX ComRx { get; set; }


        public DataPackage DataPackage { get; set; }


    }
}
