﻿using Jtkz.Common.Decision;

namespace Isolator.common.IsoltorSeriaPort.DecisionIMPL
{
    public class gaState: DecisionItem
    {
        
    }
}