﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Reactive.Linq;
using System.Threading;
using System.Threading.Tasks;
using Isolator.common.SerialportControl;
using Isolator.common.Util;

// namespaces...
namespace Isolator.common.IsoltorSeriaPort
{
    // public classes...
    /// <summary>
    /// 隔离器协议
    /// 协议头 || 消息长度 || 命令字 || 消息key ||数据总包数||当前包|| 数据区 || CRC校验
    /// 协议头2字节： 0xAA,0x55;
    /// 消息长度4字节：int32的字节数组,指消息长度 到crc校验之间的数据长度
    /// 命令字2字节： 0x1000-发送无须确认，0x1010发送并需确认,0x2000 接收正确确认，0x2010 接收失败
    /// 消息key16 字节：Guid字节数组 
    /// 数据区：不定长
    /// Crc检验区2字节
    /// </summary>
    public class IsoltorProtocol : IDisposable
    {
        // private fields...
        private byte[] head = new byte[2] { 0xAA, 0x55 };

        private LinkedList<Func<byte, bool>> CommandList = new LinkedList<Func<byte, bool>>();

        private LinkedListNode<Func<byte, bool>> node = null;


        private CancellationTokenSource cts;

        private IObservable<DataPackage> _dataPackage;

        private event Action<DataPackage> _onDataReceive = p => { };

        private bool isComplete = false;

        private int length;
        private List<byte> tempList = new List<byte>();

        private readonly object lockobj = new object();
        // public constructors...
        public IsoltorProtocol()
        {
            cts = new CancellationTokenSource();
            CancellationToken token = cts.Token;
            Task.Factory.StartNew(() =>
            {
                foreach (byte b in _ReciveDataCollection.GetConsumingEnumerable(token))
                {
                    lock (lockobj)
                    {
                        _postData(b);
                    }


                }
            }, token, TaskCreationOptions.LongRunning, TaskScheduler.Default);

            _dataPackage = Observable.FromEvent<DataPackage>(p => this._onDataReceive += p, p => this._onDataReceive -= p);

            LinkedListNode<Func<byte, bool>> headNode = new LinkedListNode<Func<byte, bool>>(p =>
               {
                   lock (lockobj)
                   {

                       tempList.Add(p);
                       if (tempList.Count < 2)
                       {
                           return false;
                       }
                       else
                       {

                           if (tempList.Skip(tempList.Count - 2).Take(2).SequenceEqual(this.head))
                           {

                               tempList = new List<byte>(tempList.Skip(tempList.Count - 2).Take(2));
                               return true;
                           }
                           else
                           {
                               return false;
                           }

                       }
                   }

               });

            LinkedListNode<Func<byte, bool>> lengthNode = new LinkedListNode<Func<byte, bool>>(p =>
               {
                   lock (lockobj)
                   {
                       tempList.Add(p);
                       if (tempList.Count < 6)
                       {
                           return false;
                       }
                       else
                       {
                           this.length = BitConverter.ToInt32(tempList.ToArray(), 2);
                           return true;
                       }
                   }
               });

            LinkedListNode<Func<byte, bool>> headOLinkedListNode = new LinkedListNode<Func<byte, bool>>(p =>
              {
                  lock (lockobj)
                  {
                      tempList.Add(p);
                      return tempList.Count == 32;
                  }
              });

            LinkedListNode<Func<byte, bool>> DataNode = new LinkedListNode<Func<byte, bool>>(p =>
               {
                   lock (lockobj)
                   {
                       tempList.Add(p);
                       return tempList.Count == length + 32;
                   }
               });

            LinkedListNode<Func<byte, bool>> CrcNode = new LinkedListNode<Func<byte, bool>>(p =>
               {
                   lock (lockobj)
                   {
                       tempList.Add(p);
                       if (tempList.Count == length + 34)
                       {
                           byte[] packageBytes = tempList.Take(length + 34).ToArray();
                           Task.Factory.StartNew(() =>
                           {
                               try
                               {
                                   DataPackage package = new DataPackage();
                                   package.comPort = this.comPort;
                                   package.Decode(packageBytes);

                                   _onDataReceive(package);
                               }
                               catch (Exception e)
                               {
                                   Console.WriteLine(e);
                               }
                           }, TaskCreationOptions.PreferFairness);



                           tempList = new List<byte>(tempList.Skip(length + 34));
                           this.length = 0;

                           return true;
                       }

                       return false;
                   }
               });

            CommandList.AddFirst(headNode);
            CommandList.AddAfter(headNode, lengthNode);
            CommandList.AddAfter(lengthNode, headOLinkedListNode);
            CommandList.AddAfter(headOLinkedListNode, DataNode);
            CommandList.AddAfter(DataNode, CrcNode);
        }

        private void _postData(byte b)
        {
            lock (lockobj)
            {
                if (node == null)
                    node = CommandList.First;
                if (node.Value(b))
                {
                    node = node.NextOrFirst();
                }
            }

        }

        private readonly BlockingCollection<byte> _ReciveDataCollection = new BlockingCollection<byte>();
        internal void PostReciveData(byte ReciveData)
        {


            _postData(ReciveData);

        }



        // public properties...
        /// <summary>
        /// 发送命令枚举
        /// </summary>
        public IsotorProtocolCommandEnum CommandEnum { get; set; }
        public Guid msgKey { get; set; }
        public byte[] SendPack { get; set; }
        public Action<bool> SendedAction { get; set; }
        internal SerialportRX comPort { get; set; }


        public IObservable<DataPackage> Receive()
        {
            return _dataPackage;
        }

        public void Dispose()
        {
            cts?.Cancel();
            cts?.Dispose();
            _ReciveDataCollection?.Dispose();
        }
    }

    /// <summary>
    /// 数据报文包
    /// </summary>
    public class DataPackage
    {

        public byte[] Head => new byte[2] { 0xAA, 0x55 };


        public int DataLength { get; set; }

        public IsotorProtocolCommandEnum CommandEnum { get; set; }

        public Guid MsgKey { get; set; }

        public int TotalPage { get; set; }

        public int CurrentPage { get; set; }

        public byte[] Data { get; set; }

        internal byte[] CrcBytes { get; set; }

        public byte[] Md5Bytes { get; set; }

        internal Action<bool> SendedAction { get; set; }
        internal SerialportRX comPort { get; set; }

        /// <summary>
        /// 编码
        /// </summary>
        /// <returns></returns>
        public byte[] Encode()
        {
            if (Md5Bytes != null)
            {
                return Md5Encode();
            }
            else
            {
                return _Encode();
            }

        }


        public bool CheckCrc()
        {
            byte[] _getEncode = Encode();
            var tempcrc = new ArraySegment<byte>(_getEncode, _getEncode.Length - 2, 2);
            return tempcrc.SequenceEqual(this.CrcBytes);
        }

        private byte[] _Encode()
        {
            byte[] _buffer = new byte[2 + 4 + 2 + 16 + 4 + 4 + Data.Length + 2];

            Buffer.BlockCopy(this.Head, 0, _buffer, 0, 2);
            this.DataLength = Data.Length;
            int temp = Data.Length;
            Buffer.BlockCopy(BitConverter.GetBytes(temp), 0, _buffer, 2, 4);
            Buffer.BlockCopy(BitConverter.GetBytes((Int16)this.CommandEnum), 0, _buffer, 6, 2);
            byte[] keyBytes = MsgKey.ToByteArray();
            Buffer.BlockCopy(keyBytes, 0, _buffer, 8, 16);
            Buffer.BlockCopy(BitConverter.GetBytes(this.TotalPage), 0, _buffer, 24, 4);
            Buffer.BlockCopy(BitConverter.GetBytes(this.CurrentPage), 0, _buffer, 28, 4);
            Buffer.BlockCopy(Data, 0, _buffer, 32, Data.Length);


            byte[] crctemp = new byte[_buffer.Length - 2];
            var crc16 = _buffer.GetCrc16();

            Buffer.BlockCopy(crc16, 0, _buffer, 32 + Data.Length, crc16.Length);

            return _buffer;
        }
        private byte[] Md5Encode()
        {
            byte[] _buffer = new byte[2 + 4 + 2 + 16 + 4 + 4 + Data.Length + Md5Bytes.Length + 2];

            Buffer.BlockCopy(this.Head, 0, _buffer, 0, 2);
            this.DataLength = Data.Length;
            int temp = Data.Length + Md5Bytes.Length;
            Buffer.BlockCopy(BitConverter.GetBytes(temp), 0, _buffer, 2, 4);

            Buffer.BlockCopy(BitConverter.GetBytes((Int16)this.CommandEnum), 0, _buffer, 6, 2);

            byte[] keyBytes = MsgKey.ToByteArray();
            Buffer.BlockCopy(keyBytes, 0, _buffer, 8, 16);
            Buffer.BlockCopy(BitConverter.GetBytes(this.TotalPage), 0, _buffer, 24, 4);
            Buffer.BlockCopy(BitConverter.GetBytes(this.CurrentPage), 0, _buffer, 28, 4);
            Buffer.BlockCopy(Data, 0, _buffer, 32, Data.Length);
            Buffer.BlockCopy(Md5Bytes, 0, _buffer, 32 + Data.Length, Md5Bytes.Length);

            byte[] crctemp = new byte[_buffer.Length - 2];
            var crc16 = _buffer.GetCrc16();

            Buffer.BlockCopy(crc16, 0, _buffer, 32 + Data.Length + Md5Bytes.Length, crc16.Length);

            return _buffer;
        }

        /// <summary>
        /// 解码
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        internal void Decode(byte[] data)
        {


            this.TotalPage = BitConverter.ToInt32(data, 24);
            this.CurrentPage = BitConverter.ToInt32(data, 28);

            bool hasMd5 = TotalPage > 1 && (TotalPage == CurrentPage);

            this.CommandEnum = (IsotorProtocolCommandEnum)BitConverter.ToInt16(data, 6);
            ArraySegment<byte> guidArraySegment = new ArraySegment<byte>(data, 8, 16);
            this.MsgKey = new Guid(guidArraySegment.ToArray());


            var tempdatelengh = BitConverter.ToInt32(data, 2);
            this.DataLength = tempdatelengh;
            if (hasMd5)
            {
                this.DataLength = tempdatelengh - 16;
                this.Md5Bytes = (new ArraySegment<byte>(data, 32 + DataLength, 16)).ToArray();
            }

            this.Data = (new ArraySegment<byte>(data, 32, this.DataLength)).ToArray();

            this.CrcBytes = (new ArraySegment<byte>(data, 32 + tempdatelengh, 2)).ToArray();

        }

    }


    public class DataPackageUtil
    {
        //   private static readonly Semaphore _semaphore=new Semaphore(10,10);
        /// <summary>
        /// 生成数据报文包组
        /// </summary>
        /// <param name="data"></param>
        /// <param name="pagesize"></param>
        /// <param name="msgKey"></param>
        /// <param name="action"></param>
        /// <param name="commandEnum"></param>
        /// <returns></returns>
        public static IEnumerable<DataPackage> CreateDataPackages(byte[] data, int pagesize, Guid msgKey, Action<bool> action, IsotorProtocolCommandEnum commandEnum = IsotorProtocolCommandEnum.SendNoAck)
        {
            int pageCount = (data.Length + pagesize - 1) / pagesize;
            if (pageCount == 1)
            { //为了节约发送数据，对无需分页的数据，不加MD5验证
                yield return new DataPackage()
                {
                    CommandEnum = commandEnum,
                    TotalPage = pageCount,
                    CurrentPage = 1,
                    MsgKey = msgKey
                    ,
                    Data = data
                    ,
                    Md5Bytes = null,
                    SendedAction = action

                };
                yield break; ;
            }

            GC.Collect(2);
            //  _semaphore.WaitOne();



            foreach (var i in Enumerable.Range(0, pageCount).AsParallel())
            {
                yield return new DataPackage()
                {
                    CommandEnum = commandEnum,
                    TotalPage = pageCount,
                    CurrentPage = i + 1,
                    MsgKey = msgKey
                    ,
                    Data = i + 1 == pageCount ? (new ArraySegment<byte>(data, i * pagesize, data.Length % pagesize)).ToArray() : (new ArraySegment<byte>(data, i * pagesize, pagesize)).ToArray()
                    ,
                    Md5Bytes = i + 1 == pageCount ? data.getMD5bytes() : null,
                    SendedAction = i + 1 == pageCount ? action : null

                };
            }
            //for (int i = 0; i < pageCount; i++)
            //{
            //    yield return new DataPackage()
            //    {
            //        CommandEnum = commandEnum,
            //        TotalPage = pageCount,
            //        CurrentPage = i + 1,
            //        MsgKey = msgKey
            //        ,
            //        Data = i + 1 == pageCount ? (new ArraySegment<byte>(data, i * pagesize, data.Length % pagesize)).ToArray() : (new ArraySegment<byte>(data, i * pagesize, pagesize)).ToArray()
            //        ,
            //        Md5Bytes = i + 1 == pageCount ? data.getMD5bytes() : null,
            //        SendedAction = i + 1 == pageCount ? action : null

            //    };
            //}

            //  _semaphore.Release();

        }


        public static DataPackage CreateCrcErrPackages(Guid msgid, int totalpage, int currentpage)
        {
            return new DataPackage()
            {
                CommandEnum = IsotorProtocolCommandEnum.CrcError,
                CurrentPage = currentpage,
                Data = new byte[] { 0x00 },
                MsgKey = msgid,
                TotalPage = totalpage

            };
        }

        public static DataPackage CreateAckBackPackage(Guid msgid,
            IsotorProtocolCommandEnum commandEnum = IsotorProtocolCommandEnum.AckOK)
        {
            return new DataPackage()
            {
                CommandEnum = commandEnum,
                Data = new byte[] { 0x00 },
                MsgKey = msgid
            };
        }
    }
}
