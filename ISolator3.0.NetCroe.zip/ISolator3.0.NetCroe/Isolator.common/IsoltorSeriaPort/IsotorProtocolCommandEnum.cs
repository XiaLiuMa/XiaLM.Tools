﻿
// namespaces...
namespace Isolator.common.IsoltorSeriaPort
{
    // public enums...
    /// <summary>
    /// 隔离器协议命令枚举
    /// </summary>
    public enum IsotorProtocolCommandEnum
    {
        /// <summary>
        /// 接收返回未确认
        /// </summary>
        AckError = 0x2010,
        /// <summary>
        /// 接收确认
        /// </summary>
        AckOK = 0x2000,
        /// <summary>
        /// 发送需确认
        /// </summary>
        SendAck = 0x1010,
        /// <summary>
        /// 发送无需确认
        /// </summary>
        SendNoAck = 0x1000,
        /// <summary>
        /// 循环校验错
        /// </summary>
        CrcError=0x2020,
        /// <summary>
        /// 存活状态
        /// </summary>
        livePack=0x0000,
        /// <summary>
        /// 注销状态
        /// </summary>
        Byebye=0x0010
    }
}
