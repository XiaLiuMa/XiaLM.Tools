﻿using System;

// namespaces...
namespace Isolator.common.SerialportControl
{
    // public classes...
    /// <summary>
    /// 串口配置
    /// </summary>
    [Serializable]
    public  class SerialPortConfig
    {
        // public properties...
        /// <summary>
        /// 波特率
        /// </summary>
        public int baudRate { get; set; }
        /// <summary>
        /// 串口号
        /// </summary>
        public string PortName { get; set; }
    }
}
