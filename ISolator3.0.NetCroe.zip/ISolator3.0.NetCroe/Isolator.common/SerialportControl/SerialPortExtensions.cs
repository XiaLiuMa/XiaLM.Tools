﻿using System;
using System.IO.Ports;
using System.Reactive.Linq;
using Schedule.Common.log;

// namespaces...
namespace Isolator.common.SerialportControl
{
    // public classes...
    public static class SerialPortExtensions
    {
        // public methods...
        public static IObservable<SerialDataReceivedEventArgs> DataReceivedAsObservable(this SerialPort serialPort)
        {
            return Observable.FromEvent<SerialDataReceivedEventHandler, SerialDataReceivedEventArgs>(
            h => (sender, e) => h(e), h => serialPort.DataReceived += h, h => serialPort.DataReceived -= h);
        }
        public static IObservable<SerialErrorReceivedEventArgs> ErrorReceivedAsObservable(this SerialPort serialPort)
        {
            return Observable.FromEvent<SerialErrorReceivedEventHandler, SerialErrorReceivedEventArgs>(
            h => (sender, e) => h(e), h => serialPort.ErrorReceived += h, h => serialPort.ErrorReceived -= h);
        }
        public static IObservable<byte[]> ObserveReceiveBytes(this SerialPort serialPort)
        {
            var received = serialPort.DataReceivedAsObservable()
                .Select(e =>
                {                                   
                        var buf = new byte[serialPort.BytesToRead];
                        serialPort.Read(buf, 0, buf.Length);
                        return buf;
                  
                });

            var error = serialPort.ErrorReceivedAsObservable()
                .Take(1)
                .Do(x =>
                {
                    LogHelp.Info("串口接收异常:" + x.EventType.ToString());
                    throw new Exception(x.EventType.ToString());
                });
          
            return received;
        }
    }
}
