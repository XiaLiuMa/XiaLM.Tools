﻿using System;
using System.Threading.Tasks;
using Isolator.common.IsoltorSeriaPort;

// namespaces...
namespace Isolator.common.SerialportControl
{
    // public interfaces...
    /// <summary>
    ///
    /// </summary>
    public   interface ISerialPort
    {
        // properties...
        /// <summary>
        /// 是否可以使用
        /// </summary>
        bool isCanUse { get; }

        // methods...
        /// <summary>
        /// 接收数据
        /// </summary>
        /// <returns></returns>
        IObservable<DataPackage> Receive(IsoltorProtocol Protocol);
        /// <summary>
        /// 发送数据
        /// </summary>
        /// <param name="data"></param>
       Task< bool> Send(byte[] data);
        /// <summary>
        /// 设置串口配置
        /// </summary>
        /// <param name="config"></param>
        void setConfig(SerialPortConfig config);
    }
}
