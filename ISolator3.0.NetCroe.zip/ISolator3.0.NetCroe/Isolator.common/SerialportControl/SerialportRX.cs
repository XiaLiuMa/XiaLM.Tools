﻿using Schedule.Common.log;
using System;
using System.IO.Ports;
using System.Linq;
using System.Reactive.Linq;
using System.Threading;
using System.Threading.Tasks;
using Isolator.common.IsoltorSeriaPort;

// namespaces...
namespace Isolator.common.SerialportControl
{
    // public classes...
    /// <summary>
    /// 隔离器端口控制
    /// </summary>
    public class SerialportRX : runtimeService.IRuntimeService, ISerialPort
    {
        // private fields...
        private bool isOpened;
        private IObservable<byte[]> ReceiveDataSource;
        private Lazy<SerialPort> serialPort;
        SpinLock slock = new SpinLock(false);
        bool lockTaken = false;

        private event Action<byte[]> _ondata = p => { };
        // public fields...
        public SerialPortConfig config;

        // public properties...
        public bool isCanUse
        {
            get
            {
                lockTaken = false;
                slock.Enter(ref lockTaken);
                if (lockTaken)
                {
                    slock.Exit(false);
                }
                return serialPort != null && isOpened && serialPort.Value.IsOpen;
            }
        }

        public bool IsRuning
        {
            get
            {
                return isOpened;
            }
        }
        public int StartOrder
        {
            get
            {
                return 0;
            }
        }

        public IObservable<DataPackage> Receive(IsoltorProtocol Protocol)
        {
            Protocol.comPort = this;
            this.ReceiveDataSource.Subscribe(p =>
            {
                foreach (byte b in p)
                {
                    Protocol.PostReciveData(b);
                }
            });

            return Protocol.Receive();
            ;

        }

        private int pageSize = 1024 * 11;
        private SemaphoreSlim _semaphore = new SemaphoreSlim(1);
        public async Task<bool> Send(byte[] data)
        {

            await _semaphore.WaitAsync();
            var res = false;
            //    System.Diagnostics.Stopwatch st = new System.Diagnostics.Stopwatch();
            //   st.Start();
            try
            {
                await Task.Factory.StartNew(async () =>
                {
                    //115200波特率相当与11Kb/s，故分包为11kb
                    serialPort.Value.Write(data, 0, data.Length);
                   await serialPort.Value.BaseStream.FlushAsync();                  
                });
                res = true;

            }
            catch (Exception ex)
            {
                res = false;

                LogHelp.Error(ex);
            }
            finally
            {
                _semaphore.Release();
                //  st.Stop();
                //  Console.WriteLine("串口发送耗时：" + st.ElapsedMilliseconds);
                // LogHelp.Info("串口发送耗时：" + st.ElapsedMilliseconds);
            }
            return res;
        }

        public void setConfig(SerialPortConfig config)
        {
            this.config = config;

            this.serialPort = new Lazy<SerialPort>(() => new SerialPort(config.PortName, config.baudRate));
        }

        public void Shutdown()
        {
            try
            {
                lockTaken = false;
                slock.Enter(ref lockTaken);
                if (lockTaken)
                {
                    serialPort.Value.Close();
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (lockTaken)
                {
                    slock.Exit(false);
                }
            }
        }

        public void Startup()
        {
            try
            {
                lockTaken = false;
                slock.Enter(ref lockTaken);
                if (lockTaken)
                {
                    if (serialPort != null)
                    {
                        if (!isOpened)
                        {
                            //  serialPort.Value.Handshake = Handshake.RequestToSend;
                            serialPort.Value.ReceivedBytesThreshold = 1;
                            serialPort.Value.ReadBufferSize = 10 * 1024 * 1024;
                            serialPort.Value.RtsEnable = true;
                            serialPort.Value.WriteBufferSize = 64 * 1024;
                            //  serialPort.Value.WriteTimeout = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["ComWriteTimeout"]);
                            serialPort.Value.ErrorReceived += Value_ErrorReceived;
                            serialPort.Value.StopBits = StopBits.One;
                            serialPort.Value.DataBits = 8;
                            serialPort.Value.Parity = Parity.None;
                            this.serialPort.Value.DataReceived += Value_DataReceived;
                            serialPort.Value.Open(); serialPort.Value.DiscardOutBuffer();
                            serialPort.Value.DiscardInBuffer();
                            this.ReceiveDataSource = Observable.FromEvent<byte[]>(p => this._ondata += p, p => this._ondata -= p);


                            //serialPort.Value.ObserveReceiveBytes().Subscribe(p =>
                            //{
                            //    this._ondata(p);
                            //});
                            isOpened = true;

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                if (lockTaken)
                {
                    slock.Exit(false);
                }
            }
        }

        private void Value_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            var buf = new byte[serialPort.Value.BytesToRead];

            var b = serialPort.Value.Read(buf, 0, buf.Length);
            if (b > 0)
            {
                this._ondata(new ArraySegment<byte>(buf, 0, b).ToArray());
            }


        }

        void Value_ErrorReceived(object sender, SerialErrorReceivedEventArgs e)
        {

        }
    }
}
