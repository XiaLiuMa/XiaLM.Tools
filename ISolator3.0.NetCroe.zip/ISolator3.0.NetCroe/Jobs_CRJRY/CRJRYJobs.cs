﻿using Jobs_Common;
using Quartz;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.Service.Quarz;
using System;
using System.Collections.Generic;

namespace Jobs_CRJRY
{
    /// <summary>
    /// 出入境人员调度任务
    /// 定时将出入境记录转送至隔离器
    /// </summary>
    [PersistJobDataAfterExecution]
    [DisallowConcurrentExecution]
    public class CRJRYJobs : AbstractQuarztJob
    {
        #region IJob 成员

        public override void Run(IJobExecutionContext context)
        {
            try
            {
                foreach (ISqlOperate sql in LstSqlOperate)
                {
                    string strSql = GlobalJobs.GetSql("crjry");

                    string str = string.Format(strSql, DateTime.Now.AddMinutes(-60).ToString("yyyyMMddHHmmss"), DateTime.Now.ToString("yyyyMMddHHmmss"));

                    List<Dictionary<string, object>> lst = SqlUtil.Select(str, sql);
                    IsolatorUtil.SendOneTime(lst, "CRJRY", 69,GlobalJobs.MaxSendCount, true);
                }
            }
            catch
            {
                throw;
            }
        }

        #endregion
    }
}
