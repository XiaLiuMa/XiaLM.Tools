﻿using Jobs_Common;
using Quartz;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.Service.Quarz;
using System;
using System.Collections.Generic;

namespace Jobs_KAASJTJNY
{
    /// <summary>
    /// 口岸案事件统计年月调度任务
    /// </summary>
    [PersistJobDataAfterExecution]
    [DisallowConcurrentExecution]
    public class KAASJTJNYJobs : AbstractQuarztJob
    {
        #region  //自定义变量

        string strCHWFWGRYM = string.Empty;

        string strCHZKRYM = string.Empty;

        string strCHWFWGRYY = string.Empty;

        string strCHZKRYY = string.Empty;

        #endregion

        #region IJob 成员

        /// <summary>
        /// 调度任务入口
        /// </summary>
        /// <param name="context"></param>       
        public override void Run(IJobExecutionContext context)
        {
            strCHWFWGRYM = GlobalJobs.GetSql("strCHWFWGRYM");

            strCHZKRYM = GlobalJobs.GetSql("strCHZKRYM");

            strCHWFWGRYY = GlobalJobs.GetSql("strCHWFWGRYY");

            strCHZKRYY = GlobalJobs.GetSql("strCHZKRYY");

            foreach (ISqlOperate sql in LstSqlOperate)
            {
                SecheduleWfwgTj(sql);
            }
        }

        #endregion

        #region 口岸案事件统计
        private void SecheduleWfwgTj(ISqlOperate sql)
        {
            try
            {
                //统计当月案事件数据
                //string DT = DateTime.Now.ToString("yyyyMM");
                //string sqlTJM = string.Format(strCHWFWGRYM, DT);
                string mStart = DateTime.Now.ToString("yyyyMM01000000");

                string mEnd = DateTime.Now.AddDays(1).ToString("yyyyMMdd235959");

                string sqlTJM = string.Format(strCHWFWGRYM, mStart, mEnd);

                List<Dictionary<string, object>> lstM = SqlUtil.Select(sqlTJM, sql);

                IsolatorUtil.SendOneTime(lstM, "KAASJTJ", 08, GlobalJobs.MaxSendCount, true);

                //string sqltjMZK = string.Format(strCHZKRYM, DT);

                string sqltjMZK = string.Format(strCHZKRYM, mStart, mEnd);

                List<Dictionary<string, object>> lstMZK = SqlUtil.Select(sqltjMZK, sql);

                IsolatorUtil.SendOneTime(lstMZK, "KAASJTJ", 08, GlobalJobs.MaxSendCount, true);

                //统计当年案事件数据
                //string DTY = DateTime.Now.ToString("yyyy");

                string yStart = DateTime.Now.ToString("yyyy0101000000");

                string yEnd = DateTime.Now.AddDays(1).ToString("yyyy1231235959");

                //string sqlTJY = string.Format(strCHWFWGRYY, DTY);
                string sqlTJY = string.Format(strCHWFWGRYY, yStart, yEnd);

                List<Dictionary<string, object>> lstY = SqlUtil.Select(sqlTJY, sql);

                IsolatorUtil.SendOneTime(lstY, "KAASJTJ", 08, GlobalJobs.MaxSendCount ,true);

                //string sqltjYZK = string.Format(strCHZKRYY, DTY);
                string sqltjYZK = string.Format(strCHWFWGRYY, yStart, yEnd);

                List<Dictionary<string, object>> lstYZK = SqlUtil.Select(sqltjYZK, sql);

                IsolatorUtil.SendOneTime(lstYZK, "KAASJTJ", 08, GlobalJobs.MaxSendCount, true);
            }
            catch
            {
                throw;
            }
        }
        #endregion
    }
}
