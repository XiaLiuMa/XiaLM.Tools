﻿using Jobs_Common;
using Jobs_Common.Mod;
using Quartz;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.Service.Quarz;
using System;
using System.Collections.Generic;

namespace Jobs_JCSJ
{
    /// <summary>
    /// 基础数据调度任务
    /// </summary>
    [PersistJobDataAfterExecution]
    [DisallowConcurrentExecution]
    public class JCSJJobs : AbstractQuarztJob
    {
        #region IJob 成员

        /// <summary>
        /// 调度任务入口
        /// </summary>
        /// <param name="context"></param>       
        public override void Run(IJobExecutionContext context)
        {
            try
            {
                foreach (ISqlOperate sql in LstSqlOperate)
                {
                    InqueryJCSJ(sql);
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region 查询数据
        private void InqueryJCSJ(ISqlOperate sql)
        {
            List<SqlEx> lstSql=GlobalJobs.GetJobSql("Jobs_JCSJ");

            foreach (SqlEx ss in lstSql)
            {
                List<Dictionary<string, object>> lst = SqlUtil.Select(ss.SqlText, sql);
                IsolatorUtil.SendOneTime(lst, "JCSJ", Convert.ToByte(ss.Cmd),GlobalJobs.MaxSendCount, true);
            }
        }
        #endregion
    }
}
