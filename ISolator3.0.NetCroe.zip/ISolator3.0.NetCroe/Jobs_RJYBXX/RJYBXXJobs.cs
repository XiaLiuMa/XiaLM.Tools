﻿using Jobs_Common;
using Quartz;
using Schedule.Common.Core;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.Service.Quarz;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Xml;

namespace Jobs_RJYBXX
{
    /// <summary>
    /// 入境预报信息调度任务
    /// </summary>
    [PersistJobDataAfterExecution]
    [DisallowConcurrentExecution]
    public class RJYBXXJobs : AbstractQuarztJob
    {
        #region //变量定义

        /// <summary>
        /// 配置文件目录
        /// </summary>
        private string configPath = AppDomain.CurrentDomain.BaseDirectory + "Config\\JobConfig.xml";

        /// <summary>
        /// XML文档管理
        /// </summary>
        private XmlFileManage xmlManage = XmlFileManage.GetInstance();

        #endregion

        #region IJob 成员

        public override void Run(IJobExecutionContext context)
        {
            try
            {
                foreach (ISqlOperate sql in LstSqlOperate)
                {
                    List<Dictionary<string, object>> lst = SqlUtil.Select(GetQuery(), sql);

                    if (lst != null && lst.Count > 0)
                    {
                        IsolatorUtil.SendOneTime(lst, "RJYBXX", 74, GlobalJobs.MaxSendCount);

                        //如果发送成功，则保存最后时间
                        UpdateWybs(lst[0]["WYBS"].ToString());
                    }
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 获取查询语句条件
        /// </summary>
        /// <returns></returns>
        private string GetQuery()
        {
            XmlNode note;
            string beginWybs="";
            try
            {
                note = xmlManage.SelectSingle(xmlManage.LoadFile(configPath), "//job[@name='RJYBXXJobs']/wybs");
                //如果查询时间为空,
                if (note == null || string.IsNullOrEmpty(note.InnerText))
                {
                    beginWybs = "";
                }
                else
                {
                    beginWybs = note.InnerText;
                }
            }
            catch
            {
                throw;
            }
            string strSql = GlobalJobs.GetSql("rjybxx");

            return string.Format(strSql, beginWybs);
        }

        /// <summary>
        /// 更新最后的上传时间
        /// </summary>
        private void UpdateWybs(string wybs)
        {
            XmlNode note = xmlManage.SelectSingle(xmlManage.LoadFile(configPath), "//job[@name='RJYBXXJobs']/wybs");
            if (note == null)
            {
                Add();
            }
            else
            {
                note.InnerText = wybs;
                xmlManage.Save(xmlManage.LoadFile(configPath));
            }
        }


        /// <summary>
        /// 添加
        /// </summary>
        void Add()
        {
            XmlUtil xml = new XmlUtil();
            Hashtable htAtt = new Hashtable();
            Dictionary<string, string> dicNode = new Dictionary<string, string>();
            htAtt.Add("name", "RJYBXXJobs");
            dicNode.Add("wybs", "02320161116101101123");
            xml.InsertNode(configPath, "job", true, "jobs", htAtt, dicNode);
        }

        #endregion
    }
}
