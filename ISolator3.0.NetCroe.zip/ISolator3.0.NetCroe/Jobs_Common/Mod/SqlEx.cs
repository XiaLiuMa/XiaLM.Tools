﻿using System;

namespace Jobs_Common.Mod
{
    [Serializable]
    public class SqlEx:Sql
    {
        public string Cmd { get; set; }
    }
}
