﻿using System;

namespace Jobs_Common.Mod
{
    [Serializable]
    public class Sql
    {
        /// <summary>
        /// SQL语句名称
        /// </summary>
        public string SqlName { get; set; }

        /// <summary>
        /// SQL语句
        /// </summary>
        public string SqlText { get; set; }
    }
}
