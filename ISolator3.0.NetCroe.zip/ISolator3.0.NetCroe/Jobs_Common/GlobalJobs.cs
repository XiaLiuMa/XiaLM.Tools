﻿using Jobs_Common.Mod;
using Schedule.Common.log;
using Schedule.Common.SqlHelp;
using Schedule.Common.SqlHelp.Impl;
using Schedule.Engine.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace Jobs_Common
{
    public static class GlobalJobs
    {
        public static List<Sql> LstSql =new List<Sql>();

        public static JobSqlConfig JobSqlConfig = new JobSqlConfig();

        private static string strAccess = string.Format(@"Data Source={0};Version=3; Password=max123456;", DataEngine_BaseDataConfig.baseDataConfig.IsolatorDbStr);

        public static int TJJGSJ= Convert.ToInt32(DataEngine_BaseDataConfig.baseDataConfig.TJJGSJ);

        public static int MaxSendCount = Convert.ToInt32(DataEngine_BaseDataConfig.baseDataConfig.MaxSendCount);

        /// <summary>
        /// 72小时过境免签自定义代码
        /// </summary>
        public static string _72XSGJMQZDYDM = DataEngine_BaseDataConfig.baseDataConfig.Sthtft;

        #region Xml方式
        #region 获取Sql语句
        /// <summary>
        /// 获取Sql语句
        /// </summary>
        /// <param name="sqlName"></param>
        /// <returns></returns>
        public static string GetSqlXml(string sqlName)
        {
            lock (LstSql)
            {
                string strSql = string.Empty;
                if (LstSql.Count == 0)
                {
                    string strXml = string.Empty;
                    string strXmlPath = string.Empty;
                    //strXmlPath = Application.StartupPath + @"\ConfigXML\SqlConfig.xml";
                    strXmlPath = AppDomain.CurrentDomain.BaseDirectory + @"\config\JobSqlConfig.xml";//UNDONE:（不确定是否可行）

                    DataSet ds = new DataSet();
                    ds.ReadXml(strXmlPath);

                    DataTable tb = ds.Tables[0];

                    foreach (DataRow row in tb.Rows)
                    {
                        Sql s = new Sql();
                        s.SqlName = row["SqlName"].ToString();
                        s.SqlText = row["SqlText"].ToString();

                        LstSql.Add(s);
                    }
                }

                Sql ss = LstSql.Find(r => r.SqlName == sqlName);

                if (ss != null)
                {
                    strSql = ss.SqlText;
                }

                return strSql;
            }
        }
        #endregion

        #region 根据调度任务名称获取要执行的Sql语句集合
        public static List<SqlEx> GetJobSqlXml(string jobName)
        {
            lock (JobSqlConfig)
            {
                List<SqlEx> lstSql = null;
                try
                {
                    //若为Null，则加载xml文件
                    if (JobSqlConfig.Items == null)
                    {
                        string strXml = string.Empty;
                        string strXmlPath = string.Empty;
                        //strXmlPath = Application.StartupPath + @"\ConfigXML\JobSqlConfig.xml";
                        strXmlPath = AppDomain.CurrentDomain.BaseDirectory + @"\config\JobSqlConfig.xml";//UNDONE:（不确定是否可行）

                        string xml = string.Empty;
                        XmlDocument xmlDoc = new XmlDocument();
                        xmlDoc.Load(strXmlPath);
                        xml = xmlDoc.InnerXml.Trim();
                        using (StringReader sr = new StringReader(xml))
                        {
                            XmlSerializer xmldes = new XmlSerializer(typeof(JobSqlConfig));
                            JobSqlConfig = xmldes.Deserialize(sr) as JobSqlConfig;
                        }
                    }

                    JobSqlConfigJob jobSqlC = Array.Find(JobSqlConfig.Items, r => r.JobName == jobName);

                    if (jobSqlC != null)
                    {
                        lstSql = new List<SqlEx>();
                        for (int i = 0; i < jobSqlC.Sql.Length; i++)
                        {
                            SqlEx s = new SqlEx();
                            s.Cmd = jobSqlC.Sql[i].Cmd;
                            s.SqlName = jobSqlC.Sql[i].SqlName;
                            s.SqlText = GetSqlXml(s.SqlName);

                            lstSql.Add(s);
                        }
                    }
                }
                catch (Exception e)
                {
                    LogHelp.Error(typeof(GlobalJobs), e);
                    return null;
                }

                return lstSql;
            }
        }
        #endregion 
        #endregion

        #region Access方式
        #region 获取Sql语句
        /// <summary>
        /// 获取Sql语句
        /// </summary>
        /// <param name="sqlName"></param>
        /// <returns></returns>
        public static string GetSql(string sqlName)
        {
            lock (LstSql)
            {
                string strSql = string.Empty;
                if (LstSql.Count == 0)
                {
                    ISqlOperate sqlOperate = new SqliteSqlOperate();
                    sqlOperate.DbConStr = strAccess;
                    DataSet dsAccess=null;
                    string strSqlAccess = "select * from SqlConfig";
                    sqlOperate.RunSQL(strSqlAccess, ref dsAccess);

                    if (dsAccess.Tables!=null&&dsAccess.Tables.Count>0)
                    {
                        DataTable tb = dsAccess.Tables[0];

                        foreach (DataRow row in tb.Rows)
                        {
                            Sql s = new Sql();
                            s.SqlName = row["SqlName"].ToString();
                            s.SqlText = row["SqlText"].ToString();

                            LstSql.Add(s);
                        } 
                    }
                }

                Sql ss = LstSql.Find(r => r.SqlName == sqlName);

                if (ss != null)
                {
                    strSql = ss.SqlText;
                }

                return strSql;
            }
        }
        #endregion

        #region 根据调度任务名称获取要执行的Sql语句集合
        public static List<SqlEx> GetJobSql(string jobName)
        {
            lock (JobSqlConfig)
            {
                List<SqlEx> lstSql = null;
                try
                {
                    //若为Null，则加载xml文件
                    if (JobSqlConfig.Items == null)
                    {
                        string strXml = string.Empty;
                        string strXmlPath = string.Empty;
                        //strXmlPath = Application.StartupPath + @"\config\JobSqlConfig.xml";
                        strXmlPath = AppDomain.CurrentDomain.BaseDirectory + @"\config\JobSqlConfig.xml";//UNDONE:（不确定是否可行）

                        string xml = string.Empty;
                        XmlDocument xmlDoc = new XmlDocument();
                        xmlDoc.Load(strXmlPath);
                        xml = xmlDoc.InnerXml.Trim();
                        using (StringReader sr = new StringReader(xml))
                        {
                            XmlSerializer xmldes = new XmlSerializer(typeof(JobSqlConfig));
                            JobSqlConfig = xmldes.Deserialize(sr) as JobSqlConfig;
                        }
                    }

                    JobSqlConfigJob jobSqlC = Array.Find(JobSqlConfig.Items, r => r.JobName == jobName);

                    if (jobSqlC != null)
                    {
                        lstSql = new List<SqlEx>();
                        for (int i = 0; i < jobSqlC.Sql.Length; i++)
                        {
                            SqlEx s = new SqlEx();
                            s.Cmd = jobSqlC.Sql[i].Cmd;
                            s.SqlName = jobSqlC.Sql[i].SqlName;
                            s.SqlText = GetSql(s.SqlName);

                            lstSql.Add(s);
                        }
                    }
                }
                catch (Exception e)
                {
                    LogHelp.Error(typeof(GlobalJobs), e);
                    return null;
                }

                return lstSql;
            }
        }
        #endregion
        #endregion
    }
}
