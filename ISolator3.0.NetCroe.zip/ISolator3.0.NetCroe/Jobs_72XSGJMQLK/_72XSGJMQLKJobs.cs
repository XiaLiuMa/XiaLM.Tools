﻿using Jobs_Common;
using Quartz;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.Service.Quarz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* ==============================
*
* 作者: 胡军会
* 创建时间：2018-06-20 14:56:08
* 文件名称：_72XSGJMQLKJobs
* 版本：V1.0.1
* 修改时间:
* 修改人：
* 修改备注：
* ===============================
*/
namespace Jobs_72XSGJMQLK
{
    [PersistJobDataAfterExecution]
    [DisallowConcurrentExecution]
    public class _72XSGJMQLKJobs : AbstractQuarztJob
    {
        public override void Run(IJobExecutionContext context)
        {
            foreach (ISqlOperate sql in LstSqlOperate)
            {
                string strSql = GlobalJobs.GetSql("72XSGJMQLK");

                string mStartCrrqsj = DateTime.Now.ToString("yyyyMM01000000");

                string mEndCrrqsj = DateTime.Now.ToString("yyyyMM31235959");

                string str = string.Format(strSql, GlobalJobs._72XSGJMQZDYDM, mStartCrrqsj, mEndCrrqsj);

                List<Dictionary<string, object>> lst = SqlUtil.Select(str, sql);

                IsolatorUtil.SendOneTime(lst, "_72XSGJMQLKJobs", 69, GlobalJobs.MaxSendCount, true);
            }
        }
    }
}
