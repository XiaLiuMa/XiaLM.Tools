﻿using Schedule.Engine.Core.Service.Quarz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* ==============================
*
* 作者: 胡军会
* 创建时间：2018-06-20 14:53:35
* 文件名称：_72XSGJMQLKService
* 版本：V1.0.1
* 修改时间:
* 修改人：
* 修改备注：
* ===============================
*/
namespace Jobs_72XSGJMQLK
{
    public class _72XSGJMQLKService : AbstractScheduleService
    {
        public override string ServiceName
        {
            get { return "_72XSGJMQLKJobs"; }
        }

        public override string ClassNote()
        {
            return "72小时过境免签旅客调度服务";
        }

        public override Type GetJobType()
        {
            return typeof(_72XSGJMQLKJobs);
        }
    }
}
