﻿using DataStorageService.Mod;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Primitives;
using Schedule.Common.SqlHelp;
using Schedule.Common.SqlHelp.Impl;
using Schedule.model.common;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Threading.Tasks;

namespace DataStorageService
{
    /// <summary>
    /// 数据库
    /// </summary>
    public class DbConfigRepertory : IDisposable
    {
        static List<Ga_DataBase> dbconfigs = new List<Ga_DataBase>();
        static string dbConfigPath = @"Config/DataBaseConfig.xml";
        static List<DataBaseEX> dbconfigEXs = new List<DataBaseEX>();
        //HostFileChangeMonitor monitor;
        IFileProvider fileProvider; //UNDONE:（不确定是否可行）

        public static List<Dictionary<string, object>> SelectData(String sql)
        {
            return SqlUtil.Select(sql, getDafaultSqlOperate());
        }

        public void init()
        {
            //monitor = new HostFileChangeMonitor(new List<string>() {
            
            //    AppDomain.CurrentDomain.BaseDirectory+dbConfigPath
            //});
            //monitor.NotifyOnChanged(OnChangedCallback);

            fileProvider = new PhysicalFileProvider(AppDomain.CurrentDomain.BaseDirectory);
            ChangeToken.OnChange(() => fileProvider.Watch(dbConfigPath), () => OnChangedCallback(fileProvider));

            getdbconfigs();
        }

        private void OnChangedCallback(object state)
        {
            getdbconfigs();
        }

        [HandleProcessCorruptedStateExceptions]
        private void getdbconfigs()
        {
            dbconfigs = SerializationHelper.Load<List<Ga_DataBase>>(AppDomain.CurrentDomain.BaseDirectory+dbConfigPath);
            dbconfigEXs.Clear();
            foreach (var item in dbconfigs)
            {
                var obj = new DataBaseEX(item);
                obj.connstr = new Lazy<ISqlOperate>(() =>
                {
                    string serverIp = item.ServerIp;
                    string serverPort = item.ServerPort;
                    string dbName = item.DataBaseName;
                    string uid = item.UserName;
                    string pwd = item.Password;

                    string conStr = "Data Source={0},{1};Initial Catalog={2};Uid={3};pwd={4};Persist Security Info=True;MultipleActiveResultSets=true";
                    conStr = string.Format(conStr,serverIp,serverPort,dbName,uid,pwd);

                    ISqlOperate sqlOperate = new MsSqlOperate();
                    sqlOperate.DbConStr = conStr;

                    return sqlOperate;
                });

                dbconfigEXs.Add(obj);
            }
        }

        public static ISqlOperate getDafaultSqlOperate()
        {
            if (dbconfigEXs.Any())
            {
                ISqlOperate defaultSql = dbconfigEXs.First().sqlOperate;

                var obj = dbconfigEXs.LastOrDefault(c => c.Default).sqlOperate;
                if (obj != null)
                {
                    defaultSql = obj;
                }
                return defaultSql;
            }
            return null;
        }

        public static List<ISqlOperate> getISqlOperater(string ids)
        {
            try
            {
                string[] idsArray = ids.Split(',');

                return dbconfigEXs.Where(p => idsArray.Contains(p.ID.ToString())).Select(p => p.sqlOperate).ToList();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void Dispose()
        {
            //monitor.Dispose();
            dbconfigs.Clear();
            dbconfigEXs.Clear();
        }
    }

    public class DataBaseEX : Ga_DataBase
    {
        public DataBaseEX(Ga_DataBase dbInfo)
        {
            this.ID = dbInfo.ID;
            this.ServerIp = dbInfo.ServerIp;
            this.ServerPort = dbInfo.ServerPort;
            this.Default = dbInfo.Default;
        }
        internal Lazy<ISqlOperate> connstr;

        public ISqlOperate sqlOperate { get { return connstr.Value; } }
    }
}
