﻿using DataStorageService.Mod;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Primitives;
using Schedule.Common.SqlHelp;
using Schedule.model.common;
using System;
using System.Collections.Generic;
using System.Runtime.ExceptionServices;

namespace DataStorageService
{
    /// <summary>
    /// 数据库
    /// </summary>
    public class JobConfigRepertory : IDisposable
    {
        static List<Ga_JobConfig> jobconfigs = new List<Ga_JobConfig>();
        static string jobConfigPath = @"Config/JobConfig.xml";
        static List<Ga_JobConfigEX> jobconfigEXs = new List<Ga_JobConfigEX>();
        //HostFileChangeMonitor monitor;
        IFileProvider fileProvider; //UNDONE:（不确定是否可行）

        public void init()
        {
            //monitor = new HostFileChangeMonitor(new List<string>() {
            //    AppDomain.CurrentDomain.BaseDirectory+jobConfigPath
            //});

            //monitor.NotifyOnChanged(OnChangedCallback);

            fileProvider = new PhysicalFileProvider(AppDomain.CurrentDomain.BaseDirectory);
            ChangeToken.OnChange(() => fileProvider.Watch(jobConfigPath), () => OnChangedCallback(fileProvider));

            getdbconfigs();
        }

        private void OnChangedCallback(object state)
        {
            getdbconfigs();
        }

        [HandleProcessCorruptedStateExceptions]
        private void getdbconfigs()
        {
            jobconfigs = SerializationHelper.Load<List<Ga_JobConfig>>(jobConfigPath);
            jobconfigEXs.Clear();
            foreach (var item in jobconfigs)
            {
                var obj = new Ga_JobConfigEX(item);
                obj.connstr = new Lazy<List<ISqlOperate>>(() => {
                    return DbConfigRepertory.getISqlOperater(item.Conn);
                });
                obj.ID = item.ID;
                obj.Name = item.Name;
                obj.state = item.state;
                obj.Conn = item.Conn;
                jobconfigEXs.Add(obj);
            }
        }

        public static List<ISqlOperate> getISqlOperater(string name)
        {
            try
            {
                return jobconfigEXs.Find(p=>p.Name==name).sqlOperate;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static bool GetJobState(string name)
        {
            bool re = false;
            try
            {
                re = jobconfigEXs.Find(p => p.Name == name).state;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return re;
        }

        public void Dispose()
        {
            //monitor.Dispose();
            jobconfigs.Clear();
            jobconfigEXs.Clear();
        }
    }

    public class Ga_JobConfigEX : Ga_JobConfig
    {
        public Ga_JobConfigEX(Ga_JobConfig dbInfo)
        {
            this.ID = dbInfo.ID;
            this.state = dbInfo.state;
            this.Name = dbInfo.Name;
            this.Conn = dbInfo.Conn;
        }

        internal Lazy<List<ISqlOperate>> connstr;

        public List<ISqlOperate> sqlOperate { get { return connstr.Value; } }
    }
}
