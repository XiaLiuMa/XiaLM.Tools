﻿using System.Collections.Generic;
using Newtonsoft.Json;
using Schedule.Common.SqlHelp;
using Schedule.model;
using System.Linq;
using System.Threading.Tasks;
using DataStorageService.Mod;

namespace DataStorageService.Service.DbImpl
{
    /// <summary>
    /// 公共数据同步
    /// </summary>
    public class CommonService : IDbService
    {
        /// <summary>
        /// 当前服务能处理的隔离器数据命令区间
        /// </summary>
        private byte[] cmds;

        /// <summary>
        /// 每一个命令所对应的表名
        /// </summary>
        private Dictionary<byte, string> tables = new Dictionary<byte, string>();

        /// <summary>
        /// 每一个表名所对应的主键值。
        /// </summary>
        private Dictionary<string, string[]> Keys = new Dictionary<string, string[]>();

        #region IService 成员

        public CommonService()
        {
            CmdConfig.GetCommondCmds(out cmds, out tables, out Keys);
        }

        /// <summary>
        /// 获取当前服务所能处理的隔离器数据命令区间
        /// </summary>
        public byte[] Cmds
        {
            get { return cmds; }
        }

        /// <summary>
        /// 数据处理接口
        /// </summary>
        /// <param name="cmd">命令号</param>
        /// <param name="json">数据为JSON格式</param>
        public void Handle(byte cmd, string json)
        {
            Knick knick = new Knick();
            knick.Cmd = cmd;
            knick.Value = json;
            InvokeResole(knick);
        }

        byte[] ts = new byte[] { 01, 02, 9, 50, 51, 55, 59, 60, 61, 62, 64, 66, 67, 69, 70,254 };

        private static readonly object lckObj = new object();

        private void InvokeResole(object paraObj)
        {
            Knick knick = paraObj as Knick;

            byte cmd = knick.Cmd;
            string json = knick.Value;

            //根据命令号，获取对应的表名以及主键
            string table = tables[cmd];
            if (table == null) return;
            string[] key = Keys[table];
            if (key == null) return;

            //这里不考虑的JSON的复杂格式。只处理简单数据型或一般对象型，包括实体类或字典
            if (json.StartsWith("["))
            {
                //说明此JSON是一个数据格式。
                object obj = JsonConvert.DeserializeObject(json, typeof(List<Dictionary<string, object>>));
                List<Dictionary<string, object>> dataLst = obj as List<Dictionary<string, object>>;

                foreach (ISqlOperate item in LstSqlOperate)
                {
                    if (ts.Contains(cmd))
                    {
                        Parallel.ForEach(dataLst, _ =>
                        {
                            lock (lckObj)
                            {
                                if (cmd == 254)
                                {

                                }
                                SqlUtil.UpdateOrAdd(table, key, _, item);
                            }
                        });
                    }
                    else
                    {
                        MergeHelper.AddMergeParallelLst(dataLst, "tmp_" + table, table, key, item);
                    }
                }
            }
            else
            {
                //此JSON可序列化成一个字典型或类对象
                Dictionary<string, object> data = JsonConvert.DeserializeObject(json, typeof(Dictionary<string, object>)) as Dictionary<string, object>;
                foreach (ISqlOperate item in LstSqlOperate)
                {
                    SqlUtil.UpdateOrAdd(table, key, data, item); 
                }
            }
        }

        #endregion

        public List<ISqlOperate> LstSqlOperate
        {
            get;
            set;
        }
    }
}
