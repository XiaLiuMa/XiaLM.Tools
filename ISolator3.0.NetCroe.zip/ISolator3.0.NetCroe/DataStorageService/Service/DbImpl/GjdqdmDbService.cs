﻿using System.Collections.Generic;
using Newtonsoft.Json;
using Schedule.Common.SqlHelp;
using System.Threading.Tasks;

namespace DataStorageService.Service.DbImpl
{
    /// <summary>
    /// 国家地区代码数据同步
    /// </summary>
    public class GjdqdmDbService : IDbService
    {
        /// <summary>
        /// 当前子类处理命令。只处理国家地区代码数据同步
        /// </summary>
        public byte[] Cmds
        {
            get { return new byte[] { 56 }; }
        }

        /// <summary>
        /// 处理入口
        /// </summary>
        /// <param name="cmd"></param>
        /// <param name="json"></param>
        public void Handle(byte cmd, string json)
        {
            switch (cmd)
            {
                case 56:
                    if (json.StartsWith("["))
                    {
                        object obj = JsonConvert.DeserializeObject(json, typeof(List<Dictionary<string, object>>));
                        List<Dictionary<string, object>> dataLst = obj as List<Dictionary<string, object>>;
                        Parallel.ForEach(dataLst, _ =>
                        {
                            InvokeResole(_);
                        });
                    }
                    else
                    {
                        Dictionary<string, object> receive = JsonConvert.DeserializeObject(json, typeof(Dictionary<string, object>)) as Dictionary<string, object>;
                        InvokeResole(receive);
                    }
                    break;
            }
        }

        private void InvokeResole(Dictionary<string, object> receive)
        {
            Gjdqdm(receive);
        }

        /// <summary>
        /// 国家地区代码入库处理
        /// </summary>
        private void Gjdqdm(Dictionary<string, object> receive)
        {
            foreach (ISqlOperate item in LstSqlOperate)
            {
                if (receive.ContainsKey("YWMC") && receive["YWMC"] != null)
                {
                    string value = receive["YWMC"].ToString();
                    value = value.Replace("'", "''".ToString());
                    receive["YWMC"] = value;
                }
                SqlUtil.UpdateOrAdd("QWSJ_D_GJDQDM", new string[] { "GJDQ3" }, receive, item); 
            }
        }

        public List<ISqlOperate> LstSqlOperate
        {
            get;
            set;
        }
    }
}
