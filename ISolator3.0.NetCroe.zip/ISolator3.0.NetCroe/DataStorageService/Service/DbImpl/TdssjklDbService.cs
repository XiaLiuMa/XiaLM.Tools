﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using DataStorageService.Mod;
using Newtonsoft.Json;
using Schedule.Common.SqlHelp;
using Schedule.model;

namespace DataStorageService.Service.DbImpl
{
    /// <summary>
    /// 通信实时监控信息数据库操作处理。01 表示上台。02 表示下台
    /// </summary>
    public class TdssjklDbService : IDbService
    {
        public TdssjklDbService()
        {
            QuTdssxx = Queue.Synchronized(QuTdssxx);
        }

        /// <summary>
        /// 工作员上台缓存
        /// </summary>
        public static Queue QuTdssxx = new Queue();

        /// <summary>
        /// 当前子类处理命令。只处理通信实时监控
        /// </summary>
        public byte[] Cmds
        {
            get { return new byte[] { 01, 02 }; }
        }

        /// <summary>
        /// 处理入口
        /// </summary>
        /// <param name="cmd"></param>
        /// <param name="json"></param>
        public void Handle(byte cmd, string json)
        {
            if (cmd == 01 || cmd == 02)
            {
                Knick knick = new Knick();
                knick.Cmd = cmd;
                knick.Value = json;
                InvokeResole(knick);
            }
        }

        private void InvokeResole(object paraObj)
        {

            Knick knick = paraObj as Knick;

            byte cmd = knick.Cmd;
            string json = knick.Value;
            List<Dictionary<string, object>> lstZfdjreceive = new List<Dictionary<string, object>>();
            if (json.StartsWith("["))
            {
                lstZfdjreceive = JsonConvert.DeserializeObject<List<Dictionary<string, object>>>(json);
                if (lstZfdjreceive == null || lstZfdjreceive.Count == 0) return;
            }
            else
            {
                Dictionary<string, object> Zfdjreceive = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                if (Zfdjreceive == null) return;
                lstZfdjreceive.Add(Zfdjreceive);
            }

            switch (cmd)
            {
                case 01:
                    lstZfdjreceive.ForEach(r => Jcystcl(r));
                    break;
                case 02:
                    lstZfdjreceive.ForEach(r => Jcyxtcl(r));
                    break;
            }
        }

        /// <summary>
        /// 检查员上台处理
        /// </summary>
        private void Jcystcl(Dictionary<string, object> receive)
        {
            SendTdxxtj(receive);
        }

        /// <summary>
        /// 发送通道实时信息统计
        /// </summary>
        /// <returns></returns>
        private void SendTdxxtj(Dictionary<string, object> receive)
        {
            string vaKey = receive["VALKEY"].ToString();
            if (QuTdssxx.Count > 100)
            {
                QuTdssxx.Dequeue();
            }

            if (QuTdssxx.Count > 0 && QuTdssxx.Contains(vaKey))
            {
                return;
            }
            QuTdssxx.Enqueue(vaKey);

            string wybs = receive["WYBS"].ToString();
            string yfzt = "0";
            if (!string.IsNullOrEmpty(wybs))
            {
                yfzt = "1";
            }
            //推送信息赋值
            TdssxxtjBroadCastMsg castMsg = new TdssxxtjBroadCastMsg();
            castMsg.Wybs = receive["WYBS"].ToString();
            castMsg.Tdh = receive["TDH"].ToString();
            castMsg.Ktzt = receive["GZZZT"].ToString();
            castMsg.Yfzt = yfzt;
            DateTime stsj = DateTime.ParseExact(receive["CZYZCSJ"].ToString(), "yyyyMMddHHmmss", null);
            DateTime ztsj = DateTime.Now;
            TimeSpan ts = stsj.Subtract(ztsj).Duration();
            castMsg.Ztsj = ts.Hours.ToString() + "小时" + ts.Minutes.ToString() + "分钟";
            castMsg.Jcy = receive["CZYXM"].ToString();
            castMsg.Stsj = stsj.ToString("yyyy-MM-dd HH:mm:ss");
            Dictionary<string, object> receiveTj = StatisticsPjbjs(receive);
            if (receiveTj == null)
            {
                castMsg.Gj = "0";
                castMsg.Zjzl = "0";
                castMsg.Yfrs = "0";
            }
            else
            {
                castMsg.Yfrs = receiveTj["YFS"].ToString();
                receive["YFS"] = receiveTj["YFS"].ToString();
            }
            castMsg.Lkxm = receive["XM"].ToString();
            castMsg.Xb = receive["XBDM"].ToString();
            castMsg.Csrq = receive["CSRQ"].ToString();
            castMsg.Zjhm = receive["ZJHM"].ToString();
            castMsg.Crjlx = receive["CRBZ"].ToString();
            castMsg.Ssbm = receive["BMMC"].ToString();
            castMsg.Zjzl = GlobalService.GetZJLBMC(receive["ZJLBDM"].ToString());
            castMsg.Gj = GlobalService.GetGJDQMC(receive["GJDQDM"].ToString());

            try
            {
                T_CRJRY crjry = JsonConvert.DeserializeObject<T_CRJRY>(JsonConvert.SerializeObject(receive));

                foreach (var item in LstSqlOperate)
                {
                    if(!string.IsNullOrEmpty(crjry.WYBS))
                    {
                        SqlUtil.UpdateOrAdd<T_CRJRY>("QWSJ_T_CRJRY", new string[] { "WYBS" }, crjry, item);
                    }
                }

                T_TDSSJK tdssjk = JsonConvert.DeserializeObject<T_TDSSJK>(JsonConvert.SerializeObject(receive));

                foreach (var item in LstSqlOperate)
                {
                    SqlUtil.UpdateOrAdd<T_TDSSJK>("QWSJ_T_TDSSJK", new string[] { "TDH" }, tdssjk, item);
                }

                receive.Add("ZTSJ", castMsg.Ztsj);
                receive.Add("YFRS", castMsg.Yfrs);
                receive.Add("JCY", castMsg.Jcy);
                receive.Add("GJ", castMsg.Gj);
                receive.Add("ZJZL", castMsg.Zjzl);
                receive.Add("XB", castMsg.Xb);
                receive.Add("KTZT", "2");
                T_TDSSTJ tdsstj = JsonConvert.DeserializeObject<T_TDSSTJ>(JsonConvert.SerializeObject(receive));

                foreach (var item in LstSqlOperate)
                {
                    SqlUtil.UpdateOrAdd<T_TDSSTJ>("QWSJ_T_TDSSTJ", new string[] { "TDH" }, tdsstj, item); 
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        /// <summary>
        /// 统计评价报警数、业务报警数，查询国家地区代码
        /// </summary>
        /// <returns></returns>
        private Dictionary<string, object> StatisticsPjbjs(Dictionary<string, object> receive)
        {
            string strSql = "select count(f.wybs) as yfs from QWSJ_T_CRJRY f left join QWSJ_T_TDSSJK a on f.TDH=a.TDH  where  " +
           "f.CRRQSJ>'" + receive["CZYZCSJ"].ToString() + "' and f.TDH='" + receive["TDH"].ToString() + "'";

            List<Dictionary<string, object>> list = SqlUtil.Select(strSql, DbConfigRepertory.getDafaultSqlOperate());
            if (list.Count > 0)
            {
                return (Dictionary<string, object>)list[0];
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// 检查员下台处理
        /// </summary>
        /// <param name="receive"></param>
        private void Jcyxtcl(Dictionary<string, object> receive)
        {
            object vaKey = receive["VALKEY"];
            if (QuTdssxx.Count > 100)
            {
                QuTdssxx.Dequeue();
            }

            if (QuTdssxx.Count > 0 && QuTdssxx.Contains(vaKey))
            {
                return;
            }
            QuTdssxx.Enqueue(vaKey.ToString());
            receive.Add("LKXM", "");
            T_TDSSTJ tdsstj = JsonConvert.DeserializeObject<T_TDSSTJ>(JsonConvert.SerializeObject(receive));
            tdsstj.KTZT = "1";

            foreach (var item in LstSqlOperate)
            {
                SqlUtil.UpdateOrAdd<T_TDSSTJ>("QWSJ_T_TDSSTJ", new string[] { "TDH" }, tdsstj, item);
            }

            T_TDSSJK tdssjk = JsonConvert.DeserializeObject<T_TDSSJK>(JsonConvert.SerializeObject(receive));

            foreach (var item in LstSqlOperate)
            {
                SqlUtil.UpdateOrAdd<T_TDSSJK>("QWSJ_T_TDSSJK", new string[] { "TDH" }, tdssjk, item);
            }
        }

        public List<ISqlOperate> LstSqlOperate
        {
            get;
            set;
        }
    }

    /// <summary>
    /// 通道实时信息与当前旅客通道信息推送
    /// </summary>
    [Serializable]
    public class TdssxxtjBroadCastMsg
    {
        /// <summary>
        /// 唯一标识
        /// </summary>
        public string Wybs = "0";

        /// <summary>
        /// 通道号
        /// </summary>
        public string Tdh = "0";

        /// <summary>
        /// 开通状态
        /// </summary>
        public string Ktzt = "0";

        /// <summary>
        /// 验放状态
        /// </summary>
        public string Yfzt = "0";

        /// <summary>
        /// 在台时间
        /// </summary>
        public string Ztsj = "0";

        /// <summary>
        /// 操作员代码
        /// </summary>
        public string Czydm = "0";

        /// <summary>
        /// 检查员
        /// </summary>
        public string Jcy = "0";

        /// <summary>
        /// 所属部门
        /// </summary>
        public string Ssbm = "0";

        /// <summary>
        /// 上台时间
        /// </summary>
        public string Stsj = "0";


        /// <summary>
        /// 验放人数
        /// </summary>
        public string Yfrs = "0";

        /// <summary>
        /// 报警次数
        /// </summary>
        public string Bjcs = "0";

        /// <summary>
        /// 不满意次数
        /// </summary>
        public string Bmycs = "0";

        /// <summary>
        /// 旅客姓名
        /// </summary>
        public string Lkxm = "0";

        /// <summary>
        /// 性别
        /// </summary>
        public string Xb = "0";

        /// <summary>
        /// 国籍
        /// </summary>
        public string Gj = "0";


        /// <summary>
        /// 出生日期
        /// </summary>
        public string Csrq = "0";

        /// <summary>
        /// 证件种类
        /// </summary>
        public string Zjzl = "0";

        /// <summary>
        /// 证件号码
        /// </summary>
        public string Zjhm = "0";

        /// <summary>
        /// 出入境类型
        /// </summary>
        public string Crjlx = "0";

    }
}
