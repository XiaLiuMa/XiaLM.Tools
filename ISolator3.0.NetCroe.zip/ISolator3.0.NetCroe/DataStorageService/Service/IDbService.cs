﻿using Schedule.Common.SqlHelp;
using System.Collections.Generic;

namespace DataStorageService.Service
{
    public interface IDbService
    {
        /// <summary>
        /// 获取当前服务所能处理的隔离器数据命令区间
        /// </summary>
        byte[] Cmds { get; }

        /// <summary>
        /// 数据处理接口
        /// </summary>
        /// <param name="cmd">命令号</param>
        /// <param name="json">数据为JSON格式</param>
        void Handle(byte cmd, string json);

        /// <summary>
        /// 数据库操作对象
        /// </summary>
        List<ISqlOperate> LstSqlOperate { get; set; }
    }
}
