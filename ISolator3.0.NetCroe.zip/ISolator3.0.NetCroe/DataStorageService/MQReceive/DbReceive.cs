﻿using DataStorageService.Service;
using log4net;
using Schedule.Common.log;
using Schedule.Common.Service;
using Schedule.Common.Util;
using Schedule.model;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks.Dataflow;

namespace DataStorageService.MQReceive
{
    public class DbReceive : IReceiveListener
    {
        /// <summary>
        /// 所有命令对应的实体类
        /// </summary>
        //private static List<IDbService> DbServiceLst = null;

        private static System.Collections.Concurrent.ConcurrentBag<IDbService> DbServiceLst = null;

        private ILog log = LogManager.GetLogger(typeof(DbReceive));

        private readonly static object lckObj = new object();

        public void ReceiveNotified(IsolatorData data)
        {
#if DEBUG
            LogHelp.Info(string.Format(DateTime.Now.ToString(CalculateUtil.FormatDt) + ",已接收到数据：jobName={0},cmd={1},SendTime={2}", data.JobName, data.Cmd, data.SendTime));
#endif

            try
            {
                if (DbServiceLst == null)
                {
                    lock (lckObj)
                    {
                        GetServicesImpl();
                    }
                }

                if (data != null)
                {
                    //根据不同的命令号来区分表名
                    for (int i = 0; i < DbServiceLst.Count; i++)
                    {
                        IDbService item =DbServiceLst.ToArray()[i];
                        if (item.Cmds.Contains(data.Cmd) && JobConfigRepertory.GetJobState(data.JobName))
                        {
                            item.LstSqlOperate = JobConfigRepertory.getISqlOperater(data.JobName);
                            item.Handle(data.Cmd, Encoding.UTF8.GetString(data.Value));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
        }

        /// <summary>
        /// 获取所有IDbService子类.反射加载所有数据库数据处理对象
        /// </summary>
        private static void GetServicesImpl()
        {
            if (DbServiceLst == null)
            {
                DbServiceLst = new ConcurrentBag<IDbService>();

                IList<Type> lst = ReflectionUtil.FindSubClasses(typeof(IDbService));
                foreach (Type t in lst)
                {
                    var handler = (IDbService)Activator.CreateInstance(t);
                    DbServiceLst.Add(handler);
                }
            }
        }

        private ActionBlock<IsolatorData> _Data_ActionBlock;

        public static CancellationTokenSource _CancellationTokenSourceData = new CancellationTokenSource();

        public ActionBlock<IsolatorData> Data_ActionBlock
        {
            get
            {
                _Data_ActionBlock = new ActionBlock<IsolatorData>((data) =>
                {
#if DEBUG
                    LogHelp.Info(string.Format(DateTime.Now.ToString(CalculateUtil.FormatDt) + ",已接收到数据：jobName={0},cmd={1},SendTime={2}", data.JobName, data.Cmd, data.SendTime));
#endif

                    try
                    {
                        if (DbServiceLst == null)
                        {
                            lock (lckObj)
                            {
                                GetServicesImpl();
                            }
                        }

                        if (data != null)
                        {
                            if (data.Cmd == 254)
                            {

                            }
                            //根据不同的命令号来区分表名
                            for (int i = 0; i < DbServiceLst.Count; i++)
                            {
                                IDbService item = DbServiceLst.ToArray()[i];
                                if (item.Cmds.Contains(data.Cmd) && JobConfigRepertory.GetJobState(data.JobName))
                                {
                                    item.LstSqlOperate = JobConfigRepertory.getISqlOperater(data.JobName);
                                    item.Handle(data.Cmd, Encoding.UTF8.GetString(data.Value));
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        log.Error(ex);
                    }
                }, new ExecutionDataflowBlockOptions() { MaxDegreeOfParallelism = 3, BoundedCapacity = 100, CancellationToken = _CancellationTokenSourceData.Token });
                return _Data_ActionBlock;
            }
            set
            {
                _Data_ActionBlock = value;
            }
        }
    }
}
