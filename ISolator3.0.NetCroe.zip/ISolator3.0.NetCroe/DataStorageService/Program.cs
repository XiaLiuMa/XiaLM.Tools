﻿using Schedule.Common.log;
using System;
using System.ServiceProcess;
using System.Threading;

namespace DataStorageService
{
    class Program
    {
        static void Main(string[] args)
        {
#if DEBUG
            bool flag = false;
            Mutex mutex = new Mutex(true, "DataStorageService", out flag);
            if (flag)
            {
                GlobalService.Init();
                Console.ReadLine();
            }
            else
            {
                LogHelp.Info(GlobalService._Resource1.StrName + "已经启动...........");
                System.Threading.Thread.Sleep(5000);//线程挂起5秒钟  
                Environment.Exit(1);//退出程序  
            }
#else
  ServiceBase[] ServicesToRun;
            ServicesToRun = new ServiceBase[] 
            { 
                new Service1() 
            };
            ServiceBase.Run(ServicesToRun);
#endif
        }
    }
}
