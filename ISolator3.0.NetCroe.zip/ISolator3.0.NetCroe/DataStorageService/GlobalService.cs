﻿using log4net;
using log4net.Config;
using Newtonsoft.Json;
using Schedule.Common.Core.Send.MqSend;
using Schedule.Common.log;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.model.common;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;

namespace DataStorageService
{
    public class GlobalService
    {
        public static Mod.Resource1 _Resource1;
        /// <summary>
        /// 证件种类
        /// </summary>
        static BlockingCollection<ZJZL> lstZJZL = new BlockingCollection<ZJZL>();

        /// <summary>
        /// 国家地区代码
        /// </summary>
        static BlockingCollection<GJDQDMMC> lstGJDQDM = new BlockingCollection<GJDQDMMC>();

        /// <summary>
        /// 根据证件类别代码获取证件类别名称
        /// </summary>
        /// <param name="tdh"></param>
        /// <returns></returns>
        public static string GetZJLBMC(string zjlbdm)
        {
            if (lstZJZL.Count == 0)
            {
                if (lstZJZL.Count == 0)
                {
                    string strSql = @"SELECT ZJLBDM,ZJLBMC FROM QWSJ_D_ZJLBDM";
                    List<Dictionary<string, object>> listDic = SqlUtil.Select(strSql, DbConfigRepertory.getDafaultSqlOperate());
                    listDic.ForEach(d =>
                    {
                        ZJZL zjzl = JsonConvert.DeserializeObject<ZJZL>(JsonConvert.SerializeObject(d));

                        lstZJZL.Add(zjzl);
                    });
                }
            }

            ZJZL zj = lstZJZL.FirstOrDefault(a => a.ZJLBDM.Equals(zjlbdm));

            return zj == null ? "" : zj.ZJLBMC;
        }

        /// <summary>
        /// 根据国家地区代码获取国家地区名称
        /// </summary>
        /// <param name="tdh"></param>
        /// <returns></returns>
        public static string GetGJDQMC(string gjdqdm)
        {
            if (lstGJDQDM.Count == 0)
            {
                if (lstGJDQDM.Count == 0)
                {
                    string strSql = @"SELECT GJDQ3,GJDQMC FROM QWSJ_D_GJDQDM";
                    List<Dictionary<string, object>> listDic = SqlUtil.Select(strSql,DbConfigRepertory.getDafaultSqlOperate());
                    listDic.ForEach(d =>
                    {
                        GJDQDMMC gjqd = JsonConvert.DeserializeObject<GJDQDMMC>(JsonConvert.SerializeObject(d));

                        lstGJDQDM.Add(gjqd);
                    });
                }
            }

           GJDQDMMC gj = lstGJDQDM.FirstOrDefault(a => a.GJDQ3.Equals(gjdqdm));

           return gj == null ? "" : gj.GJDQMC;
        }

        /// <summary>
        /// 初始化
        /// </summary>
        public static void Init()
        {
            try
            {
                _Resource1 = SerializationHelper.Load<Mod.Resource1>(AppDomain.CurrentDomain.BaseDirectory + @"Config/Resource1.xml");

                var repository = LogManager.CreateRepository("NETCoreRepository");  //UNDONE:（不确定是否可行）
                string path = @"Log4Net.config";
                //XmlConfigurator.Configure(new FileInfo(path));
                XmlConfigurator.Configure(repository, new FileInfo(path));
                LogHelp.Info("启动" + _Resource1.StrName + "...........");
                ThreadPool.SetMaxThreads(50, 80);
                IsolatorUtil.StartDataBlock();
                DbConfigRepertory dbconfig = new DbConfigRepertory();
                dbconfig.init();

                JobConfigRepertory jobs = new JobConfigRepertory();
                jobs.init();

                RabbitMqManage.Init();
                RabbitMqManage.ConsumeRegist();
                LogHelp.Info(_Resource1.StrName + "初始化成功................");
            }
            catch (System.Exception ex)
            {
               LogHelp.Error(typeof(GlobalService),ex);
            }
        }

        /// <summary>
        /// 释放系统
        /// </summary>
        public static void UnInit()
        {
            LogHelp.Info("停止" + _Resource1.StrName + "...........");
            try
            {
                RabbitMqManage.Stop();
            }
            catch (Exception ex)
            {
                LogHelp.Error(typeof(GlobalService), ex);
            }
            LogHelp.Info(_Resource1.StrName + "停止成功................");
        }
    }

    /// <summary>
    /// 证件种类
    /// </summary>
    public class ZJZL
    {
        /// <summary>
        /// 证件类别代码
        /// </summary>
        public string ZJLBDM { get; set; }

        /// <summary>
        /// 证件类别名称
        /// </summary>
        public string ZJLBMC { get; set; }
    }

    public class GJDQDMMC
    {
        public string GJDQ3 { get; set; }

        public string GJDQMC { get; set; }
    }
}
