﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStorageService.Mod
{
    public class Ga_JobConfig
    {
        public Guid ID { get; set; }
        //状态
        public bool state { get; set; }

        //job的服务名
        public string Name { get; set; }

        public string Conn { get; set; }
    }
}
