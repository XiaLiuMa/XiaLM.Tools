﻿using System;

namespace DataStorageService.Mod
{
    [Serializable]
    public class T_TDSSTJ
    {
        public string WYBS { get; set; }

        public string TDH { get; set; }

        public string KTZT { get; set; }

        public string YFZT { get; set; }

        public string ZTSJ { get; set; }

        public string CZYDM { get; set; }

        public string JCY { get; set; }

        public string SSBM { get; set; }

        public string STSJ { get; set; }

        public string YFRS { get; set; }

        public string BJCS { get; set; }

        public string BMYCS { get; set; }

        public string LKXM { get; set; }

        public string XB { get; set; }

        public string GJ { get; set; }

        public string CSRQ { get; set; }

        public string ZJZL { get; set; }

        public string ZJHM { get; set; }

        public string CRJLX { get; set; }

    }
}
