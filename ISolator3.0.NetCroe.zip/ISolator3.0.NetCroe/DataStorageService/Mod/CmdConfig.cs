﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Xml;
using Schedule.Common.Core;

namespace DataStorageService.Mod
{
    /// <summary>
    /// 配置文件管理
    /// </summary>
    public class CmdConfig
    {
        /// <summary>
        /// DbCmdConfig.xml文档路径
        /// </summary>
        public static string DbCmdConfig = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location) + "\\Config\\DbCmdConfig.xml";

        /// <summary>
        /// XML 文件管理器
        /// </summary>
        private static XmlFileManage xmFileManage = XmlFileManage.GetInstance();

        /// <summary>
        /// 获取公共配置节点命令
        /// <param name="cmds">所有命令点</param>
        /// <param name="tables">所有命令对应的表名</param>
        /// <param name="Keys">所有表对应的主键</param>
        /// </summary>
        public static void GetCommondCmds(out byte[] cmds, out Dictionary<byte, string> tables, out Dictionary<string, string[]> Keys)
        {
            GetCmdConfig("commond", out cmds, out tables, out Keys);
        }

        /// <summary>
        /// 获取指定名称下的命令，以及对应的表名，和键值。如获取公共配置节点，名称为commond
        /// </summary>
        /// <param name="name"></param>
        /// <param name="cmds"></param>
        /// <param name="tables"></param>
        /// <param name="Keys"></param>
        public static void GetCmdConfig(string name, out byte[] cmds, out Dictionary<byte, string> tables, out Dictionary<string, string[]> Keys)
        {
            cmds = null;
            tables = new Dictionary<byte, string>();
            Keys = new Dictionary<string, string[]>();

            XmlNodeList notes = xmFileManage.SelectNodes(xmFileManage.LoadFile(DbCmdConfig), "/cmds/" + name + "/item");
            List<byte> cmdLst = new List<byte>();
            foreach (XmlElement item in notes)
            {
                if (item.HasChildNodes == false) continue;

                XmlNodeList keyNotes = item.FirstChild.ChildNodes;
                if (keyNotes.Count > 0)
                {
                    byte c = Convert.ToByte(item.Attributes["cmd"].Value);
                    cmdLst.Add(c);
                    tables.Add(c, item.Attributes["table"].Value);

                    List<string> keyLst = new List<string>();
                    foreach (XmlElement subitem in keyNotes)
                    {
                        keyLst.Add(subitem.InnerText.ToUpper());
                    }
                    Keys.Add(item.Attributes["table"].Value, keyLst.ToArray());
                }

            }
            cmds = cmdLst.ToArray();
        }
    }
}
