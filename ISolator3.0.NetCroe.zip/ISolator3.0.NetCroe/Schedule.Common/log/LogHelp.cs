﻿using System;

// namespaces...
namespace Schedule.Common.log
{
    // public classes...
    public class LogHelp
    {
        // private fields...
        //private static readonly log4net.ILog errorLog = log4net.LogManager.GetLogger("logerror");
        //private static readonly log4net.ILog infoLog = log4net.LogManager.GetLogger("loginfo");
        private static readonly log4net.ILog errorLog = log4net.LogManager.GetLogger("NETCoreRepository", "logerror");
        private static readonly log4net.ILog infoLog = log4net.LogManager.GetLogger("NETCoreRepository", "loginfo");//UNDONE:（不确定是否可行）

        // public methods...
        public static void Debug(string message)
        {
            infoLog.Debug(message);
        }
        /// <summary>
        /// 将指定的<see cref="Exception"/>实例详细信息写入日志,同时会保存到数据库当中。
        /// </summary>
        /// <param name="ex">需要将详细信息写入日志的<see cref="Exception"/>实例。</param>
        public static void Error(Exception ex)
        {
            errorLog.Error("Exception caught", ex);
        }
        public static void Error(string message)
        {
            errorLog.Error(message);
        }
        public static void Error(object message, Exception ex)
        {
            errorLog.Error(message, ex);
        }
        public static void Fatal(object message, Exception exception)
        {
            errorLog.Fatal(message, exception);
        }
        /// <summary>
        /// 将指定的字符串信息写入日志。
        /// </summary>
        /// <param name="message">需要写入日志的字符串信息。</param>
        public static void Info(string message)
        {
            infoLog.Info(message);
        }
        public static void Warn(string message)
        {
            infoLog.Warn(message);
        }
    }
}
