﻿using log4net.Layout;
using log4net.Layout.Pattern;

// namespaces...
namespace Schedule.Common.log.Extention
{
    // public classes...
    public class EndTimePatternCovert : PatternLayoutConverter
    {
        // protected methods...
        protected override void Convert(System.IO.TextWriter writer, log4net.Core.LoggingEvent loggingEvent)
        {
            var message = loggingEvent.MessageObject as ScheduleLogMessage;
            if (message != null)
            {
                writer.Write(message.EndTime);
            }
        }
    }

    public class JobNamePatternCovert : PatternLayoutConverter
    {
        // protected methods...
        protected override void Convert(System.IO.TextWriter writer, log4net.Core.LoggingEvent loggingEvent)
        {
            var message = loggingEvent.MessageObject as ScheduleLogMessage;
            if (message != null)
            {
                writer.Write(message.JobName);
            }
        }
    }

    public class PatternLayoutExtention : PatternLayout
    {
        // public constructors...
        public PatternLayoutExtention()
        {
            this.AddConverter("JobName", typeof(JobNamePatternCovert));
            this.AddConverter("StartTime", typeof(StartTimePatternCovert));
            this.AddConverter("EndTime", typeof(EndTimePatternCovert));
        }
    }

    public class StartTimePatternCovert : PatternLayoutConverter
    {
        // protected methods...
        protected override void Convert(System.IO.TextWriter writer, log4net.Core.LoggingEvent loggingEvent)
        {
            var message = loggingEvent.MessageObject as ScheduleLogMessage;
            if (message != null)
            {
                writer.Write(message.StartTime);
            }
        }
    }
}
