﻿using System;

// namespaces...
namespace Schedule.Common.log
{
    // public classes...
    /// <summary>
    /// 调度任务消息日志
    /// </summary>
    public class ScheduleLogMessage
    {
        // public constructors...
        public ScheduleLogMessage(string name)
        {
            JobName = name;
            StartTime = DateTime.Now.ToString();
        }

        // public properties...
        /// <summary>
        /// 任务结束时间
        /// </summary>
        public string EndTime { get; set; }
        /// <summary>
        /// 任务名称
        /// </summary>
        public string JobName { get; set; }
        /// <summary>
        /// 任务开始时间
        /// </summary>
        public string StartTime { get; set; }

        // public methods...
        public override string ToString()
        {
            return string.Format("任务名：{0}，开始时间：{1}，结束时间：{2} ", JobName, StartTime, EndTime);
        }
    }
}
