﻿using System;
using log4net;

namespace Schedule.Common.Util
{
    /// <summary>
    /// Log4net日志
    /// </summary>
    public class LogUtil
    {
        //static ILog Logger=LogManager.GetLogger("DataEngine");
        static ILog Logger = LogManager.GetLogger("DataEngine","DataEngine");   //UNDONE:（不确定是否可行）

        public static void LogError(Type type, Exception ex)
        {
            ILog log = log4net.LogManager.GetLogger(type);
            log.Error("Exception caught", ex);
        }

        public static void LogDebug(Type type, string strLog)
        {
            ILog log = log4net.LogManager.GetLogger(type);
            log.Debug(strLog);
        }

        public static void LogInfo(string info)
        {
            Logger.Info(info);
        }
    }
}
