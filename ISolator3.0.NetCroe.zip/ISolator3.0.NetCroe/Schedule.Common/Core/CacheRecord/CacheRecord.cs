﻿
// namespaces...
namespace Schedule.Common.Core.CacheRecord
{
}
