﻿using Jobs_Common;
using Quartz;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.Service.Quarz;
using System;
using System.Collections.Generic;

namespace Jobs_KAASJTJ
{
    /// <summary>
    /// 口岸案事件统计调度任务
    /// </summary>
    [PersistJobDataAfterExecution]
    [DisallowConcurrentExecution]
    public class KAASJTJJobs : AbstractQuarztJob
    {
        #region  //自定义变量

        private string strCHWFWGRY = string.Empty;

        /// <summary>
        /// 查获在控人员统计
        /// </summary>
        string strCHZKRY = string.Empty;

        #endregion

        #region IJob 成员

        /// <summary>
        /// 调度任务入口
        /// </summary>
        /// <param name="context"></param>       
        public override void Run(IJobExecutionContext context)
        {
            try
            {
                strCHWFWGRY = GlobalJobs.GetSql("strCHWFWGRY");
                strCHZKRY = GlobalJobs.GetSql("strCHZKRY");
                foreach (ISqlOperate sql in LstSqlOperate)
                {
                    SecheduleWfwgTj(sql);
                }
            }
            catch(Exception ex)
            {
                throw;
            }
        }

        #endregion

        #region 口岸案事件统计

        private void SecheduleWfwgTj(ISqlOperate sql)
        {
            //string dt = DateTime.Now.ToString("yyyyMMdd");
            //string sqlCHWFWGRY = string.Format(strCHWFWGRY, dt);

            //string sqlCHZKRY = string.Format(strCHZKRY, dt);

            string dStart = DateTime.Now.ToString("yyyyMMdd000000");

            string dEnd = DateTime.Now.AddDays(1).ToString("yyyyMMdd235959");

            string sqlCHWFWGRY = string.Format(strCHWFWGRY, dStart, dEnd);

            string sqlCHZKRY = string.Format(strCHZKRY, dStart, dEnd);

            List<Dictionary<string, object>> lst = SqlUtil.Select(sqlCHWFWGRY, sql);

            IsolatorUtil.SendOneTime(lst, "KAASJTJ", 08,GlobalJobs.MaxSendCount, true);

            List<Dictionary<string, object>> lstzk = SqlUtil.Select(sqlCHZKRY, sql);
                
            IsolatorUtil.SendOneTime(lstzk, "KAASJTJ", 08,GlobalJobs.MaxSendCount, true);
        }
        #endregion
    }
}
