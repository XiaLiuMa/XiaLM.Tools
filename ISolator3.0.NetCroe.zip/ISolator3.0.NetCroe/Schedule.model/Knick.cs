﻿using System;

namespace Schedule.model
{
    [Serializable]
    public class Knick
    {
        /// <summary>
        /// 命令标识。默认为0
        /// </summary>
        private byte cmd = 0;

        public byte Cmd
        {
            get { return cmd; }
            set { cmd = value; }
        }

        /// <summary>
        /// 隔离器发送的数据
        /// </summary>
        private string value;

        public string Value
        {
            get { return this.value; }
            set { this.value = value; }
        }

    }
}
