﻿using System.Collections.Generic;

// namespaces...
namespace Schedule.model
{
    // public classes...
    public class ConsumerConfig
    {
        // public properties...
        public string ExchangeKey { get; set; }
        public string ExchangeName { get; set; }
        /// <summary>
        /// 同步时是否需要接收确认
        /// </summary>
        public bool IsAck { get; set; }
        /// <summary>
        /// 当前系统是否监听当前队列数据进行消费
        /// </summary>
        public bool IsListen { get; set; }
        /// <summary>
        /// 是否设置优先级
        /// </summary>
        public bool IsPriority { get; set; }
        /// <summary>
        /// 是否设置队列过期时间
        /// </summary>
        public bool IsTtl { get; set; }
        /// <summary>
        /// 优先级大小
        /// </summary>
        public int PrioritySize { get; set; }
        /// <summary>
        /// 队列名称
        /// </summary>
        public string QueueName { get; set; }
        /// <summary>
        /// 过期时间
        /// </summary>
        public int TtlTime { get; set; }
    }

    public class JobConfig
    {
        // public properties...
        /// <summary>
        /// 任务消息是否需要持久化
        /// </summary>
        public bool Durable { get; set; }
        /// <summary>
        /// 任务名称
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 任务的优先级。为-1表示不设置优先级
        /// </summary>
        public int Priority { get; set; }
        /// <summary>
        /// 当前任务消息的过期时间。为0表示不设置过期时间。
        /// </summary>
        public int TtlTime { get; set; }
    }

    public class PublishConfig
    {
        // public properties...
        public bool Default { get; set; }
        public string ExchangeKey { get; set; }
        public string ExchangeName { get; set; }
        public string ExchangeType { get; set; }
        /// <summary>
        /// 当前路由对应的任务
        /// </summary>
        public List<JobConfig> Jobs { get; set; }
    }

    public class RabbitMqConfig
    {
        // public properties...
        /// <summary>
        /// 每个通道连接池的大小
        /// </summary>
        public int ChannelPool { get; set; }
        /// <summary>
        /// 连接池大小
        /// </summary>
        public int ConnPool { get; set; }
        /// <summary>
        /// 当前消费者配置
        /// </summary>
        public List<ConsumerConfig> Consumers { get; set; }
        public string Ip { get; set; }
        public int Port { get; set; }
        /// <summary>
        /// 当前所有生产者配置
        /// </summary>
        public List<PublishConfig> Publishs { get; set; }
        public string Pwd { get; set; }
        public string Use { get; set; }
        public string Vhost { get; set; }
    }
}
