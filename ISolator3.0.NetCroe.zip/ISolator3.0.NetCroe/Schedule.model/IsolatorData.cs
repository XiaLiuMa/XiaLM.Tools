﻿using System;

// namespaces...
namespace Schedule.model
{
    // public classes...
    [Serializable]
    public class IsolatorData
    {
        // public properties...
        /// <summary>
        /// 命令标识
        /// </summary>
        public byte Cmd { get; set; }
        /// <summary>
        /// 数据对应的任务名称
        /// </summary>
        public string JobName { get; set; }
        /// <summary>
        /// 数据发送时间
        /// </summary>
        public string SendTime { get; set; }

        /// <summary>
        /// 数据接收时间
        /// </summary>
        public string ReceiveTime { get; set; }
        
        /// <summary>
        /// 数据内容
        /// </summary>
        public byte[] Value { get; set; }
    }
}
