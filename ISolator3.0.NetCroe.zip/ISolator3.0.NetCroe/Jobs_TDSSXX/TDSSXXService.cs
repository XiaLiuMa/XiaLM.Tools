﻿using Schedule.Engine.Core.Service.Engines;
using Schedule.Engine.Core.Service.Engines.CycleEngine;
using System;

namespace Jobs_TDSSXX
{
    /// <summary>
    /// 通道实时信息调度服务
    /// </summary>
    public class TDSSXXService : AbstractEngineService
    {
        public override string ServiceName
        {
            get { return "TDSSXX"; }
        }

        public override string ClassNote()
        {
            return "通道实时信息调度服务";
        }

        private TDSSXXJobs TDSSXXEngine;

        public override BaseCycleEngine Job
        {
            get
            {
                if (TDSSXXEngine == null)
                {
                    TDSSXXEngine= new TDSSXXJobs();
                }
                return TDSSXXEngine;
            }
        }
    }
}
