﻿using Jobs_Common;
using Newtonsoft.Json;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.Service.Engines.CycleEngine;
using Schedule.model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Jobs_TDSSXX
{
    /// <summary>
    /// 通道实时信息调度任务。
    /// 获取的信息主要用于字符叠加以及指挥中心项目勤务台数据显示
    /// </summary>
    public class TDSSXXJobs : BaseCycleEngine
    {
        #region //变量定义
        /// <summary>
        /// sql查询命令
        /// </summary>
        private string SqlText = string.Empty;

        /// <summary>
        /// 下台查询语句
        /// </summary>
        private string SqlXiaTai = string.Empty;

        #endregion

        #region //初始化

        public TDSSXXJobs()
        {
            SqlText = GlobalJobs.GetSql("TDSSXXST");

            SqlXiaTai = GlobalJobs.GetSql("SqlXiaTai");

            qu = Queue.Synchronized(qu);
        }

        #endregion

        #region //循环引擎执行方法

        static Queue qu = new Queue();

        private int quClearZeroNum = 0;

        private int quClearZeroNumMax = 10;

        /// <summary>
        /// 循环引擎执行方法
        /// </summary>
        /// <returns></returns>
        protected override bool DoDetect()
        {
            try
            {
                if (qu.Count > 200)
                {
                    qu.Dequeue();
                }

                foreach (ISqlOperate item in LstSqlOperate)
                {
                    //保存上台人员信息和旅客通关信息
                    List<Dictionary<string, object>> lst = new List<Dictionary<string, object>>();

                    //保存下台的人员信息
                    List<Dictionary<string, object>> lstxt = new List<Dictionary<string, object>>();

                    int newCount = 0;

                    SelectTdssxx(item, ref lst);

                    if (lst.Count != 0)
                    {
                        newCount = SendNewData(lst);
                    }

                    //获取下台的信息
                    SelectTdxtxx(item, ref lstxt);

                    if (lstxt.Count != 0)
                    {
                        newCount += SendXTData(lstxt);
                    }

                    if (newCount == 0)
                    {
                        quClearZeroNum++;
                        if (quClearZeroNum > quClearZeroNumMax)
                        {
                            qu.Clear();
                            quClearZeroNum = 0;
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
            return true;
        }

        #region 获取通道实时相关信息
        /// <summary>
        /// 获取通道实时相关信息
        /// <param name="lst">保存的数据列表</param>
        /// </summary>
        private void SelectTdssxx(ISqlOperate sqlOperate, ref List<Dictionary<string, object>> lst)
        {
            DataSet ds = new DataSet();

            sqlOperate.RunSQL(SqlText, ref ds);
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                string strKey = dr["VALKEY"].ToString();
                if (!(dr["pjnr"] is DBNull) && dr["pjnr"].ToString() == "0")
                {
                    strKey = strKey.Substring(0, strKey.Length - 1);
                }
                if (qu.Contains(strKey))
                {
                    continue;
                }
                qu.Enqueue(strKey);

                Dictionary<string, object> data = new Dictionary<string, object>();
                foreach (DataColumn dc in ds.Tables[0].Columns)
                {
                    string temp = "0";
                    if (!(dr[dc] is DBNull))
                    {
                        temp = dr[dc].ToString();
                    }

                    temp.Replace(" ", "");

                    data.Add(dc.ColumnName, temp);
                }
                lst.Add(data);
            }
        }
        #endregion

        #region 获取下台的通道信息
        /// <summary>
        /// 获取下台的通道信息
        /// <param name="lst">保存的数据列表</param>
        /// </summary>
        private void SelectTdxtxx(ISqlOperate sqlOperate, ref List<Dictionary<string, object>> lst)
        {
            DataSet ds = new DataSet();
            sqlOperate.RunSQL(SqlXiaTai, ref ds);
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                string strKey = dr["VALKEY"].ToString();
                if (qu.Contains(strKey))
                {
                    continue;
                }
                qu.Enqueue(strKey);

                Dictionary<string, object> data = new Dictionary<string, object>();
                foreach (DataColumn dc in ds.Tables[0].Columns)
                {
                    string temp = "0";
                    if (!(dr[dc] is DBNull))
                    {
                        temp = dr[dc].ToString();
                    }
                    data.Add(dc.ColumnName, temp);
                }
                lst.Add(data);
            }
        }
        #endregion

        #region 发送信息。将每一行的数据格式化为{key:value}的形式，进行发送。
        /// <summary>
        /// 发送信息。将每一行的数据格式化为{key:value}的形式，进行发送。
        /// 隔离器发送命令为01
        /// </summary>
        /// <param name="lst"></param>
        private int SendNewData(List<Dictionary<string, object>> lst)
        {
            IsolatorData isd = new IsolatorData();
            isd.Cmd = 01;
            isd.Value = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(lst));

            int newCount = lst.Count; //记录当前发送新数据的记录

            IsolatorUtil.SendOneTime(lst, "TDSSXX",01,GlobalJobs.MaxSendCount, true);

            return newCount;
        }
        #endregion

        #region 发送下台信息，发送命令为02
        /// <summary>
        /// 发送下台信息，发送命令为02
        /// </summary>
        /// <param name="lst"></param>
        /// <returns></returns>
        private int SendXTData(List<Dictionary<string, object>> lst)
        {
            IsolatorData isd = new IsolatorData();
            isd.Cmd = 02;
            isd.Value = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(lst));
            IsolatorUtil.SendOneTime(lst, "TDSSXX", 02, GlobalJobs.MaxSendCount,true);
            int newCount = lst.Count; //记录当前发送新数据的记录

            return newCount;
        }
        #endregion
        #endregion
    }
}
