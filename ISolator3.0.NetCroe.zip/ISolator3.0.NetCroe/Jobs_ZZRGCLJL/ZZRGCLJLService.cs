﻿using Schedule.Engine.Core.Service.Quarz;
using System;

/* ==============================
*
* 作者: 胡军会
* 创建时间：2018-06-20 15:26:06
* 文件名称：ZZRGCLJLService
* 版本：V1.0.1
* 修改时间:
* 修改人：
* 修改备注：
* ===============================
*/
namespace Jobs_ZZRGCLJL
{
    public class ZZRGCLJLService : AbstractScheduleService
    {
        public override string ServiceName
        {
            get { return "ZZRGCLJL"; }
        }

        public override string ClassNote()
        {
            return "自助通道人工处理记录调度服务";
        }

        public override Type GetJobType()
        {
            return typeof(ZZRGCLJLJobs);
        }
    }
}
