﻿using Jobs_Common;
using Schedule.Common.log;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.Service.Quarz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* ==============================
*
* 作者: 胡军会
* 创建时间：2018-06-20 15:26:22
* 文件名称：ZZRGCLJLJobs
* 版本：V1.0.1
* 修改时间:
* 修改人：
* 修改备注：
* ===============================
*/
namespace Jobs_ZZRGCLJL
{
    public class ZZRGCLJLJobs : AbstractQuarztJob
    {
        public override void Run(Quartz.IJobExecutionContext context)
        {
            foreach (ISqlOperate sql in LstSqlOperate)
            {
                try
                {
                    string strSql = GlobalJobs.GetSql("ZZRGCLJL");

                    string str = string.Format(strSql, DateTime.Now.ToString("yyyyMMdd"), DateTime.Now.ToString("yyyyMMdd"), DateTime.Now.AddMinutes(-1).ToString("HHmmss"), DateTime.Now.ToString("HHmmss"));

                    List<Dictionary<string, object>> lst = SqlUtil.Select(str, sql);
                    List<Dictionary<string, object>> lstSend = new List<Dictionary<string, object>>();
                    foreach (Dictionary<string, object> dic in lst)
                    {
                        string strwybs = GlobalJobs.GetSql("ZZRGCLJLWYBS");
                        string clsj = dic["CLRQ"].ToString() + dic["CLSJ"].ToString();
                        DateTime dtClsj = DateTime.ParseExact(clsj, "yyyyMMddHHmmss", System.Globalization.CultureInfo.CurrentCulture);
                        string startDt = dtClsj.AddHours(-5).ToString("yyyyMMddHHmmss");
                        string endDt = dtClsj.AddHours(5).ToString("yyyyMMddHHmmss");
                        string strSqlWybs = string.Format(strwybs, startDt, endDt, dic["ZJHM"], dic["KADM"], dic["TDH"]);

                        List<Dictionary<string, object>> lstWybs = SqlUtil.Select(strSqlWybs, sql);
                        string wybs = lstWybs != null && lstWybs.Count > 0 && lstWybs[0]["WYBS"] != null ? lstWybs[0]["WYBS"].ToString() : "";
                        if (!string.IsNullOrEmpty(wybs))
                        {
                            dic.Add("WYBS", wybs);
                            lstSend.Add(dic);
                        }
                    }
                    IsolatorUtil.SendOneTime(lst, "ZZRGCLJL", 252, GlobalJobs.MaxSendCount);
                }
                catch (Exception ex)
                {
                    LogHelp.Error(ex);
                }
            }
        }
    }
}
