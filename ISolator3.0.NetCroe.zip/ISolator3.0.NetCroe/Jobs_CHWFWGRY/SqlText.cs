﻿
namespace Jobs_CHWFWGRY
{
    /// <summary>
    /// SQL
    /// </summary>
    public class SqlText
    {
        /// <summary>
        /// 查货违法违规人员
        /// </summary>
        public static string chwfwgry = "SELECT SJBH,"+
                                         "GLSJBH,"+
                                         "XM,"+
                                         "RYLBDM,"+
                                         "GJDQDM,"+
                                         "XBDM,"+
                                         "CSRQ,"+
                                         "ZJLBDM,"+
                                         "ZJHM,"+
                                         "QZZLDM,"+
                                         "D2ZH,"+
                                         "D2ZJLBDM,"+
                                         "D2CSRQ,"+
                                         "D2XM,"+
                                         "FZD,"+
                                         "QFGJDQDM,"+
                                         "QFYYDM,"+
                                         "CJKADM,"+
                                         "CJSJ,"+
                                         "CRKADM,"+
                                         "JTFSDM,"+
                                         "JTGJBS,"+
                                         "QWLZG,"+
                                         "SFMDD,"+
                                         "CRJSYDM,"+
                                         "TDH,"+
                                         "NBTH,"+
                                         "LXTH,"+
                                         "CDDM,"+
                                         "CCLBMDM,"+
                                         "CKBZ,"+
                                         "YCTJLY,"+
                                         "SJLBDM,"+
                                         "SJXZDM,"+
                                         "JCYMS,"+
                                         "SJMS,"+
                                         "SJZT,"+
                                         "GWZL,"+
                                         "CCXMBZ,"+
                                         "YNZSM,"+
                                         "LRBZ,"+
                                         "SPR,"+
                                         "SPJB,"+
                                         "LZKCKSJBH,"+
                                         "JPR,"+
                                         "JPSJ,"+
                                         "CHR,"+
                                         "CHBMDM,"+
                                         "CHSJ,"+
                                         "LRR,"+
                                         "LRSJ,"+
                                         "XZZD,"+
                                         "JCBZ,"+
                                         "CRJBZ,"+
                                         "ZLLY,"+
                                         "CLBZ,"+
                                         "KGRXX,"+
                                         "MZDM,"+
                                         "ZDYDM,"+
                                         "HTBLBJ,"+
                                         "CRBZ,"+
                                         "ZZTDBJ,"+
                                         "QRSJXZDM,"+
                                         "CLJGDM,"+
                                         "MSJE,"+
                                         "FKJE,"+
                                         "GDBZ,"+
                                         "JLTS,"+
                                         "QRSJ,"+
                                         "ZFBJ,"+
                                         "ZFYY,"+
                                         "JLCRJBZ,"+
                                         "QRSJLBDM,"+
                                         "RKSJ,"+
                                         "GZDWMC,"+
                                         "QZH,"+
                                         "TLQ "+
                                         "from bj_yw_t_chwfwgry "+
                                         "where to_date(LRSJ, 'yyyymmddhh24miss') >=" +
                                         "to_date('{0}', 'yyyymmddhh24miss') " +
                                         "and to_date(LRSJ, 'yyyymmddhh24miss') <" +
                                         "to_date('{1}', 'yyyymmddhh24miss')";
    }
}
