﻿using Jobs_Common;
using Quartz;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.Service.Quarz;
using System;
using System.Collections.Generic;

namespace Jobs_CHWFWGRY
{
    /// <summary>
    /// 查获违法违规人员调度任务
    /// </summary>
    [PersistJobDataAfterExecution]
    [DisallowConcurrentExecution]
    public class CHWFWGRYJobs : AbstractQuarztJob
    {
        public override void Run(IJobExecutionContext context)
        {
            try 
            {
                foreach (ISqlOperate sql in LstSqlOperate)
                {
                    string strSql = GlobalJobs.GetSql("chwfwgry");

                    string str = string.Format(strSql, DateTime.Now.ToString("yyyyMMdd000000"), DateTime.Now.ToString("yyyyMMdd235959"));

                    List<Dictionary<string, object>> lst = SqlUtil.Select(str, sql);

                    IsolatorUtil.SendOneTime(lst, "CHWFWGRY", 247,  GlobalJobs.MaxSendCount,true);
                }
            }
            catch
            {
                throw;
            }
        }
    }
}
