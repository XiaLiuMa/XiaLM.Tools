﻿using Schedule.Engine.Core.Service.Quarz;
using System;

namespace Jobs_ZDYMT
{
    /// <summary>
    /// 自定义每天调度服务
    /// </summary>
    public class ZDYMTService : AbstractScheduleService
    {
        /// <summary>
        /// 当前调度服务名称
        /// </summary>
        public override string ServiceName
        {
            get { return "ZDYMT"; }
        }

        /// <summary>
        /// 类说明，做为调度器名称
        /// </summary>
        /// <returns></returns>
        public override string ClassNote()
        {
            return "自定义每天调度服务";
        }

        /// <summary>
        /// 获取当前任务类型
        /// </summary>
        /// <returns></returns>
        public override Type GetJobType()
        {
            return typeof(ZDYMTJobs);
        }
    }
}
