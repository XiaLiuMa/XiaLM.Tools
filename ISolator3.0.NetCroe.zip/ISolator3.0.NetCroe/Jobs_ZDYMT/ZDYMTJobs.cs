﻿using Jobs_Common;
using Jobs_Common.Mod;
using Quartz;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.Service.Quarz;
using System;
using System.Collections.Generic;

namespace Jobs_ZDYMT
{
    /// <summary>
    /// 自定义每天调度任务
    /// </summary>
    [PersistJobDataAfterExecution]
    [DisallowConcurrentExecution]
    public class ZDYMTJobs : AbstractQuarztJob
    {
        #region IJob 成员

        /// <summary>
        /// 调度任务入口
        /// </summary>
        /// <param name="context"></param>       
        public override void Run(IJobExecutionContext context)
        {
            try
            {
                List<SqlEx> lstSql = GlobalJobs.GetJobSql("Jbos_ZDYMT");
                if (lstSql != null && lstSql.Count > 0)
                {
                    foreach (ISqlOperate sql in LstSqlOperate)
                    {
                        foreach (SqlEx ss in lstSql)
                        {
                            List<Dictionary<string, object>> lst = SqlUtil.Select(ss.SqlText, sql);
                            IsolatorUtil.SendOneTime(lst, "ZDYMS", Convert.ToByte(ss.Cmd),GlobalJobs.MaxSendCount);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion
    }
}
