﻿using Jobs_Common;
using Newtonsoft.Json;
using Schedule.Common.Core.CacheRecord;
using Schedule.Common.Extention;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.Service.Engines.CycleEngine;
using Schedule.model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Jobs_MSSSYWBJ
{
    /// <summary>
    /// 梅沙实时业务报警调度任务
    /// </summary>
    public class MSSSYWBJJobs : BaseCycleEngine
    {
        public MSSSYWBJJobs()
        {
            qu = Queue.Synchronized(qu);
            strSql = GlobalJobs.GetSql("MSSSYWBJ");
        }

        private string strSql = string.Empty;

        private Hashtable maxAbnormalTimeCache = Hashtable.Synchronized(new Hashtable());

        /// <summary>
        /// 缓存记录
        /// </summary>
        private ICacheRecord CacheRecord;

        public void CacheAbnormalTime(string cacheKey, string strTime)
        {
            maxAbnormalTimeCache[cacheKey] = strTime;
        }

        #region 报警过期时间
        /// <summary>
        /// 报警过期时间
        /// </summary>
        private int TIME_OUT
        {
            get
            {
                return 5*1000;
            }
        }
        #endregion

        #region 最近黑名单报警的时间
        /// <summary>
        /// 最近黑名单报警的时间
        /// 异常：返回NULL
        /// </summary>
        private string PreviousAbnormalTime
        {
            get
            {
                if (maxAbnormalTimeCache["AbnormalTime"] != null)
                {
                    return maxAbnormalTimeCache["AbnormalTime"].ToString();
                }
                else
                {
                    string sqllast = "select max(fssj) as fssj from qgtg.bj_yw_t_jrgz";
                    DataSet ds = new DataSet();
                    LstSqlOperate[0].RunSQL(sqllast,ref ds);
                    object obj = ds.Tables[0].Rows[0]["fssj"];
                    if (obj != null)
                    {
                        CacheAbnormalTime("AbnormalTime", obj.ToString());
                        return obj.ToString();
                    }
                    else
                    { 
                       return null;
                    }
                }
            }
        }
        #endregion

        static Queue qu = new Queue();
        protected override bool DoDetect()
        {
            try
            {
                if (qu.Count > 200)
                {
                    qu.Dequeue();
                }
                if (string.IsNullOrEmpty(PreviousAbnormalTime))
                {
                    return true;
                }

                string sqlAbnormalAcceptanceList = string.Format(strSql, PreviousAbnormalTime);

                List<Dictionary<string, object>> lst = new List<Dictionary<string, object>>();

                SelectMSYWBJ(LstSqlOperate[0], sqlAbnormalAcceptanceList, ref lst);

                if (lst.Count != 0)
                {
                    SendNewData(lst);
                }
            }
            catch
            {
                throw;
            }

            return true;
        }

        #region 获取梅沙业务报警数据
        /// <summary>
        /// 获取梅沙业务报警数据
        /// <param name="lst">保存的数据列表</param>
        /// </summary>
        private void SelectMSYWBJ(ISqlOperate sqlOperate, string SqlText, ref List<Dictionary<string, object>> lst)
        {
            DataSet ds = new DataSet();

            sqlOperate.RunSQL(SqlText, ref ds);

            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                string strKey = dr["VALKEY"].ToString();
                if (qu.Contains(strKey))
                {
                    continue;
                }
                qu.Enqueue(strKey);

                string fssj = dr["fssj"].ToString();

                string datenow = dr["datenow"].ToString();
                DateTime DateTime1 = fssj.FormatFssj(null);
                DateTime DateTime2 = Convert.ToDateTime(datenow);

                double eventDuration = DateTime1.CompareCalculate(DateTime2);//

                if (eventDuration < TIME_OUT)
                {
                    Dictionary<string, object> data = new Dictionary<string, object>();
                    foreach (DataColumn dc in ds.Tables[0].Columns)
                    {
                        string temp = "0";
                        if (!(dr[dc] is DBNull))
                        {
                            temp = dr[dc].ToString();
                        }

                        temp.Replace(" ", "");

                        data.Add(dc.ColumnName, temp);
                    }
                    lst.Add(data);
                }

                CacheAbnormalTime("AbnormalTime", fssj);
            }
        } 
        #endregion

        #region 发送信息。将每一行的数据格式化为{key:value}的形式，进行发送。
        /// <summary>
        /// 发送信息。将每一行的数据格式化为{key:value}的形式，进行发送。
        /// 隔离器发送命令为41
        /// </summary>
        /// <param name="lst"></param>
        private void SendNewData(List<Dictionary<string, object>> lst)
        {
            foreach (Dictionary<string, object> item in lst)
            {
                IsolatorData isd = new IsolatorData();
                isd.Cmd = 41;
                isd.Value = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(item));

                IsolatorUtil.OnSend(isd, "MSSSYWBJ");

                IsolatorData isdZFDJ = new IsolatorData();
                isd.Cmd = 1;
                item.Add("PJNR","5");
                item.Add("gzzzt","2");
                isd.Value = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(item));
                IsolatorUtil.OnSend(isdZFDJ, "MSSSYWBJ");
            }
        } 
        #endregion
    }
}
