﻿using Schedule.Engine.Core.Service.Engines;
using Schedule.Engine.Core.Service.Engines.CycleEngine;

namespace Jobs_MSSSYWBJ
{
    /// <summary>
    /// 梅沙实时业务报警调度服务
    /// </summary>
    public class MSSSYWBJService : AbstractEngineService
    {
        public override string ServiceName
        {
            get { return "MSSSYWBJ"; }
        }

        public override string ClassNote()
        {
            return "梅沙实时业务报警调度服务";
        }

        private MSSSYWBJJobs MSSSYWBJEngine;

        public override BaseCycleEngine Job
        {
            get
            {
                if (MSSSYWBJEngine == null)
                {
                    MSSSYWBJEngine = new MSSSYWBJJobs();
                }
                return MSSSYWBJEngine;
            }
        }
    }
}
