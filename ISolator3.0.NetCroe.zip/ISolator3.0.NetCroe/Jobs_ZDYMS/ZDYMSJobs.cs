﻿using Jobs_Common;
using Jobs_Common.Mod;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.Service.Engines.CycleEngine;
using System;
using System.Collections.Generic;

namespace Jobs_ZDYMS
{
    /// <summary>
    /// 自定义每秒调度任务
    /// </summary>
    public class ZDYMSJobs : BaseCycleEngine
    {
        /// <summary>
        /// 数据库操作接口
        /// </summary>
        /// </summary>
        private List<ISqlOperate> lstSqlOperate;

        public List<ISqlOperate> LstSqlOperate
        {
            get { return lstSqlOperate; }
            set { lstSqlOperate = value; }
        }

        protected override bool DoDetect()
        {
            try
            {
                List<SqlEx> lstSql = GlobalJobs.GetJobSql("Jbos_ZDYMS");
                if (lstSql != null && lstSql.Count > 0)
                {
                    foreach (ISqlOperate sql in LstSqlOperate)
                    {
                        foreach (SqlEx ss in lstSql)
                        {
                            List<Dictionary<string, object>> lst = SqlUtil.Select(ss.SqlText, sql);
                            IsolatorUtil.SendOneTime(lst, "ZDYMS", Convert.ToByte(ss.Cmd), GlobalJobs.MaxSendCount);
                        }
                    }
                }
            }
            catch
            {
                throw;
            }

            return true;
        }
    }
}
