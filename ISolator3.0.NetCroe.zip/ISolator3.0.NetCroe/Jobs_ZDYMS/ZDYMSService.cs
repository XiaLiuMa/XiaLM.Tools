﻿using Schedule.Engine.Core.Service.Engines;
using Schedule.Engine.Core.Service.Engines.CycleEngine;

namespace Jobs_ZDYMS
{
    /// <summary>
    /// 自定义每秒调度服务
    /// </summary>
    public class ZDYMSService : AbstractEngineService
    {
        public override string ServiceName
        {
            get { return "ZDYMS"; }
        }

        public override string ClassNote()
        {
            return "自定义每秒调度服务";
        }

        private ZDYMSJobs ZDYMS;

        public override BaseCycleEngine Job
        {
            get
            {
                if (ZDYMS == null)
                {
                    ZDYMS = new ZDYMSJobs();
                }
                return ZDYMS;
            }
        }
    }
}
