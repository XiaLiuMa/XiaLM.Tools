﻿using Jobs_Common;
using Quartz;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.Service.Quarz;
using System;
using System.Collections.Generic;

namespace Jobs_YJYL
{
    /// <summary>
    /// 预检预录调度任务
    /// </summary>
    [PersistJobDataAfterExecution]
    [DisallowConcurrentExecution]
    public class YJYLJobs : AbstractQuarztJob
    {
        #region  //自定义变量

        private string strSql = GlobalJobs.GetSql("YJYL");

        #endregion

        #region IJob 成员

        /// <summary>
        /// 调度任务入口
        /// </summary>
        /// <param name="context"></param>       
        public override void Run(IJobExecutionContext context)
        {
            try
            {
                foreach (ISqlOperate sql in LstSqlOperate)
                {
                    SecheduleKadryfTj(sql);
                }
            }
            catch
            {
                throw;
            }
        }

        #endregion

        #region //预检预录数据统计

        /// <summary>
        /// 按口岸预检预录,只统计当天当前的数据
        /// </summary>
        private void SecheduleKadryfTj(ISqlOperate sql)
        {
            string startDDSJ =DateTime.Now.ToString("yyyyMMdd000000");

            string endDDSJ = DateTime.Now.ToString("yyyyMMdd235959");
            string dt = DateTime.Now.ToString("yyyyMMdd");
            string cmdText = string.Format(strSql, startDDSJ, endDDSJ, dt);

            try
            {
                List<Dictionary<string, object>> lst = SqlUtil.Select(cmdText, sql);
                IsolatorUtil.SendOneTime(lst, "YJYL", 10, GlobalJobs.MaxSendCount);
            }
            catch
            {
                throw;
            }
        }

        #endregion
    }
}
