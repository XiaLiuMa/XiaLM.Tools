﻿using DAL.IDAL;
using DAL.Mod;
using Schedule.Common.SqlHelp;
using Schedule.Common.SqlHelp.Impl;
using Schedule.Engine.Model;
using System.Configuration;

namespace DAL.AccessDAL
{
    public class RunLogSqliteDAL : AbstractSqliteDAL<RunLog>, IRunLogDAL
    {
        public override Schedule.Common.SqlHelp.ISqlOperate SqlOperate
        {
            get
            {
                string strSqlite = string.Format(@"Data Source={0};Version=3; Password=max123456;", DataEngine_BaseDataConfig.baseDataConfig.IsolatorDbStr);
                ISqlOperate sqlOperate = new SqliteSqlOperate();
                sqlOperate.DbConStr = strSqlite;
                return sqlOperate;
            }
        }
    }
}
