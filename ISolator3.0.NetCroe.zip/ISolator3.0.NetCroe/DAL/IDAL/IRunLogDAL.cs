﻿using DAL.Mod;

namespace DAL.IDAL
{
    public interface IRunLogDAL : ISQLDAL<RunLog>
    {

    }
}
