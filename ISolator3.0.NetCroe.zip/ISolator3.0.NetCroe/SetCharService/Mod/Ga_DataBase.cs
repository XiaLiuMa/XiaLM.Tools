﻿using System;
using System.Xml.Serialization;

namespace SetCharService.Mod
{
    public class Ga_DataBase
    {
        [XmlElement("guid")]
        public Guid ID { get; set; }

        /// <summary>
        /// 数据库IP地址
        /// </summary>
        public string ServerIp { get; set; }

        /// <summary>
        /// 数据库端口
        /// </summary>
        public string ServerPort { get; set; }

        /// <summary>
        /// 数据库名称
        /// </summary>
        public string DataBaseName { get; set; }

        /// <summary>
        /// 数据库用户名
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 数据库密码
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// 是否为默认数据库
        /// </summary>
        public bool Default { get; set; }

    }
}
