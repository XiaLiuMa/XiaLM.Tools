﻿using System;

namespace SetCharService.Mod
{
    /// <summary>
    /// 字符叠加-网络设备对应关系视图
    /// </summary>
    [Serializable]
    public class View_QWSJ_ZFDJ_WLSBDYGX
    {
        private string _TDH;
        private int? _CZYDM_DJZB_X;
        private int? _CZYDM_DJZB_Y;
        private int? _CZYXM_DJZB_X;

        private int? _CZYXM_DJZB_Y;
        private int? _CZYBM_DJZB_X;
        private int? _CZYBM_DJZB_Y;
        private int? _LKZJHM_DJZB_X;
        private int? _LKZJHM_DJZB_Y;
        private int? _LKXM_DJZB_X;
        private int? _LKXM_DJZB_Y;
        private int? _LKPJXX_DJZB_X;
        private int? _LKPJXX_DJZB_Y;
        private string _SBXH;
        private string _IPADDRESS;
        private int _PORT;
        private int _CHANNEL;
        private string _USER_NAME;
        private string _USER_PWD;

        /// <summary>
        /// 通道号
        /// </summary>    
        public string TDH
        {
            get { return _TDH; }
            set { _TDH = value; }
        }

        /// <summary>
        /// 操作员代码X坐标
        /// </summary>
        public int? CZYDM_DJZB_X
        {
            get { return _CZYDM_DJZB_X; }
            set { _CZYDM_DJZB_X = value; }
        }

        /// <summary>
        /// 操作员代码Y坐标
        /// </summary>
        public int? CZYDM_DJZB_Y
        {
            get { return _CZYDM_DJZB_Y; }
            set { _CZYDM_DJZB_Y = value; }
        }

        /// <summary>
        /// 操作员姓名X坐标
        /// </summary>
        public int? CZYXM_DJZB_X
        {
            get { return _CZYXM_DJZB_X; }
            set { _CZYXM_DJZB_X = value; }
        }

        /// <summary>
        /// 操作员姓名Y坐标
        /// </summary>
        public int? CZYXM_DJZB_Y
        {
            get { return _CZYXM_DJZB_Y; }
            set { _CZYXM_DJZB_Y = value; }
        }

        /// <summary>
        /// 操作员部门X坐标
        /// </summary>
        public int? CZYBM_DJZB_X
        {
            get { return _CZYBM_DJZB_X; }
            set { _CZYBM_DJZB_X = value; }
        }

        /// <summary>
        /// 操作员部门Y坐标
        /// </summary>
        public int? CZYBM_DJZB_Y
        {
            get { return _CZYBM_DJZB_Y; }
            set { _CZYBM_DJZB_Y = value; }
        }

        /// <summary>
        /// 旅客证件号码X坐标
        /// </summary>
        public int? LKZJHM_DJZB_X
        {
            get { return _LKZJHM_DJZB_X; }
            set { _LKZJHM_DJZB_X = value; }
        }

        /// <summary>
        /// 旅客证件号码Y坐标
        /// </summary>
        public int? LKZJHM_DJZB_Y
        {
            get { return _LKZJHM_DJZB_Y; }
            set { _LKZJHM_DJZB_Y = value; }
        }

        /// <summary>
        /// 旅客姓名X坐标
        /// </summary>
        public int? LKXM_DJZB_X
        {
            get { return _LKXM_DJZB_X; }
            set { _LKXM_DJZB_X = value; }
        }

        /// <summary>
        /// 旅客姓名Y坐标
        /// </summary>
        public int? LKXM_DJZB_Y
        {
            get { return _LKXM_DJZB_Y; }
            set { _LKXM_DJZB_Y = value; }
        }

        /// <summary>
        /// 旅客评价内容X坐标
        /// </summary>
        public int? LKPJXX_DJZB_X
        {
            get { return _LKPJXX_DJZB_X; }
            set { _LKPJXX_DJZB_X = value; }
        }

        /// <summary>
        /// 旅客评价内容Y坐标
        /// </summary>
        public int? LKPJXX_DJZB_Y
        {
            get { return _LKPJXX_DJZB_Y; }
            set { _LKPJXX_DJZB_Y = value; }
        }

        /// <summary>
        /// 旅客国籍X坐标
        /// </summary>
        public int? LKGJ_DJZB_X
        {
            get;
            set;
        }

        /// <summary>
        /// 旅客国籍内容Y坐标
        /// </summary>
        public int? LKGJ_DJZB_Y
        {
            get;
            set;
        }

        /// <summary>
        /// 航班号X坐标
        /// </summary>
        public int? JTGJ_DJZB_X
        {
            get;
            set;
        }

        /// <summary>
        /// 航班号内容Y坐标
        /// </summary>
        public int? JTGJ_DJZB_Y
        {
            get;
            set;
        }

        /// <summary>
        /// 设备型号
        /// </summary>
        public string SBXH
        {
            get { return _SBXH; }
            set { _SBXH = value; }
        }
        /// <summary>
        /// 设备IP地址
        /// </summary>
        public string IPADDRESS
        {
            get { return _IPADDRESS; }
            set { _IPADDRESS = value; }
        }

        /// <summary>
        /// 设备端口号
        /// </summary>
        public int PORT
        {
            get { return _PORT; }
            set { _PORT = value; }
        }
        /// <summary>
        /// 设备通道号
        /// </summary>
        public int CHANNEL
        {
            get { return _CHANNEL; }
            set { _CHANNEL = value; }
        }
        /// <summary>
        /// 设备用户名
        /// </summary>
        public string USER_NAME
        {
            get { return _USER_NAME; }
            set { _USER_NAME = value; }
        }
        /// <summary>
        /// 设备密码
        /// </summary>
        public string USER_PWD
        {
            get { return _USER_PWD; }
            set { _USER_PWD = value; }
        }
    }
}
