﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SetCharService.Mod
{
    public class Resource1
    {
        public string StrName { get; set; }
    }
}
