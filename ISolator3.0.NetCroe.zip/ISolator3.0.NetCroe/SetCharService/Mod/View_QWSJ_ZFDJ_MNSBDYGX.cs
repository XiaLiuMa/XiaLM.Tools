﻿
namespace SetCharService.Mod
{
    public class View_QWSJ_ZFDJ_MNSBDYGX
    {
        private string _port_name;
        private int _baudrate;
        private int _databits;
        private string _parity;
        private string _stopbits;
        private string _handshake;
        private string _mstdh;
        private string _sblx;
        private int? _jktdh;
        private int? _czydm_djzb_x;
        private int? _czydm_djzb_y;
        private int? _czyxm_djzb_x;
        private int? _czyxm_djzb_y;
        private int? _czybm_djzb_x;
        private int? _czybm_djzb_y;
        private int? _lkzjhm_djzb_x;
        private int? _lkzjhm_djzb_y;
        private int? _lkxm_djzb_x;
        private int? _lkxm_djzb_y;
        private int? _lkpjxx_djzb_x;
        private int? _lkpjxx_djzb_y;
        private string _cksbid;

        /// <summary>
        /// 串口名称
        /// </summary>
        public string PORT_NAME
        {
            set { _port_name = value; }
            get { return _port_name; }
        }
        /// <summary>
        /// 串口波特率
        /// </summary>
        public int BAUDRATE
        {
            set { _baudrate = value; }
            get { return _baudrate; }
        }
        /// <summary>
        /// 串口数据位
        /// </summary>
        public int DATABITS
        {
            set { _databits = value; }
            get { return _databits; }
        }
        /// <summary>
        /// 串口校验位
        /// </summary>
        public string PARITY
        {
            set { _parity = value; }
            get { return _parity; }
        }
        /// <summary>
        /// 串口停止位
        /// </summary>
        public string STOPBITS
        {
            set { _stopbits = value; }
            get { return _stopbits; }
        }
        /// <summary>
        /// 串口握手协议
        /// </summary>
        public string HANDSHAKE
        {
            set { _handshake = value; }
            get { return _handshake; }
        }
        /// <summary>
        /// 梅沙通道号
        /// </summary>
        public string MSTDH
        {
            set { _mstdh = value; }
            get { return _mstdh; }
        }
        /// <summary>
        /// 设备类型
        /// </summary>
        public string SBLX
        {
            set { _sblx = value; }
            get { return _sblx; }
        }
        /// <summary>
        /// 监控通道号
        /// </summary>
        public int? JKTDH
        {
            set { _jktdh = value; }
            get { return _jktdh; }
        }
        /// <summary>
        /// 操作员代码叠加坐标-X
        /// </summary>
        public int? CZYDM_DJZB_X
        {
            set { _czydm_djzb_x = value; }
            get { return _czydm_djzb_x; }
        }
        /// <summary>
        /// 操作员代码叠加坐标-Y
        /// </summary>
        public int? CZYDM_DJZB_Y
        {
            set { _czydm_djzb_y = value; }
            get { return _czydm_djzb_y; }
        }
        /// <summary>
        /// 操作员姓名叠加坐标-X
        /// </summary>
        public int? CZYXM_DJZB_X
        {
            set { _czyxm_djzb_x = value; }
            get { return _czyxm_djzb_x; }
        }
        /// <summary>
        /// 操作员姓名叠加坐标-Y
        /// </summary>
        public int? CZYXM_DJZB_Y
        {
            set { _czyxm_djzb_y = value; }
            get { return _czyxm_djzb_y; }
        }
        /// <summary>
        /// 操作员部门叠加坐标-X
        /// </summary>
        public int? CZYBM_DJZB_X
        {
            set { _czybm_djzb_x = value; }
            get { return _czybm_djzb_x; }
        }
        /// <summary>
        /// 操作员部门叠加坐标-Y
        /// </summary>
        public int? CZYBM_DJZB_Y
        {
            set { _czybm_djzb_y = value; }
            get { return _czybm_djzb_y; }
        }
        /// <summary>
        /// 旅客证件号码叠加坐标-X
        /// </summary>
        public int? LKZJHM_DJZB_X
        {
            set { _lkzjhm_djzb_x = value; }
            get { return _lkzjhm_djzb_x; }
        }
        /// <summary>
        /// 旅客证件号码叠加坐标-Y
        /// </summary>
        public int? LKZJHM_DJZB_Y
        {
            set { _lkzjhm_djzb_y = value; }
            get { return _lkzjhm_djzb_y; }
        }
        /// <summary>
        /// 旅客姓名叠加坐标-X
        /// </summary>
        public int? LKXM_DJZB_X
        {
            set { _lkxm_djzb_x = value; }
            get { return _lkxm_djzb_x; }
        }
        /// <summary>
        /// 旅客姓名叠加坐标-Y
        /// </summary>
        public int? LKXM_DJZB_Y
        {
            set { _lkxm_djzb_y = value; }
            get { return _lkxm_djzb_y; }
        }
        /// <summary>
        /// 旅客评价信息叠加坐标-X
        /// </summary>
        public int? LKPJXX_DJZB_X
        {
            set { _lkpjxx_djzb_x = value; }
            get { return _lkpjxx_djzb_x; }
        }
        /// <summary>
        /// 旅客评价信息叠加坐标-Y
        /// </summary>
        public int? LKPJXX_DJZB_Y
        {
            set { _lkpjxx_djzb_y = value; }
            get { return _lkpjxx_djzb_y; }
        }
    }
}
