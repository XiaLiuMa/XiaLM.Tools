﻿using System.Data.SqlClient;
using Schedule.Common.SqlHelp;
using Schedule.Common.SqlHelp.Impl;
using System.IO;
using log4net.Config;
using Schedule.Common.Core.Send.MqSend;
using Schedule.Common.log;
using System;
using Isolator.SetCharacter.SetCharacter;
using System.Threading;
using Schedule.Common.Util;
using Schedule.model.common;
using log4net;

namespace SetCharService
{
    public class GlobalService
    {
        /// <summary>
        /// 字符叠加停留时间
        /// </summary>
        public static int djtlsj = 0;

        /// <summary>
        /// 数据库选择标示
        /// </summary>
        public static string dbType = string.Empty;

        /// <summary>
        /// 旅客信息过期时间
        /// </summary>
        public static int lkxxgqsj = 0;

        /// <summary>
        /// 数据库操作对象
        /// </summary>
        public static ISqlOperate SqlOperate;

        public static Mod.Resource1 _Resource1;

        #region //初始化数据库连接
        public static void InitDbConn()
        {
            if (dbType.Equals("Ms"))
            {
                DbConfigRepertory dbconfig = new DbConfigRepertory();
                dbconfig.init();

                GlobalService.InitDbConnMs();
            }
            else if (dbType.Equals("Acc"))
            {
                GlobalService.InitDbConnAcc();
            }
        }

        /// <summary>
        /// 初始化sqlServer数据库连接
        /// </summary>
        public static void InitDbConnMs()
        {
            SqlOperate = DbConfigRepertory.getDafaultSqlOperate();
        }

        /// <summary>
        /// 初始化Access数据库连接
        /// </summary>
        public static void InitDbConnAcc()
        {
            string conStr = string.Format(@"Provider=Microsoft.Jet.OleDb.4.0;Data Source={0};Jet OleDb:DataBase Password=max123456;", SetCharService_BaseDataConfig.baseDataConfig.IsolatorDbStr);

            SqlOperate = new SqliteSqlOperate();
            SqlOperate.DbConStr = conStr;
        }
        #endregion

        /// <summary>
        /// 初始化
        /// </summary>
        public static void Init()
        {
            try
            {
                _Resource1 = SerializationHelper.Load<Mod.Resource1>(AppDomain.CurrentDomain.BaseDirectory + @"Config/Resource1.xml");

                string path = @"Log4Net.config";
                var repository = LogManager.CreateRepository("NETCoreRepository");
                XmlConfigurator.Configure(repository, new FileInfo(path));
                LogHelp.Info("启动" + _Resource1.StrName + "...........");
                ThreadPool.SetMaxThreads(50, 80);
                djtlsj = Convert.ToInt32(SetCharService_BaseDataConfig.baseDataConfig.Tlsj);
                IsolatorUtil.StartDataBlock();
                dbType = SetCharService_BaseDataConfig.baseDataConfig.DbType;

                lkxxgqsj = Convert.ToInt32(SetCharService_BaseDataConfig.baseDataConfig.Lkxxgqsj);
                GlobalSetCharacter.StartClearLKXX();
                InitDbConn();

                SetCharacterFactory.IsTgtp = SetCharService_BaseDataConfig.baseDataConfig.IsTgtp == "true" ? true : false;
                //SetCharacterFactory.Zplj = SetCharService_BaseDataConfig.baseDataConfig.Zplj;

                RabbitMqManage.Init();
                RabbitMqManage.ConsumeRegist();

                LogHelp.Info(_Resource1.StrName + "初始化成功................");
            }
            catch (System.Exception ex)
            {
                LogHelp.Error(typeof(GlobalService), ex);
            }
        }

        /// <summary>
        /// 释放系统
        /// </summary>
        public static void UnInit()
        {
            LogHelp.Info("停止" + _Resource1.StrName + "...........");
            try
            {
                RabbitMqManage.Stop();
                GlobalSetCharacter.ClearAll();
            }
            catch (Exception ex)
            {
                LogHelp.Error(typeof(GlobalService), ex);
            }
            LogHelp.Info(_Resource1.StrName + "停止成功................");
        }
    }
}
