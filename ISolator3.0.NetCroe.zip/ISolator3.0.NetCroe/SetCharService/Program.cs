﻿using Schedule.Common.log;
using System;
using System.Runtime.InteropServices;
using System.Threading;

namespace SetCharService
{
    public delegate bool ConsoleCtrlDelegate(int dwCtrlType);
    class Program
    {
        [DllImport("kernel32.dll")]
        private static extern bool SetConsoleCtrlHandler(ConsoleCtrlDelegate HandlerRoutine,bool Add);

        //当用户关闭Console时，系统会发送次消息
        private const int CTRL_CLOSE_EVENT = 2;

        static void Main(string[] args)
        {
#if DEBUG
            bool flag = false;
            Mutex mutex = new Mutex(true, "SetCharService", out flag);
            if (flag)
            {
                GlobalService.Init();
                ConsoleCtrlDelegate newDelegate = new ConsoleCtrlDelegate(HandlerRoutine);
                bool bRet = SetConsoleCtrlHandler(newDelegate, true);
                Console.ReadLine();
            }
            else
            {
                LogHelp.Info(GlobalService._Resource1.StrName + "已经启动...........");
                System.Threading.Thread.Sleep(5000);//线程挂起5秒钟  
                Environment.Exit(1);//退出程序  
            }
#else
  ServiceBase[] ServicesToRun;
            ServicesToRun = new ServiceBase[] 
            { 
                new Service1() 
            };
            ServiceBase.Run(ServicesToRun);
#endif
        }

        /// <summary>
        /// 处理消息的事件
        /// </summary>
        /// <param name="CtrlType"></param>
        /// <returns></returns>
        private static bool HandlerRoutine(int CtrlType)
        {
            switch (CtrlType)
            {
                case CTRL_CLOSE_EVENT:       //用户要关闭Console了
                    GlobalService.UnInit();
                    break;
            }
            return false;
        }
    }
}
