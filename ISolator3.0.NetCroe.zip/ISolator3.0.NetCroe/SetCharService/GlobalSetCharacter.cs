﻿using System;
using System.Collections.Generic;
using System.Threading;
using Isolator.SetCharacter.Mod;
using Isolator.SetCharacter.SetCharacter;
using log4net;
using Newtonsoft.Json;
using Schedule.Common.SqlHelp;
using SetCharService.Mod;
using Schedule.Common.Util;

namespace SetCharService
{
    public class GlobalSetCharacter
    {
        static ILog logger = LogManager.GetLogger(typeof(GlobalSetCharacter));
        /// <summary>
        /// 网络字符叠加对应关系缓存
        /// </summary>
        private static List<WLZFDJDYGX> lstWLZfdj = null;

        /// <summary>
        /// 模拟字符叠加对应关系缓存
        /// </summary>
        private static List<MNZFDJDYGX> lstMNZfdj = null;

        private readonly static object locker = new object();

        public static System.Collections.Concurrent.ConcurrentQueue<ClearLKXXstl> _ConcurrentQueueClearLKXXstl = new System.Collections.Concurrent.ConcurrentQueue<ClearLKXXstl>();


        /// <summary>
        /// 根据通道号获取网络字符叠加对应关系
        /// </summary>
        /// <param name="tdh"></param>
        /// <returns></returns>
        public static List<WLZFDJDYGX> GetWLZfdjqygx(string tdh)
        {
            if (lstWLZfdj == null)
            {
                lock (locker)
                {
                    if (lstWLZfdj == null)
                    {
                        lstWLZfdj = new List<WLZFDJDYGX>();
                        string strSql = string.Empty;
                        if(GlobalService.dbType.Equals("Ms"))
                        {
                            strSql = " select * from View_QWSJ_ZFDJ_WLSBDYGX";
                        }
                        else if (GlobalService.dbType.Equals("Acc"))
                        {
                            strSql = @"SELECT   c.mstdh AS TDH, b.czydm_djzb_x, b.czydm_djzb_y, b.czyxm_djzb_x, b.czyxm_djzb_y, b.czybm_djzb_x, 
                                        b.czybm_djzb_y, b.lkzjhm_djzb_x, b.lkzjhm_djzb_y, b.lkxm_djzb_x, b.lkxm_djzb_y, b.lkpjxx_djzb_x, b.lkpjxx_djzb_y, 
                                        b.lkgj_djzb_x, b.lkgj_djzb_y, b.jtgj_djzb_x, b.jtgj_djzb_y, a.SBXH, a.IPADDRESS, a.port, a.channel, a.USER_NAME, 
                                        a.USER_PWD
                                        FROM      ((QWSJ_T_ZFDJ_WLSB a INNER JOIN
                                        QWSJ_T_ZFDJ_ZBXX b ON a.ZBID = b.ZBID) INNER JOIN
                                        QWSJ_T_ZFDJ_TDSBDYGX c ON a.WLSBID = c.SBID)";
                        }
                        List<Dictionary<string, object>> listDic = SqlUtil.Select(strSql, GlobalService.SqlOperate);
                        try
                        {
                            for (int i = 0; i < listDic.Count; i++)
                            {
                                View_QWSJ_ZFDJ_WLSBDYGX zfdjdygx = JsonConvert.DeserializeObject<View_QWSJ_ZFDJ_WLSBDYGX>(JsonConvert.SerializeObject(listDic[i]));
                                WLZFDJDYGX wl = new WLZFDJDYGX();
                                wl.WLSB = new WLSB();
                                wl.ZBXX = new ZBXX();
                                wl.WLSB.TDH = zfdjdygx.TDH;
                                wl.ZBXX.CZYBM_DJZB_X = zfdjdygx.CZYBM_DJZB_X;
                                wl.ZBXX.CZYBM_DJZB_Y = zfdjdygx.CZYBM_DJZB_Y;

                                wl.ZBXX.CZYDM_DJZB_X = zfdjdygx.CZYDM_DJZB_X;
                                wl.ZBXX.CZYDM_DJZB_Y = zfdjdygx.CZYDM_DJZB_Y;

                                wl.ZBXX.CZYXM_DJZB_X = zfdjdygx.CZYXM_DJZB_X;
                                wl.ZBXX.CZYXM_DJZB_Y = zfdjdygx.CZYXM_DJZB_Y;

                                wl.ZBXX.LKZJHM_DJZB_X = zfdjdygx.LKZJHM_DJZB_X;
                                wl.ZBXX.LKZJHM_DJZB_Y = zfdjdygx.LKZJHM_DJZB_Y;

                                wl.ZBXX.LKXM_DJZB_X = zfdjdygx.LKXM_DJZB_X;
                                wl.ZBXX.LKXM_DJZB_Y = zfdjdygx.LKXM_DJZB_Y;

                                wl.ZBXX.LKPJXX_DJZB_X = zfdjdygx.LKPJXX_DJZB_X;
                                wl.ZBXX.LKPJXX_DJZB_Y = zfdjdygx.LKPJXX_DJZB_Y;

                                wl.ZBXX.LKGJ_DJZB_X = zfdjdygx.LKGJ_DJZB_X;
                                wl.ZBXX.LKGJ_DJZB_Y = zfdjdygx.LKGJ_DJZB_Y;

                                wl.ZBXX.JTGJ_DJZB_X = zfdjdygx.JTGJ_DJZB_X;
                                wl.ZBXX.JTGJ_DJZB_Y = zfdjdygx.JTGJ_DJZB_Y;

                                wl.WLSB.SBXH = zfdjdygx.SBXH;
                                wl.WLSB.IPADDRESS = zfdjdygx.IPADDRESS;
                                wl.WLSB.PORT = zfdjdygx.PORT;
                                wl.WLSB.CHANNEL = zfdjdygx.CHANNEL;
                                wl.WLSB.USER_NAME = zfdjdygx.USER_NAME;
                                wl.WLSB.USER_PWD = zfdjdygx.USER_PWD;

                                lstWLZfdj.Add(wl);
                            }

                        }
                        catch (System.Exception ex)
                        {
                            logger.Error(ex);
                        }

                    }
                }
            }

            return lstWLZfdj.FindAll(a => a.WLSB.TDH.Equals(tdh));
        }

        /// <summary>
        /// 根据通道号获取模拟字符叠加对应关系
        /// </summary>
        /// <param name="tdh"></param>
        /// <returns></returns>
        public static List<MNZFDJDYGX> GetMNZfdjqygx(string tdh)
        {
            if (lstMNZfdj == null)
            {
                lock (locker)
                {
                    if (lstMNZfdj == null)
                    {
                        lstMNZfdj = new List<MNZFDJDYGX>();

                        string strSql = string.Empty;
                        if (GlobalService.dbType.Equals("Ms"))
                        {
                            strSql = " select * from View_QWSJ_ZFDJ_MNSBDYGX";
                        }
                        else if (GlobalService.dbType.Equals("Acc"))
                        {
                            strSql = @"SELECT   QWSJ_T_ZFDJ_CKSB.PORT_NAME, QWSJ_T_ZFDJ_CKSB.baudRate, QWSJ_T_ZFDJ_CKSB.DATABITS, 
                QWSJ_T_ZFDJ_CKSB.parity, QWSJ_T_ZFDJ_CKSB.STOPBITS, QWSJ_T_ZFDJ_CKSB.handShake, 
                QWSJ_T_ZFDJ_TDSBDYGX.mstdh, QWSJ_T_ZFDJ_TDSBDYGX.SBLX, QWSJ_T_ZFDJ_MNSB.JKTDH, 
                QWSJ_T_ZFDJ_ZBXX.czydm_djzb_x, QWSJ_T_ZFDJ_ZBXX.czydm_djzb_y, QWSJ_T_ZFDJ_ZBXX.czyxm_djzb_x, 
                QWSJ_T_ZFDJ_ZBXX.czyxm_djzb_y, QWSJ_T_ZFDJ_ZBXX.czybm_djzb_x, QWSJ_T_ZFDJ_ZBXX.czybm_djzb_y, 
                QWSJ_T_ZFDJ_ZBXX.lkzjhm_djzb_x, QWSJ_T_ZFDJ_ZBXX.lkzjhm_djzb_y, QWSJ_T_ZFDJ_ZBXX.lkxm_djzb_x, 
                QWSJ_T_ZFDJ_ZBXX.lkxm_djzb_y, QWSJ_T_ZFDJ_ZBXX.lkpjxx_djzb_x, QWSJ_T_ZFDJ_ZBXX.lkpjxx_djzb_y, 
                QWSJ_T_ZFDJ_CKSB.CKSBID
FROM      (((QWSJ_T_ZFDJ_TDSBDYGX INNER JOIN
                QWSJ_T_ZFDJ_MNSB ON QWSJ_T_ZFDJ_TDSBDYGX.SBID = QWSJ_T_ZFDJ_MNSB.MNSBID) INNER JOIN
                QWSJ_T_ZFDJ_ZBXX ON QWSJ_T_ZFDJ_MNSB.ZBID = QWSJ_T_ZFDJ_ZBXX.ZBID) INNER JOIN
                QWSJ_T_ZFDJ_CKSB ON QWSJ_T_ZFDJ_MNSB.CKSBID = QWSJ_T_ZFDJ_CKSB.CKSBID)";
                        }
                        List<Dictionary<string, object>> listDic = SqlUtil.Select(strSql, GlobalService.SqlOperate);
                        listDic.ForEach(d =>
                        {
                            View_QWSJ_ZFDJ_MNSBDYGX zfdjdygx = JsonConvert.DeserializeObject<View_QWSJ_ZFDJ_MNSBDYGX>(JsonConvert.SerializeObject(d));
                            MNZFDJDYGX mn = new MNZFDJDYGX();

                            mn.ZBXX.CZYBM_DJZB_X = zfdjdygx.CZYBM_DJZB_X;
                            mn.ZBXX.CZYBM_DJZB_Y = zfdjdygx.CZYBM_DJZB_Y;

                            mn.ZBXX.CZYDM_DJZB_X = zfdjdygx.CZYDM_DJZB_X;
                            mn.ZBXX.CZYDM_DJZB_Y = zfdjdygx.CZYDM_DJZB_Y;

                            mn.ZBXX.CZYXM_DJZB_X = zfdjdygx.CZYXM_DJZB_X;
                            mn.ZBXX.CZYXM_DJZB_Y = zfdjdygx.CZYXM_DJZB_Y;

                            mn.ZBXX.LKZJHM_DJZB_X = zfdjdygx.LKZJHM_DJZB_X;
                            mn.ZBXX.LKZJHM_DJZB_Y = zfdjdygx.LKZJHM_DJZB_Y;

                            mn.ZBXX.LKXM_DJZB_X = zfdjdygx.LKXM_DJZB_X;
                            mn.ZBXX.LKXM_DJZB_Y = zfdjdygx.LKXM_DJZB_Y;

                            mn.ZBXX.LKPJXX_DJZB_X = zfdjdygx.LKPJXX_DJZB_X;
                            mn.ZBXX.LKPJXX_DJZB_Y = zfdjdygx.LKPJXX_DJZB_Y;

                            mn.MNSB.BAUDRATE = zfdjdygx.BAUDRATE;
                            mn.MNSB.DATABITS = zfdjdygx.DATABITS;
                            mn.MNSB.HANDSHAKE = zfdjdygx.HANDSHAKE;
                            mn.MNSB.JKTDH = zfdjdygx.JKTDH;
                            mn.MNSB.PARITY = zfdjdygx.PARITY;
                            mn.MNSB.PORT_NAME = zfdjdygx.PORT_NAME;

                            lstMNZfdj.Add(mn);
                        });
                    }
                }
            }
            return lstMNZfdj.FindAll(a => a.MNSB.JKTDH.Equals(tdh));
        }

        public static void StartClearLKXX()
        {
            System.Threading.Thread th = new Thread(() =>
            {
                while (true)
                {
                    try
                    {
                        ClearLKXXstl _ClearLKXXstl = new ClearLKXXstl();
                        if (_ConcurrentQueueClearLKXXstl.TryDequeue(out _ClearLKXXstl))
                        {
                            double eventDuration = DateTime.Now.CompareCalculate(_ClearLKXXstl.RZSJ);//

                            if (eventDuration > GlobalService.djtlsj)
                            {
                                WLSetCharacter iSetCharacter = SetCharacterFactory.CreatWLSetCharacter(_ClearLKXXstl._WLZFDJDYGX);

                                if (iSetCharacter != null)
                                {
                                    iSetCharacter.ClearLKXX(_ClearLKXXstl.zjhm);
                                }
                            }
                            else
                            {
                                _ConcurrentQueueClearLKXXstl.Enqueue(_ClearLKXXstl);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        logger.Error(ex);
                    }

                    Thread.Sleep(1000);
                }
            });

            th.Start();
        }

        /// <summary>
        /// 清空所有通道字符叠加
        /// </summary>
        /// <returns></returns>
        public static bool ClearAll()
        {
            logger.Info("清除字符叠加");
            bool re = SetCharacterFactory.ClearALLWL();
            logger.Info("字符叠加清除成功");
            return re;
        }
    }

    public class ClearLKXXstl
    {
        public WLZFDJDYGX _WLZFDJDYGX { get; set; }

        public DateTime RZSJ { get; set; }

        public string zjhm { get; set; }
    }
}
