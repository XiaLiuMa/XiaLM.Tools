﻿using Microsoft.Extensions.Caching.Memory;
using Schedule.model.common;
using System;
using System.Collections.Generic;

namespace SetCharService
{
    /// <summary>
    /// DataEngine基础数据配置
    /// </summary>
    public class SetCharService_BaseDataConfig
    {
        //private static MemoryCache _ConfigCache = new MemoryCache("BaseData");
        private static MemoryCache cache = new MemoryCache(new MemoryCacheOptions());  //UNDONE:（不确定是否可行）
        private static readonly string baseDataConfigPath = @"Config\BaseData.xml";

        public static BaseData baseDataConfig
        {
            get
            {
                //var mqconfig = (BaseData)_ConfigCache.Get("BaseData");
                var mqconfig = (BaseData)cache.Get("BaseData");
                if (mqconfig == null)
                {
                    mqconfig = SerializationHelper.Load<BaseData>(AppDomain.CurrentDomain.BaseDirectory + baseDataConfigPath);

                    //var policy = new CacheItemPolicy();
                    //policy.ChangeMonitors.Add(new HostFileChangeMonitor(new List<string>() { AppDomain.CurrentDomain.BaseDirectory + baseDataConfigPath }));
                    //_ConfigCache.Add("BaseData", mqconfig, policy);

                    cache.Set("BaseData", mqconfig, new MemoryCacheEntryOptions
                    {
                        SlidingExpiration = TimeSpan.FromMinutes(1)
                    });
                }
                return mqconfig;
            }
        }
    }

    public class BaseData
    {
        /// <summary>
        /// 字符叠加停留时间（秒）
        /// </summary>
        public string Tlsj { get; set; }

        /// <summary>
        /// 旅客抓拍照片路径
        /// </summary>
        public string Zplj { get; set; }

        /// <summary>
        /// 是否抓拍图片
        /// </summary>
        public string IsTgtp { get; set; }

        /// <summary>
        /// Access数据库绝对路径
        /// </summary>
        public string IsolatorDbStr { get; set; }

        /// <summary>
        /// 数据库标示（value="Ms"为sqlservler ,value="Acc"为Access）
        /// </summary>
        public string DbType { get; set; }

        /// <summary>
        /// 旅客信息过期时间(秒)
        /// </summary>
        public string Lkxxgqsj { get; set; }
    }
}
