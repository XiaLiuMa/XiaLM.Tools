﻿using Isolator.SetCharacter.Mod;
using Isolator.SetCharacter.SetCharacter;
using log4net;
using Newtonsoft.Json;
using Schedule.Common.Extention;
using Schedule.Common.log;
using Schedule.Common.Service;
using Schedule.Common.Util;
using Schedule.model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;

namespace SetCharService.MQReceive
{
    /// <summary>
    /// 字符叠加监听处理
    /// </summary>
    public class ZfdjReceive : IReceiveListener
    {
        public ZfdjReceive()
        {
            QuTdssxx = Queue.Synchronized(QuTdssxx);
        }

        private static ILog log = LogManager.GetLogger(typeof(ZfdjReceive));

        /// <summary>
        /// 通道实时信息命令队列
        /// </summary>
        public static Queue QuTdssxx = new Queue();

        /// <summary>
        /// 通道实时信息命令队列最大长度
        /// </summary>
        public const int QuTdssxxMaxCount = 1000;

        public void ReceiveNotified(IsolatorData data)
        {
            try
            {
#if DEBUG
                var mydata = System.Text.Encoding.UTF8.GetString(data.Value);
                LogHelp.Info(string.Format(DateTime.Now.ToString(CalculateUtil.FormatDt) + ",已接收到数据：jobName={0},cmd={1},SendTime={2},mydata={3}", data.JobName, data.Cmd, data.SendTime, mydata)); 
#endif
                if (data.Cmd == 01 || data.Cmd == 02)
                {
                    InvokeResole(data);
                }
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
        }

        private void InvokeResole(IsolatorData data)
        {
            string json = Encoding.UTF8.GetString(data.Value);

            if (json.StartsWith("["))
            {
                List<Dictionary<string, object>> lstZfdjreceive = JsonConvert.DeserializeObject<List<Dictionary<string, object>>>(json);
                if (lstZfdjreceive == null || lstZfdjreceive.Count == 0) return;

                Parallel.ForEach(lstZfdjreceive, r =>
                {
                    Resole(data.Cmd, r);
                });
            }
            else
            {
                Dictionary<string, object> Zfdjreceive = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                Resole(data.Cmd, Zfdjreceive);
            }
        }

        private void Resole(byte cmd, Dictionary<string, object> zfdjreceive)
        {
            if (zfdjreceive == null) return;
            if (zfdjreceive.Count == 0) return;

            string valkey = zfdjreceive["VALKEY"].ToString();
            string tdh = zfdjreceive["TDH"].ToString();

            if (QuTdssxx.Contains(valkey))
            {
                return;
            }
            QuTdssxx.Enqueue(valkey);

            #region 获取叠加配置相关信息
            List<WLZFDJDYGX> qwsj_wlzfdjList = new List<WLZFDJDYGX>();
            qwsj_wlzfdjList = GlobalSetCharacter.GetWLZfdjqygx(tdh);

            List<MNZFDJDYGX> qwsj_mnzfdjList = new List<MNZFDJDYGX>();
            qwsj_mnzfdjList = GlobalSetCharacter.GetMNZfdjqygx(tdh);
            #endregion

            #region CMD:01 上台、验放旅客
            if (cmd == 01)
            {
                #region 获取需要叠加的相关信息存放在DjMessage结构体中

                tdh = zfdjreceive["TDH"].ToString();
                DjMessage djmsg = new DjMessage();
                djmsg.Czydm = zfdjreceive["CZYDM"].ToString(); ;
                djmsg.Czyxm = zfdjreceive["CZYXM"].ToString();
                djmsg.Czybm = zfdjreceive["BMMC"].ToString();

                //todo 添加航班号与旅客国籍
                djmsg.Jtgj = zfdjreceive["JTGJBS"].ToString();
                djmsg.Lkgj = zfdjreceive["GJDQDM"].ToString();
                string fssj = zfdjreceive["CRRQSJ"].ToString();

                if (fssj == "0")
                {
                    djmsg.Lkzjhm = "";
                    djmsg.Lkxm = "";
                    djmsg.Lkpjxx = "";
                    djmsg.Jtgj = "";
                    djmsg.Lkgj = "";
                }
                else
                {
                    DateTime DateTimeFSSJ = fssj.FormatFssj(null);

                    double eventDuration = DateTimeFSSJ.CompareCalculate(DateTime.Now);//

                    if (eventDuration < GlobalService.lkxxgqsj)
                    {
                        djmsg.Lkzjhm = zfdjreceive["ZJHM"].ToString();
                        djmsg.Lkxm = zfdjreceive["XM"].ToString();
                        djmsg.CSRQ = zfdjreceive["CSRQ"].ToString();
                        djmsg.WYBS = zfdjreceive["WYBS"].ToString();
                        switch (zfdjreceive["PJNR"].ToString())
                        {
                            case "1": djmsg.Lkpjxx = "非常满意"; break;
                            case "2": djmsg.Lkpjxx = "满意"; break;
                            case "3": djmsg.Lkpjxx = "时间太长"; break;
                            case "4": djmsg.Lkpjxx = "态度不好"; break;
                            default: djmsg.Lkpjxx = ""; break;
                        }
                    }
                    else
                    {
                        djmsg.Lkzjhm = "";
                        djmsg.Lkxm = "";
                        djmsg.Lkpjxx = "";
                        djmsg.Jtgj = "";
                        djmsg.Lkgj = "";
                    }
                }
                #endregion

                #region 将信息叠加到相关网络设备上
                if (qwsj_wlzfdjList != null)
                {
                    foreach (WLZFDJDYGX qwsj_zfdj in qwsj_wlzfdjList)
                    {
                        WLSetCharacter iSetCharacter = SetCharacterFactory.CreatWLSetCharacter(qwsj_zfdj);

                        if (iSetCharacter != null)
                        {
                            //Thread thr = new Thread(new ThreadStart(delegate()
                            //{
                                iSetCharacter.SetCharacter(djmsg);
                            //}));
                            //thr.Priority = ThreadPriority.Highest;
                            //thr.IsBackground = true;
                            //thr.Start();

                            if (string.IsNullOrEmpty(djmsg.Lkpjxx) && valkey.Length > 40)
                            {
                                ClearLKXXstl _ClearLKXXstl = new ClearLKXXstl();
                                _ClearLKXXstl._WLZFDJDYGX = qwsj_zfdj;
                                _ClearLKXXstl.RZSJ = DateTime.Now;
                                _ClearLKXXstl.zjhm = djmsg.Lkzjhm;
                                GlobalSetCharacter._ConcurrentQueueClearLKXXstl.Enqueue(_ClearLKXXstl);
                            }
                        }
                    }
                }
                #endregion

                #region 将信息叠加到相关模拟设备上
                if (qwsj_mnzfdjList != null)
                {
                    foreach (MNZFDJDYGX qwsj_zfdj in qwsj_mnzfdjList)
                    {
                        MNSetCharacter iSetCharacter;

                        iSetCharacter = SetCharacterFactory.CreatMNSetCharacter(qwsj_zfdj);
                        if (iSetCharacter != null)
                        {
                            Thread thr = new Thread(new ThreadStart(delegate()
                            {
                                iSetCharacter.SetCharacter(djmsg);
                            }));
                            thr.Priority = ThreadPriority.Highest;
                            thr.IsBackground = true;
                            thr.Start();

                            //if (string.IsNullOrEmpty(djmsg.Lkpjxx) && valkey.Length > 40)
                            //{
                            //    ClearLKXXstl _ClearLKXXstl = new ClearLKXXstl();
                            //    _ClearLKXXstl._WLZFDJDYGX = qwsj_zfdj;
                            //    _ClearLKXXstl.RZSJ = DateTime.Now;
                            //    _ClearLKXXstl.zjhm = djmsg.Lkzjhm;
                            //    GlobalSetCharacter._ConcurrentQueueClearLKXXstl.Enqueue(_ClearLKXXstl);
                            //}
                        }
                    }
                }
                #endregion
            }
            #endregion

            #region CMD:02 下台
            else if (cmd == 02)
            {
                #region 清除相关网络设备上面的所有信息
                if (qwsj_wlzfdjList != null)
                {
                    foreach (WLZFDJDYGX qwsj_zfdjxt in qwsj_wlzfdjList)
                    {
                        WLSetCharacter iSetCharacter = SetCharacterFactory.CreatWLSetCharacter(qwsj_zfdjxt);

                        if (iSetCharacter != null)
                        {
                            ThreadPool.QueueUserWorkItem(new WaitCallback(delegate
                            {
                                iSetCharacter.ClearAll();
                            }));
                        }
                    }
                }
                #endregion

                #region 清除相关模拟设备上面的所有信息
                if (qwsj_mnzfdjList != null)
                {
                    foreach (MNZFDJDYGX qwsj_zfdjxt in qwsj_mnzfdjList)
                    {
                        MNSetCharacter iSetCharacter;

                        iSetCharacter = SetCharacterFactory.CreatMNSetCharacter(qwsj_zfdjxt);
                        if (iSetCharacter != null)
                        {
                            ThreadPool.QueueUserWorkItem(new WaitCallback(delegate
                            {
                                iSetCharacter.ClearAll();
                            }));
                        }
                    }
                }
                #endregion
            }
            #endregion

            if (QuTdssxx.Count > QuTdssxxMaxCount)
            {
                QuTdssxx.Dequeue();
            }
        }

        private ActionBlock<IsolatorData> _Data_ActionBlock;

        public static CancellationTokenSource _CancellationTokenSourceData = new CancellationTokenSource();

        public ActionBlock<IsolatorData> Data_ActionBlock
        {
            get
            {
                _Data_ActionBlock = new ActionBlock<IsolatorData>((data) =>
                {
                    try
                    {
#if DEBUG
                        var mydata = System.Text.Encoding.UTF8.GetString(data.Value);
                        LogHelp.Info(string.Format(DateTime.Now.ToString(CalculateUtil.FormatDt) + ",已接收到数据：jobName={0},cmd={1},SendTime={2},mydata={3}", data.JobName, data.Cmd, data.SendTime, mydata));
#endif
                        if (data.Cmd == 01 || data.Cmd == 02)
                        {
                            InvokeResole(data);
                        }
                    }
                    catch (Exception ex)
                    {
                        log.Error(ex);
                    }
                }, new ExecutionDataflowBlockOptions() { MaxDegreeOfParallelism = 3, BoundedCapacity = 100, CancellationToken = _CancellationTokenSourceData.Token });
                return _Data_ActionBlock;
            }
            set
            {
                _Data_ActionBlock = value;
            }
        }
    }
}
