﻿using System;
using System.Collections.Generic;
using System.Text;
using log4net;
using Newtonsoft.Json;
using Schedule.Common.Data;
using Schedule.Common.Extention;
using Schedule.Common.Service;
using Schedule.Common.Util;
using Schedule.model;
using Schedule.Common.log;
using System.Threading.Tasks.Dataflow;
using System.Threading;

namespace SetCharService.MQReceive
{
    /// <summary>
    /// 时间同步接收处理
    /// </summary>
    public class SjtbReceive : IReceiveListener
    {
        private static ILog log = LogManager.GetLogger(typeof(SjtbReceive));

        public void ReceiveNotified(IsolatorData data)
        {
            var mydata = System.Text.Encoding.UTF8.GetString(data.Value);
            LogHelp.Info(string.Format("TDSSXXReceive已接收到数据：jobName={0},cmd={1},SendTime={2},mydata={3}", data.JobName, data.Cmd, data.SendTime, mydata));

            switch (data.Cmd)
            {
                case 88:
                    InvokeResole(data);
                    break;
                default:
                    break;
            }
        }

        private void InvokeResole(IsolatorData data)
        {
            try
            {
                string json = Encoding.UTF8.GetString(data.Value);

                List<Dictionary<string, object>> dicSysTime = JsonConvert.DeserializeObject<List<Dictionary<string, object>>>(json);

                DateTime dtReceive = string.IsNullOrEmpty(data.ReceiveTime) ? DateTime.Now : data.ReceiveTime.FormatFssj(null);
                DateTime dt = Convert.ToDateTime(dicSysTime[0]["SYSDATE"]);
                DateTime tbdt = dt.Add(DateTime.Now.Subtract(dtReceive));
                SetLocalTime(tbdt);
            }
            catch (Exception ex)
            {
                LogHelp.Error(ex);
            }
        }

        #region 设置计算机时间
        /// <summary>
        /// 设置计算机时间
        /// </summary>
        private void SetLocalTime(DateTime TimeNow)
        {
            try
            {
                SystemTime st = new SystemTime
                {
                    vYear = (ushort)(Convert.ToDateTime(TimeNow)).Year,
                    vMonth = (ushort)(Convert.ToDateTime(TimeNow)).Month,
                    vDay = (ushort)(Convert.ToDateTime(TimeNow)).Day,
                    vHour = (ushort)(Convert.ToDateTime(TimeNow)).Hour,
                    vMinute = (ushort)(Convert.ToDateTime(TimeNow)).Minute,
                    vSecond = (ushort)((Convert.ToDateTime(TimeNow)).Second)
                };

                Win32Util.SetLocalTime(ref st);
            }
            catch (Exception ex)
            {
                log.Error(ex.Message);
            }
        }
        #endregion


        private ActionBlock<IsolatorData> _Data_ActionBlock;

        public static CancellationTokenSource _CancellationTokenSourceData = new CancellationTokenSource();

        public ActionBlock<IsolatorData> Data_ActionBlock
        {
            get
            {
                _Data_ActionBlock = new ActionBlock<IsolatorData>((data) =>
                {
                    switch (data.Cmd)
                    {
                        case 88:
                            InvokeResole(data);
                            break;
                        default:
                            break;
                    }
                }, new ExecutionDataflowBlockOptions() { MaxDegreeOfParallelism = 3, BoundedCapacity = 100, CancellationToken = _CancellationTokenSourceData.Token });
                return _Data_ActionBlock;
            }
            set
            {
                _Data_ActionBlock = value;
            }
        }
    }
}
