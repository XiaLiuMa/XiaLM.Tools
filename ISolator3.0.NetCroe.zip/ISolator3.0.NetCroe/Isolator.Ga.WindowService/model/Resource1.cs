﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Isolator.Ga.WindowService.model
{
    public class Resource1
    {
        public string StrName { get; set; }
    }
}
