﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Isolator.Ga.WindowService.model
{
    public class serviceConfig
    {
        public int HttpServerPort { get; set; }
        public serviceConfig()
        {
            HttpServerPort = 9000;
        }
    }
}
