﻿using Isolator.common.Isoltor.MQQueue;
using Isolator.common.Isoltor.SeriaPort;
using log4net.Config;
using Schedule.Common.log;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Isolator.common.IsoltorSeriaPort;
using log4net;
using Schedule.model.common;

namespace Isolator.Ga.WindowService
{
    class Global
    {
        private static IsoltorComManager comManage;
        public static model.Resource1 _Resource1;
        public static void Init()
        {
            try
            {
                _Resource1 = SerializationHelper.Load<model.Resource1>(AppDomain.CurrentDomain.BaseDirectory + @"Config/Resource1.xml");
                var repository = LogManager.CreateRepository("NETCoreRepository");
                string path = AppDomain.CurrentDomain.BaseDirectory + "Log4Net.config";
                XmlConfigurator.Configure(repository,new FileInfo(path));   //UNDONE:（不确定是否可行）
                ThreadPool.SetMaxThreads(50, 80);

                LogHelp.Info("启动" + _Resource1.StrName + "...........");
                MQmanage.StartMqData_ActionBlock();
                MQmanage.Init();
                MQmanage.ConsumeRegist();
                comManage = new IsoltorComManager();
                comManage.StartSerialPortData_ActionBlock();
                comManage.startListen();
                WebApiSeviceState httpserver = new WebApiSeviceState();
                httpserver.Start();
                LogHelp.Info(_Resource1.StrName + "初始化成功................");
                //每隔20s发送存活状态
                Task.Factory.StartNew(async () =>
                {
                    while (true)
                    {
                        Guid id = MqData.GetGuid();
                        var livepackage = DataPackageUtil.CreateAckBackPackage(id, IsotorProtocolCommandEnum.livePack);
                        await IsoltorComManager.context.SerialportDispatch.Send(livepackage.Encode(), id, 16,
                            IsotorProtocolCommandEnum.livePack);
                        MqData.RemoveMsgid(id);
                        Thread.Sleep(20 * 1000);
                    }
                }, TaskCreationOptions.LongRunning);
            }
            catch (Exception ex)
            {
                LogHelp.Error(typeof(Global),ex);
            }
        }

        public async static void UnInit()
        {
            LogHelp.Info("停止" + _Resource1.StrName + "...........");
            try
            {
                MQmanage.stop();
                if (comManage != null)
                {
                    Guid id = MqData.GetGuid();
                    var livepackage = DataPackageUtil.CreateAckBackPackage(id, IsotorProtocolCommandEnum.livePack);
                    await IsoltorComManager.context.SerialportDispatch.Send(livepackage.Encode(), id, 19,
                        IsotorProtocolCommandEnum.Byebye);
                    MqData.RemoveMsgid(id);
                    await Task.Delay(TimeSpan.FromMilliseconds(4000));
                    comManage.Dispose();
                }
            }
            catch (Exception ex)
            {
                LogHelp.Error(typeof(Global),ex);
            }
            LogHelp.Info(_Resource1.StrName + "停止成功................");
        }
    }
}
