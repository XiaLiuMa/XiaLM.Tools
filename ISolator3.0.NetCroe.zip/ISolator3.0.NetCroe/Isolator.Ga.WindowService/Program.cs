﻿using Isolator.common.Isoltor.MQQueue;
using Isolator.common.Isoltor.SeriaPort;
using log4net;
using Schedule.Common.log;
using System;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.ServiceProcess;
using System.Threading;

namespace Isolator.Ga.WindowService
{
    static class Program
    {
        public delegate bool ControlCtrlDelegate(int CtrlType);
        [DllImport("kernel32.dll")]
        private static extern bool SetConsoleCtrlHandler(ControlCtrlDelegate HandlerRoutine, bool Add);
        private static ControlCtrlDelegate cancelHandler = new ControlCtrlDelegate(HandlerRoutine);

        public static bool HandlerRoutine(int CtrlType)
        {
            switch (CtrlType)
            {
                case 0:
                    Global.UnInit(); ; //Ctrl+C关闭
                    break;
                case 2:
                    Global.UnInit();//按控制台关闭按钮关闭
                    break;
            }
            Thread.Sleep(2000);
            return false;

        }

        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        static void Main()
        {
#if DEBUG
            bool flag = false;
            Mutex mutex = new Mutex(true, "Isolator.Ga", out flag);
            if (flag)
            {
                SetConsoleCtrlHandler(cancelHandler, true);
                Global.Init();
                Console.ReadLine();
                Console.WriteLine("正在通知梅沙端,本设备下线");
                Global.UnInit();
                
            }
            else
            {
                LogHelp.Info(Global._Resource1.StrName + "已经启动...........");
                System.Threading.Thread.Sleep(5000);//线程挂起5秒钟  
                Environment.Exit(1);//退出程序  
            }
#else
  ServiceBase[] ServicesToRun;
            ServicesToRun = new ServiceBase[] 
            { 
                new Service1() 
            };
            ServiceBase.Run(ServicesToRun);
#endif

        }
    }
}
