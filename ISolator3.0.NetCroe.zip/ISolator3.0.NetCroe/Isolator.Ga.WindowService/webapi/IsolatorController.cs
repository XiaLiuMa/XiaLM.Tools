﻿using Newtonsoft.Json;
using Schedule.Common.log;
using Schedule.Common.Util;
using Schedule.model;
using System;
using System.Linq;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using Isolator.common.Isoltor.MQQueue;
using Isolator.common.IsoltorSeriaPort;
using Nancy;

namespace Isolator.Ga.WindowService.webapi
{
    public class IsolatorController : NancyModule
    {
        public IsolatorController()
        {
            Post("/SendCmd", p =>
            {
                var isolatorData = (string)Request.Form.isolatorData;
                return SendCmd(isolatorData);
            });
        }

        public HttpResponseMessage SendCmd(string isolatorData)
        {
            bool error = false;
            string msg = string.Empty;
            LogHelp.Info("{0}:已接收配置服务器发送的命令，正在通过隔离器提交至梅沙端");
            try
            {
                Task<IsolatorDataApi> task_data = Task.Factory.StartNew<IsolatorDataApi>(() =>
                {
                    return JsonConvert.DeserializeObject<IsolatorDataApi>(isolatorData);
                });
                IsolatorDataApi dataApi = null;
                if (task_data.Result != null)
                {
                    dataApi = task_data.Result;
                }
                else
                {
                    msg = "隔离器未接收到数据";
                    LogHelp.Info(msg);
                    return Write(new { res = error, msg });
                }

                var jobNamebytes = System.Text.Encoding.Default.GetBytes("cmdtest");

                IsolatorData data = new IsolatorData();
                data.SendTime = DateTime.Now.ToString();
                data.JobName = dataApi.JobName;
                data.Cmd = dataApi.Cmd;
                data.Value = Encoding.UTF8.GetBytes(isolatorData);

                var tdata = SerializeUtil.SerializeObject(data);

                var sendData = new byte[4 + jobNamebytes.Length + tdata.Length];
                System.Buffer.BlockCopy(BitConverter.GetBytes(jobNamebytes.Length), 0, sendData, 0, 4);
                System.Buffer.BlockCopy(jobNamebytes, 0, sendData, 4, jobNamebytes.Length);
                System.Buffer.BlockCopy(tdata, 0, sendData, 4 + jobNamebytes.Length, tdata.Length);

                var guid = MqData.GetGuid();
                var obj = Isolator.common.Isoltor.Context.ApplicationContext.Instance.SerialportDispatch.Send(sendData, guid, 19, IsotorProtocolCommandEnum.SendNoAck);

                MqData.RemoveMsgid(guid);
                if (!obj.Result)
                {
                    msg = "隔离器发送数据失败";
                    LogHelp.Info(msg);

                }
                else
                {
                    LogHelp.Info("隔离器发送数据成功");
                }
            }
            catch (Exception ex)
            {
                LogHelp.Error(ex);
                msg = "隔离器发送数据失败";
            }
            finally
            {

            }
            return Write(new { res = error, msg });
        }

        /// <summary>
        /// 向前台输出
        /// </summary>
        /// <param name="content">输出内容。默认编码UTF-8，媒体类型text/html</param>
        /// <returns>输出上下文</returns>
        public static HttpResponseMessage Write<T>(T t)
        {
            string content = JsonConvert.SerializeObject(t);
            HttpResponseMessage result = new HttpResponseMessage
            {
                Content = new StringContent(content, Encoding.GetEncoding("UTF-8"), "text/html")
            };
            return result;
        }
    }


    [Serializable]
    public class IsolatorDataApi
    {
        // public properties...
        /// <summary>
        /// 命令标识
        /// </summary>
        public byte Cmd { get; set; }
        /// <summary>
        /// 数据对应的任务名称
        /// </summary>
        public string JobName { get; set; }
        /// <summary>
        /// 数据发送时间
        /// </summary>
        public string StarTime { get; set; }

        /// <summary>
        /// 数据接收时间
        /// </summary>
        public string EndTime { get; set; }
        /// <summary>
        /// 同步数据
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// 数据内容
        /// </summary>
        public byte[] Value { get; set; }
    }
}
