﻿using System;
using System.Collections.Generic;
using System.Linq;
using Schedule.Common.log;
using System.Net.NetworkInformation;
using System.Net;
using Microsoft.AspNetCore.Hosting;
using System.IO;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.FileProviders;
using Nancy.Owin;

namespace Isolator.Ga.WindowService
{
    public class HttpServer
    {

        // Fields...

        private string _ServerIp = "http://localhost:8080"; //默认开启本机8080端口
        private int? _serverPort;


        static IDisposable webserver = null;
        static readonly string configPath = @"Config/servicesConfig.xml";
        /// <summary>
        /// http服务监听地址，如：http://localhost:8080
        /// </summary>
        public string ServerIp
        {
            get { return _ServerIp; }
            set
            {
                _ServerIp = value;
            }
        }

        public void start(SeviceState state)
        {
            try
            {
                if (!_serverPort.HasValue)
                    _serverPort = getConfigPort();

                //ServerIp = "http://+:" + _serverPort;
                ServerIp = "http://127.0.0.1:" + _serverPort;

                LogHelp.Info("正在启动http服务，端口号{0}" + _serverPort.Value);
                //if (webserver != null)
                //{
                //    LogHelp.Info("正在重启http服务，端口号{0}" + _serverPort.Value);
                //    state.State = "正在停止服务";
                //    webserver.Dispose();
                //    webserver = WebApp.Start<Startup>(ServerIp);
                //    state.State = "运行中";

                //}
                //else
                //{
                //    webserver = WebApp.Start<Startup>(ServerIp);
                //    state.State = "运行中";
                //}

                var hos = new WebHostBuilder()
                        .UseKestrel()
                        .UseUrls(ServerIp)
                        .UseContentRoot(Directory.GetCurrentDirectory())
                        .UseIISIntegration()
                        .UseStartup<Startup>()
                        .Build();
                hos.Run();  //UNDONE:（不确定是否可行）
                state.State = "运行中";

                LogHelp.Info("http服务启动成功，端口号{0}" + _serverPort.Value);

            }
            catch (Exception ex)
            {

                if (ex.InnerException is System.Net.HttpListenerException)
                {
                    var innerex = ex.InnerException as System.Net.HttpListenerException;
                    int errcode = innerex.ErrorCode;
                    switch (errcode)
                    {
                        case 5:

                            LogHelp.Error("拒绝访问，无法启动http服务，请使用管理员身份运行");
                            break;
                        case 183:
                            LogHelp.Error(string.Format("{0}端口已被占用，无法启动http服务,正在尝试试用其他端口启动", _serverPort.Value));
                            Random rand = new Random(DateTime.Now.Millisecond);

                            int tempPort = 0;
                            do
                            {
                                tempPort = rand.Next(5000, 10000);

                            } while (PortInUse(tempPort));
                            _serverPort = tempPort;
                            saveConfig();
                            start(state);
                            break;
                        default:
                            LogHelp.Error(ex);
                            break;
                    }
                    state.State = "启动失败";
                }
                else
                {
                    state.State = "启动失败";
                    LogHelp.Error(ex);
                }
            }

        }

        private void saveConfig()
        {
            var obj = Schedule.model.common.SerializationHelper.Load<model.serviceConfig>(configPath);
            obj.HttpServerPort = _serverPort.Value;
            Schedule.model.common.SerializationHelper.Save(obj, configPath);
        }

        /// <summary>
        /// 获取端口
        /// </summary>
        /// <returns></returns>
        private int getConfigPort()
        {

            return Schedule.model.common.SerializationHelper.Load<model.serviceConfig>(configPath).HttpServerPort;
        }

        public static bool PortInUse(int port)
        {
            IPGlobalProperties ipProperties = IPGlobalProperties.GetIPGlobalProperties();
            IPEndPoint[] ipEndPoints = ipProperties.GetActiveTcpListeners();
            return ipEndPoints.Any(c => c.Port == port);
        }


        public class Startup
        {
            //// This code configures Web API. The Startup class is specified as a type
            //// parameter in the WebApp.Start method.
            //public void Configuration(IAppBuilder appBuilder)
            //{

            //    HttpConfiguration config = new HttpConfiguration();
            //    WebApiConfig.Register(config);

            //    appBuilder.UseCors(CorsOptions.AllowAll);
            //    appBuilder.UseWebApi(config);
            //}


            /// <summary>
            /// 此方法由运行时调用。使用此方法配置HTTP请求管道
            /// </summary>
            /// <param name="app"></param>
            public void Configure(IApplicationBuilder app)
            {
                app.UseStaticFiles(new StaticFileOptions()
                {
                    FileProvider = new PhysicalFileProvider(Directory.GetCurrentDirectory())
                });//使用静态文件
                app.UseOwin(x => x.UseNancy());
            }
        }
    }

    //public static class WebApiConfig
    //{
    //    public static void Register(System.Web.Http.HttpConfiguration config)
    //    {
    //        //注册路由
    //        config.Routes.MapHttpRoute(
    //      name: "DefaultApi1",
    //      routeTemplate: "api/{controller}/{action}/{id}",
    //      defaults: new { id = System.Web.Http.RouteParameter.Optional }
    //  );


    //        config.Routes.MapHttpRoute(
    //            name: "DefaultApi",
    //            routeTemplate: "api/{controller}/{id}",
    //            defaults: new { id = RouteParameter.Optional }
    //        );
    //        //只允许输出为json字符串方式
    //        var appXmlType = config.Formatters.XmlFormatter.SupportedMediaTypes.FirstOrDefault
    //        (t => t.MediaType == "application/xml");
    //        config.Formatters.XmlFormatter.SupportedMediaTypes.Remove(appXmlType);
    //    }
    //}
}
