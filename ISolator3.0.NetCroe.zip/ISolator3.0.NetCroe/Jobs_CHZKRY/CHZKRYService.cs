﻿using Schedule.Engine.Core.Service.Quarz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* ==============================
*
* 作者: 胡军会
* 创建时间：2018-06-20 13:59:35
* 文件名称：CHZKRYService
* 版本：V1.0.1
* 修改时间:
* 修改人：
* 修改备注：
* ===============================
*/
namespace Jobs_CHZKRY
{
    public class CHZKRYService : AbstractScheduleService
    {
        public override string ServiceName
        {
            get { return "CHZKRY"; }
        }

        public override string ClassNote()
        {
            return "查获在控人员调度服务";
        }

        public override Type GetJobType()
        {
            return typeof(CHZKRYJobs);
        }
    }
}
