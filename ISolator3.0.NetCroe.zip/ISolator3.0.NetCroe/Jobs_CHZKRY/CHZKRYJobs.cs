﻿using Jobs_Common;
using Quartz;
using Schedule.Common.SqlHelp;
using Schedule.Common.Util;
using Schedule.Engine.Core.Service.Quarz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* ==============================
*
* 作者: 胡军会
* 创建时间：2018-06-20 13:59:56
* 文件名称：CHZKRYJobs
* 版本：V1.0.1
* 修改时间:
* 修改人：
* 修改备注：
* ===============================
*/
namespace Jobs_CHZKRY
{
    [PersistJobDataAfterExecution]
    [DisallowConcurrentExecution]
    public class CHZKRYJobs : AbstractQuarztJob
    {
        public override void Run(IJobExecutionContext context)
        {
            foreach (ISqlOperate sql in LstSqlOperate)
            {
                string strSql = GlobalJobs.GetSql("CHZKRYJL");

                string str = string.Format(strSql, DateTime.Now.ToString("yyyyMMdd000000"), DateTime.Now.ToString("yyyyMMdd235959"));

                List<Dictionary<string, object>> lst = SqlUtil.Select(str, sql);
                IsolatorUtil.SendOneTime(lst, "CHZKRY", 251, GlobalJobs.MaxSendCount, true);
            }
        }
    }
}
