﻿using Quartz;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using XiaLM.Common;
using XiaLM.Schedule.Db.IManaments;

namespace XiaLM.Schedule.Jobs
{
    public class CHZKRYJob : IJob
    {
        private readonly ISqlManament sqlManament;
        public CHZKRYJob(ISqlManament _manament)
        {
            sqlManament = _manament;
        }

        public Task Execute(IJobExecutionContext context)
        {
            try
            {
                string strSql = sqlManament.FirstOrDefault(p=>p.SqlName.Equals("CHZKRYJL")).SqlText;
                string str = string.Format(strSql, DateTime.Now.ToString("yyyyMMdd000000"), DateTime.Now.ToString("yyyyMMdd235959"));


                foreach (ISqlOperate sql in LstSqlOperate)
                {
                    string strSql = GlobalJobs.GetSql("CHZKRYJL");

                    string str = string.Format(strSql, DateTime.Now.ToString("yyyyMMdd000000"), DateTime.Now.ToString("yyyyMMdd235959"));

                    List<Dictionary<string, object>> lst = SqlUtil.Select(str, sql);
                    IsolatorUtil.SendOneTime(lst, "CHZKRY", 251, GlobalJobs.MaxSendCount, true);
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex.ToString());
            }
            return Task.CompletedTask;
        }
    }
}
