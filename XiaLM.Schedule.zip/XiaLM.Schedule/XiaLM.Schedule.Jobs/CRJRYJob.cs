﻿using Quartz;
using System;
using System.Threading.Tasks;
using XiaLM.Common;

namespace XiaLM.Schedule.Jobs
{
    public class CRJRYJob : IJob
    {
        public Task Execute(IJobExecutionContext context)
        {
            try
            {
                //foreach (ISqlOperate sql in LstSqlOperate)
                //{
                //    string strSql = GlobalJobs.GetSql("crjry");

                //    string str = string.Format(strSql, DateTime.Now.AddMinutes(-60).ToString("yyyyMMddHHmmss"), DateTime.Now.ToString("yyyyMMddHHmmss"));

                //    List<Dictionary<string, object>> lst = SqlUtil.Select(str, sql);
                //    IsolatorUtil.SendOneTime(lst, "CRJRY", 69, GlobalJobs.MaxSendCount, true);
                //}
            }
            catch(Exception ex)
            {
                Logger.Error(ex.ToString());
            }
            return Task.CompletedTask;
        }
    }
}
