﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XiaLM.Schedule.Service
{
    public static class Global
    {
        /// <summary>
        /// 初始化系统
        /// </summary>
        public static void Init()
        {
            try
            {
                //string path = AppDomain.CurrentDomain.BaseDirectory + "Log4Net.config";
                //XmlConfigurator.Configure(new FileInfo(path));

                //LogHelp.Info("启动" + Resource1.StrName + "...........");
                //ThreadPool.SetMaxThreads(50, 80);

                //IsolatorUtil.StartDataBlock();
                //RabbitMqManage.Init();
                //RabbitMqManage.ConsumeRegist();

                //DbConfigRepertory dbconfig = new DbConfigRepertory();
                //dbconfig.init();

                //JobRepertory jobs = new JobRepertory();
                //jobs.init();

                //RunLogMonitor.Start();
                //SeviceState httpserver = new WebApiSeviceState();
                //httpserver.Start();
                //LogHelp.Info(Resource1.StrName + "初始化成功................");
            }
            catch (Exception ex)
            {
                //LogHelp.Error(typeof(Global), ex);
            }
        }
    }
}
