﻿using Microsoft.AspNetCore.Hosting;
using System;
using System.IO;
using XiaLM.Common;
using XiaLM.Schedule.Core;

namespace XiaLM.Schedule.Service
{
    class Program
    {
        static void Main(string[] args)
        {
            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
            System.Threading.Mutex mutex = new System.Threading.Mutex(false, "XiaLM.P101.Quartz");
            bool Running = !mutex.WaitOne(0, false);
            if (!Running)
            {
                var host = new WebHostBuilder()
                    .UseKestrel()
                    .UseUrls("http://localhost:5000")
                    .UseContentRoot(Directory.GetCurrentDirectory())
                    .UseIISIntegration()
                    .UseStartup<Startup>()
                    .Build();
                host.Run();

                JobManager.GetInstance().RunConfigJobs();   //运行配置文件中的工作计划
                while (true) Console.ReadKey();
            }
        }

        private static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            Logger.Error(e.ExceptionObject.ToString());
            Environment.Exit(0);
        }
    }
}
