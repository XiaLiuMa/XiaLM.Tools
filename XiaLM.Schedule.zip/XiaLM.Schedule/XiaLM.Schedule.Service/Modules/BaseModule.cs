﻿using Nancy;
using System;
using System.Collections.Generic;
using System.Text;

namespace XiaLM.Schedule.Service.Modules
{
    public class BaseModule : NancyModule
    {
        public BaseModule()
        {
            Get("/GetAllRuningJob", args => "Hello Wo rld, it's Nancy on .NET Core");
        }
    }
}
