﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace XiaLM.Schedule.Db
{
    public static class GlobalDbManament
    {
        /// <summary>
        /// 查询数据
        /// </summary>
        /// <param name="cmdText"></param>
        /// <returns></returns>
        public static List<Dictionary<string, object>> Select(string cmdText)
        {
            try
            {
                BaseDBContext.GetInstance().Database.ExecuteSqlCommand(cmdText);
                BaseDBContext.GetInstance().Objs.FromSql(cmdText);



                var lst = new List<Dictionary<string, object>>();

                var ds = new DataSet();
                SqlOperate.RunSQL(cmdText, ref ds);
                if (ds != null)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        var data = new Dictionary<string, object>();
                        foreach (DataColumn dc in ds.Tables[0].Columns)
                        {
                            data.Add(dc.ColumnName.ToUpper(), dr[dc]);
                        }
                        lst.Add(data);
                    }
                }
                return lst;
            }
            catch
            {
                throw;
            }
        }
        
    }
}
