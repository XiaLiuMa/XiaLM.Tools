﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using XiaLM.Schedule.Db.Entities;
using XiaLM.Schedule.Db.IManaments;

namespace XiaLM.Schedule.Db.Manaments
{
    public class ScheduleManament : BaseManament<ScheduleEntity, Guid>, IScheduleManament
    {
        public ScheduleManament(BaseDBContext dbcontext) : base(dbcontext)
        {
        }
    }
}
