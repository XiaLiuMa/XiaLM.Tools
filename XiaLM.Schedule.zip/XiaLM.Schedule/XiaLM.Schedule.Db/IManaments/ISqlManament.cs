﻿using System;
using XiaLM.Schedule.Db.Entities;

namespace XiaLM.Schedule.Db.IManaments
{
    public interface ISqlManament : IBaseManament<SqlEntity, Guid>
    {
    }
}
