﻿using System;
using XiaLM.Schedule.Db.Entities;

namespace XiaLM.Schedule.Db.IManaments
{
    public interface IScheduleManament : IBaseManament<ScheduleEntity, Guid>
    {
    }
}
