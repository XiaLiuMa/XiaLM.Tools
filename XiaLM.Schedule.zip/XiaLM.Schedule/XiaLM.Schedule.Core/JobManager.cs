﻿using Newtonsoft.Json;
using Quartz;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using XiaLM.Schedule.Core.Models;

namespace XiaLM.Schedule.Core
{
    /// <summary>
    /// 工作计划管理员
    /// </summary>
    public class JobManager
    {
        private static JobManager instance;
        private readonly static object objLock = new object();
        public static JobManager GetInstance()
        {
            if (instance == null)
            {
                lock (objLock)
                {
                    if (instance == null)
                    {
                        instance = new JobManager();
                    }
                }
            }
            return instance;
        }

        /// <summary>
        /// 运行配置的工作计划
        /// </summary>
        public void RunConfigJobs()
        {
            string strConfig = AppDomain.CurrentDomain.BaseDirectory + @"Configs\QuartzByCron.json";
            //var tempList = JsonConvert.DeserializeObject<List<ConfigJob>>(File.ReadAllText(strConfig));
            var tempList = JsonConvert.DeserializeObject<List<Scheduler>>(File.ReadAllText(strConfig));
            foreach (var item in tempList)
            {
                var tempResult = SchedulerCenter.GetInstance().RunScheduleJob(item);
            }
        }

        /// <summary>
        /// 运行工作计划
        /// </summary>
        public void RunJobs()
        {
            //string strConfig = AppDomain.CurrentDomain.BaseDirectory + @"Configs\QuartzByCron.json";
            //var tempList = JsonConvert.DeserializeObject<List<ConfigJob>>(File.ReadAllText(strConfig));
            //foreach (var item in tempList)
            //{
            //    var tempResult = SchedulerCenter.GetInstance().RunScheduleJob(item);
            //}
        }

        /// <summary>
        /// 获取项目中所有继承了IJober接口的类
        /// </summary>
        /// <returns></returns>
        public Type[] GetTypesBy_IJob()
        {
            return AppDomain.CurrentDomain.GetAssemblies().SelectMany(a => a.GetTypes().Where(t => t.GetInterfaces().Contains(typeof(IJob)))).ToArray();
        }


    }
}
