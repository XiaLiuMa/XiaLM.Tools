﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuartzNet2.Core.Entity {
    public class StatusResult {
        public int Status { get; set; }

        public string Msg { get; set; }
    }
}
