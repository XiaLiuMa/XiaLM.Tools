# QuartzNetJob
基于Asp.Net Core集成QuartzNet3.0的简单后端任务管理系统
Blog:http://www.cnblogs.com/miskis/p/8487634.html
